﻿--create table useractivities
CREATE TABLE [dbo].[alluseractivities] (
    [id]       INT           IDENTITY (1, 1) NOT NULL,
    [activity] VARCHAR (MAX) NULL,
    CONSTRAINT [PK_alluseractivities] PRIMARY KEY CLUSTERED ([id] ASC)
);

--create table category
CREATE TABLE [dbo].[category] (
    [id]          INT            IDENTITY (1, 1) NOT NULL,
    [catname]     VARCHAR (500)  NULL,
    [description] VARCHAR (1000) NULL,
    CONSTRAINT [PK_category] PRIMARY KEY CLUSTERED ([id] ASC)
);

--create table company
CREATE TABLE [dbo].[company] (
    [id]        INT            IDENTITY (1, 1) NOT NULL,
    [name]      VARCHAR (2000) NULL,
    [telephone] VARCHAR (50)   NULL,
    [location]  VARCHAR (50)   NULL,
    [email]     VARCHAR (500)  NULL,
    [regno]     VARCHAR (50)   NULL,
    [bop]       VARCHAR (500)  NULL,
    CONSTRAINT [PK_company] PRIMARY KEY CLUSTERED ([id] ASC)
);

--create table customers
CREATE TABLE [dbo].[customer] (
    [customerid] INT           IDENTITY (1, 1) NOT NULL,
    [name]       VARCHAR (500) NULL,
    [gender]     VARCHAR (6)   NULL,
    [contactno]  VARCHAR (10)  NULL,
    [email]      VARCHAR (500) NULL,
    [location]   VARCHAR (250) NULL,
    CONSTRAINT [PK_customer] PRIMARY KEY CLUSTERED ([customerid] ASC)
);

--create table expense
CREATE TABLE [dbo].[expense] (
    [id]          INT           IDENTITY (1, 1) NOT NULL,
    [title]       VARCHAR (500) NULL,
    [amount]      MONEY         NULL,
    [description] VARCHAR (MAX) NULL,
    [date]        DATE          NULL,
    [createdby]   VARCHAR (500) NULL,
    CONSTRAINT [PK_expense] PRIMARY KEY CLUSTERED ([id] ASC)
);

--create table invoice
CREATE TABLE [dbo].[invoice] (
    [invid]     INT           IDENTITY (1, 1) NOT NULL,
    [invoiceno] VARCHAR (500) NULL,
    [invdate]   DATE          NULL,
    CONSTRAINT [PK_invoice] PRIMARY KEY CLUSTERED ([invid] ASC)
);

--create table invoice_info
CREATE TABLE [dbo].[invoice_info] (
    [infoid]     INT           IDENTITY (1, 1) NOT NULL,
    [invoice_id] INT           NULL,
    [prod_id]    INT           NULL,
    [infoprice]  MONEY         NULL,
    [infoqty]    INT           NULL,
    [infototal]  MONEY         NULL,
    [infodate]   DATE          NULL,
    [customer]   VARCHAR (500) NULL,
    CONSTRAINT [PK_invoice_info] PRIMARY KEY CLUSTERED ([infoid] ASC)
);

--create table invoice_payment
CREATE TABLE [dbo].[invoice_payment] (
    [ipid]      INT          IDENTITY (1, 1) NOT NULL,
    [invoiceid] INT          NULL,
    [paymode]   VARCHAR (50) NULL,
    [paytotal]  MONEY        NULL,
    [paydate]   DATE         NULL,
    CONSTRAINT [PK_invoice_payment] PRIMARY KEY CLUSTERED ([ipid] ASC)
);

--create table location
CREATE TABLE [dbo].[location] (
    [locid]   INT           IDENTITY (1, 1) NOT NULL,
    [locname] VARCHAR (500) NULL,
    CONSTRAINT [PK_location] PRIMARY KEY CLUSTERED ([locid] ASC)
);

--create table product
CREATE TABLE [dbo].[product] (
    [productid]     INT           IDENTITY (1, 1) NOT NULL,
    [pcode]         VARCHAR (50)  NULL,
    [pname]         VARCHAR (MAX) NULL,
    [pcatid]        INT           NULL,
    [pcostprice]    MONEY         NULL,
    [punitprice]    MONEY         NULL,
    [preorderlevel] INT           NULL,
    [description]   VARCHAR (MAX) NULL,
    CONSTRAINT [PK_product] PRIMARY KEY CLUSTERED ([productid] ASC)
);

--create table staff
CREATE TABLE [dbo].[staff] (
    [staffid]     INT            IDENTITY (1, 1) NOT NULL,
    [fullname]    VARCHAR (500)  NULL,
    [gender]      VARCHAR (6)    NULL,
    [mobileno]    VARCHAR (10)   NULL,
    [location]    VARCHAR (150)  NULL,
    [email]       NVARCHAR (500) NULL,
    [contactname] VARCHAR (500)  NULL,
    [contactno]   VARCHAR (10)   NULL,
    [username]    VARCHAR (150)  NULL,
    [password]    VARCHAR (150)  NULL,
    [type]        VARCHAR (100)  NULL,
    [status]      VARCHAR (50)   NULL,
    [regdate]     DATE           NULL,
    CONSTRAINT [PK_staff] PRIMARY KEY CLUSTERED ([staffid] ASC)
);

--create table stock
CREATE TABLE [dbo].[stock] (
    [stid]        INT          IDENTITY (1, 1) NOT NULL,
    [stockid]     VARCHAR (50) NULL,
    [product_id]  INT          NULL,
    [quantity]    INT          NULL,
    [price]       MONEY        NULL,
    [totalamount] MONEY        NULL,
    [datein]      DATE         NULL,
    CONSTRAINT [PK_stock] PRIMARY KEY CLUSTERED ([stid] ASC)
);

--create table stock_payment
CREATE TABLE [dbo].[stock_payment] (
    [spid]         INT   IDENTITY (1, 1) NOT NULL,
    [stock_id]     INT   NULL,
    [supplier_id]  INT   NULL,
    [grandtotal]   MONEY NULL,
    [totalpayment] MONEY NULL,
    [paymentdue]   MONEY NULL,
    [payduedate]   DATE  NULL,
    [stockdate]    DATE  NULL,
    CONSTRAINT [PK_stock_payment] PRIMARY KEY CLUSTERED ([spid] ASC)
);

--create table supplier
CREATE TABLE [dbo].[supplier] (
    [supplierid]  INT           IDENTITY (1, 1) NOT NULL,
    [supplier_id] VARCHAR (50)  NULL,
    [name]        VARCHAR (500) NULL,
    [contactno]   VARCHAR (10)  NULL,
    [location]    VARCHAR (150) NULL,
    [email]       VARCHAR (500) NULL,
    [address]     VARCHAR (500) NULL,
    CONSTRAINT [PK_supplier] PRIMARY KEY CLUSTERED ([supplierid] ASC)
);

--creat table systemlogs
CREATE TABLE [dbo].[systemlogs] (
    [logid]     INT           IDENTITY (1, 1) NOT NULL,
    [logname]   VARCHAR (150) NULL,
    [logdate]   DATE          NULL,
    [logtime]   VARCHAR (50)  NULL,
    [operation] VARCHAR (100) NULL,
    CONSTRAINT [PK_systemlogs] PRIMARY KEY CLUSTERED ([logid] ASC)
);

--create table temp_stock
CREATE TABLE [dbo].[temp_stock] (
    [tsid]       INT IDENTITY (1, 1) NOT NULL,
    [prodid]     INT NULL,
    [stocklevel] INT NULL,
    CONSTRAINT [PK_temp_stock] PRIMARY KEY CLUSTERED ([tsid] ASC)
);

