﻿Imports System.Data.SqlClient
Imports POS.My

Module Connection
    Dim dbstr As String = MySettings.Default.POSConnectionString
    Public Connection As SqlConnection = New SqlConnection("Data Source=(LocalDB)\v11.0;Initial Catalog=POS;Integrated Security=True")
    'Public Dbconnection As SqlConnection = New SqlConnection("Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Bless\Desktop\prjts\POS\POS\DB\POS.mdf;Integrated Security=True")
    Public Dbconnection As SqlConnection = New SqlConnection("Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\DB\POS.mdf;Integrated Security=True")
    'Public Dbconnection As SqlConnection = New SqlConnection(dbstr)

End Module
