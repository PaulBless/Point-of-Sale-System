﻿Imports System.Data.SqlClient
Imports System.Net
Imports System.Text

Module modClasses
    'public variables and classes
    Public query As String
    Public command, command1 As SqlCommand
    Public dreader As SqlDataReader
    Public dset As New DataSet
    Public dtable As DataTable
    Public dadapter As SqlDataAdapter
    Public reguser As String = "Active"
    Public lockuser As String = "Locked"
    Public Defaultpassword As String = "pos12345"

    Public Property LogFullName As String 'this property holds user fullname
    Public Property LogUserRole As String  'this property holds user type
    Public Property LogUsername As String   'this holds username
    Public Property LogUserPassword As String 'property to hold user password
    Public Property LogStatus As String 'property to hold user status
    Public Property LogUid As Integer


    Public Function HandleRegistry() As Boolean
        Dim firstRunDate As Date
        Dim st As Date = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\POS", "Set", Nothing)
        firstRunDate = st
        If firstRunDate = Nothing Then
            firstRunDate = System.DateTime.Today.Date
            My.Computer.Registry.SetValue("HKEY_LOCAL_MACHINE\SOFTWARE\POS", "Set", firstRunDate)
        ElseIf (Now - firstRunDate).Days > 7 Then
            Return False
        End If
        Return True
    End Function
    'this function saves users login info
    Public Sub UserLogFunction(ByVal logname As String, ByVal operation As String)
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "insert into systemlogs(logname,logdate,logtime,operation) VALUES (@d1,@d2,@d3,@d4)"
            Dim cmd As SqlCommand = New SqlCommand(query, myconnection)
            cmd.Parameters.AddWithValue("@d1", logname)
            cmd.Parameters.AddWithValue("@d2", Date.Now.ToString())
            cmd.Parameters.AddWithValue("@d3", DateTime.Now.ToLongTimeString())
            cmd.Parameters.AddWithValue("@d4", operation)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            DisconnectDB()
        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Tygen User Logs Error")
        End Try
    End Sub
    'this function send sms to customers/suppliers
    Sub SMSFunction(ByVal st1 As String, ByVal st2 As String, ByVal st3 As String)
        st3 = st3.Replace("@MobileNo", st1).Replace("@Message", st2)
        Dim request As HttpWebRequest
        Dim response As HttpWebResponse = Nothing
        Dim myUri As New Uri(st3)
        request = DirectCast(WebRequest.Create(myUri), HttpWebRequest)
        response = DirectCast(request.GetResponse(), HttpWebResponse)
    End Sub
    'function to encrypt user's password
    Public Function EncryptPassword(password As String) As String
        Dim strmsg As String = String.Empty
        Dim encode As Byte() = New Byte(password.Length - 1) {}
        encode = Encoding.UTF8.GetBytes(password)
        strmsg = Convert.ToBase64String(encode)
        Return strmsg
    End Function
    Public Function DecryptPassword(encryptpwd As String) As String
        Dim decryptpwd As String = String.Empty
        Dim encodepwd As New UTF8Encoding()
        Dim Decode As Decoder = encodepwd.GetDecoder()
        Dim todecode_byte As Byte() = Convert.FromBase64String(encryptpwd)
        Dim charCount As Integer = Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length)
        Dim decoded_char As Char() = New Char(charCount - 1) {}
        Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0)
        decryptpwd = New [String](decoded_char)
        Return decryptpwd
    End Function
    Public Sub AllUserActivities(ByVal msg As String)
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ConnectDB()
            query = "insert into alluseractivities(activity) values(@d1)"
            command = New SqlCommand(query, myconnection)
            command.Parameters.AddWithValue("@d1", msg)
            command.ExecuteNonQuery()
            command.Dispose()
            DisconnectDB()
        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Tygen User Activities Error")
        End Try
    End Sub
    Public Sub DatabaseBackup()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'query = "exec msdb.dbo.sp_start_job @job_name='DatabaseBackup - USER_DATABASES - FULL'"
            query = "msdb.dbo.sp_start_job"
            command = New SqlCommand()
            command.CommandType = CommandType.StoredProcedure
            command.CommandText = query
            command.Parameters.AddWithValue("@job_name", "DatabaseBackup - USER_DATABASES - FULL")
            command.Connection = Dbconnection
            ConnectDB()
            command.ExecuteNonQuery()
            command.Dispose()
            myconnection.Close()
            MessageBox.Show("The Database Backup operation was completed successfully!", "DATABASE BACKUP", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Critical, "Database Backup Error")
        End Try
    End Sub
    Public Function GenerateUserName(ByVal uname As TextBox) 'function to split & generate usernames
        Dim st As String = uname.Text
        Dim username As String() = st.Split(" ")
        Dim finval As String = username(0) + "." + username(1)
        Return finval
    End Function
    Public Sub ValidateMobileNumber(ByVal txt As TextBox)
        Dim st As String = txt.Text.Substring(0, 3)
        Try
            If (st <> "024") AndAlso (st <> "054") AndAlso (st <> "055") AndAlso (st <> "059") AndAlso (st <> "027") AndAlso (st <> "057") AndAlso (st <> "026") AndAlso (st <> "020") AndAlso (st <> "050") AndAlso (st <> "023") Then
                MsgBox("Phone or mobile number not correct." & vbCrLf & "Number should be valid mtn/airteltigo/vodafone/glo... Please check", MsgBoxStyle.Information, "Invalid Mobile / Telephone")
                txt.Clear() 'clear the text
                txt.Focus()
                Exit Sub
            End If

        Catch ex As ArgumentOutOfRangeException
            'MessageBox.Show(ex.Message)
        Catch ex As ArgumentNullException
            'MessageBox.Show(ex.Message)
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub
    Public Function Convert_Number_to_Words(ByVal amt As Integer) As String
        Try
            Select Case amt
                Case 0
                    Return ""
                Case 1 To 19
                    Dim arrayOnes() As String = {"One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"}
                    Return arrayOnes(amt - 1) & " "
                Case 20 To 99
                    Dim arrayTens() As String = {"Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"}
                    Return arrayTens(amt \ 10 - 2) & " " & Convert_Number_to_Words(amt Mod 10)
                Case 100 To 199
                    Return "One hundred " & "and " & Convert_Number_to_Words(amt Mod 100)
                Case 200 To 999
                    Return Convert_Number_to_Words(amt \ 100) & "hundred and " & Convert_Number_to_Words(amt Mod 100)
                Case 1000 To 1999
                    'Return "One thousand " & Number_to_Words(amt \ 1000)
                    Return "One thousand " & Convert_Number_to_Words(amt Mod 1000)
                Case 2000 To 999999
                    Return Convert_Number_to_Words(amt \ 1000) & "thousand " & Convert_Number_to_Words(amt Mod 1000)
                Case Else
                    Return Convert_Number_to_Words(amt \ 1000000) & "One million " & Convert_Number_to_Words(amt \ 1000000)
            End Select

        Catch ex As IndexOutOfRangeException
            MsgBox(ex.Message)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Return amt
    End Function
End Module
