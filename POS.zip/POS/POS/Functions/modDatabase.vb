﻿Imports System.Data.SqlClient
Imports POS.My

Module modDatabase
    'Public dbConString As String = "Data Source=(LocalDb)\v.11; Initial Catalog=POS; Integrated Security=True"
    Public myConString As String = MySettings.Default.POSConnectionString
    Public myconnection As SqlConnection = New SqlConnection(myConString)    'database connection variable

    Public dataSource As String
    Public serverName As String

    Public Sub ConnectDB()
        If myconnection.State = ConnectionState.Open Then myconnection.Close()
        Try
            If myconnection.State = ConnectionState.Closed Then myconnection.Open()
            'myconnection.Open()
            'MsgBox("Database connected.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Tygen Sale System")

        Catch ex As Exception
            MsgBox("The system failed to establish a connection to the database." & vbCrLf & ex.ToString(), MsgBoxStyle.Critical, "Database Connection Error")
        End Try
    End Sub
    Public Sub DisconnectDB()
        Try
            myconnection.Close()
            myconnection.Dispose()
        Catch ex As Exception

        End Try
    End Sub
    Public Sub SetDbSettings()
        Dim appName As String = My.Application.Info.ProductName
        Try
            dataSource = GetSetting(appName, "DBSection", "DB_Name", myConString)
            serverName = GetSetting(appName, "DBSection", "DB_IP", My.Computer.Name.ToString())
            MsgBox(serverName & " " & dataSource)
        Catch ex As Exception
            MsgBox(ex.ToString())
            MsgBox("System registry was not established, you can set/save " & _
            "these settings by pressing F1", MsgBoxStyle.Information, "Database Settings Error")
        End Try
    End Sub
    Public Sub CommitDbSettings()
        Dim appName As String = My.Application.Info.ProductName
        Try
            SaveSetting(appName, "DBSection", "DB_Name", myConString)
            SaveSetting(appName, "DBSection", "DB_IP", My.Computer.Name.ToString())
            MsgBox("Database connection settings successfully saved.", MsgBoxStyle.Information, "Tygen Database Settings")

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Database Settings Failure")
        End Try
    End Sub
End Module
