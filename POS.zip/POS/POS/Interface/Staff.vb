﻿Imports System.Data.SqlClient

Public Class Staff
    Dim staffname As String
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub

    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        Try
            Dim frm As New StaffRecord
            frm.ActiveFormStaff = Me
            frm.lblSet.Text = "Staff Entry"
            frm.Reset()
            frm.ShowDialog()
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub
    Sub Reset()
        txtContactNo.Clear()
        txtContactName.Clear()
        txtLocation.Clear()
        txtEmail.Clear()
        txtMobileNo.Clear()
        txtPassword.Clear()
        txtPasswordConfirm.Clear()
        txtUsername.Clear()
        txtSID.Clear()
        txtStaffName.Clear()
        cboGender.ResetText()
        cboRole.ResetText()
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
        btnSave.Enabled = True
        btnCreate.Enabled = True
        txtStaffName.Focus()
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Reset()
    End Sub
    Sub SaveRecord()
        Try
            'check staff name exists
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Const sql As String = "select RTRIM(fullname) from staff where fullname=@d1"
            command = New SqlCommand(sql)
            command.Parameters.AddWithValue("@d1", txtStaffName.Text)
            command.Connection = myconnection
            dreader = command.ExecuteReader()
            If dreader.Read() Then
                dreader.Close()
                MessageBox.Show("A staff with the name: '" & txtStaffName.Text & "' is already registered", "Staff Name Exists", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                Exit Sub
            End If
            'check mobile no exists
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            Const check As String = "select RTRIM(mobileno) from staff where mobileno=@d1"
            command = New SqlCommand(check)
            command.Parameters.AddWithValue("@d1", txtMobileNo.Text)
            command.Connection = myconnection
            dreader = command.ExecuteReader()
            If dreader.Read() Then
                dreader.Close()
                MessageBox.Show("The mobile number '" & txtMobileNo.Text & "' is already added", "Mobile Number Exists", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                Exit Sub
            End If

            'proceed to save record
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "insert into staff(fullname, gender, mobileno, location, email,contactname,contactno,username,password,type,status,regdate) VALUES (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9,@d10,@d11,@d12)"
            command = New SqlCommand(query, myconnection)
            command.Parameters.AddWithValue("@d1", txtStaffName.Text)
            command.Parameters.AddWithValue("@d2", cboGender.Text)
            command.Parameters.AddWithValue("@d3", txtMobileNo.Text)
            command.Parameters.AddWithValue("@d4", (txtLocation.Text))
            command.Parameters.AddWithValue("@d5", (txtEmail.Text))
            command.Parameters.AddWithValue("@d6", (txtContactName.Text))
            command.Parameters.AddWithValue("@d7", txtContactNo.Text)
            command.Parameters.AddWithValue("@d8", GenerateUserName(txtStaffName))
            command.Parameters.AddWithValue("@d9", EncryptPassword(Defaultpassword))
            command.Parameters.AddWithValue("@d10", (cboRole.Text))
            command.Parameters.AddWithValue("@d11", (reguser))
            command.Parameters.AddWithValue("@d12", Date.Now)
            command.ExecuteNonQuery()
            AllUserActivities(LogFullName + ", registered a new staff with name: " & txtStaffName.Text & " on " & DateTime.Now)
            MessageBox.Show("Record saved" + vbCrLf + "User account Login details: " + vbCrLf + vbCrLf + "Login Username: " + txtUsername.Text + vbCrLf + "Login Password: " + txtPassword.Text, "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Reset()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "Save Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim st As String = txtContactNo.Text.Substring(0, 3)
        Dim st1 As String = txtMobileNo.Text.Substring(0, 3)
        If Len(Trim(txtStaffName.Text)) = 0 Then
            MessageBox.Show("Please enter staff name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtStaffName.Focus()
            Exit Sub
        End If
        If Len(Trim(txtMobileNo.Text)) = 0 Then
            MessageBox.Show("Please enter staff mobile number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtMobileNo.Focus()
            Exit Sub
        End If
        If (cboGender.Text = "") Then
            MessageBox.Show("Please select gender of stafff", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboGender.Focus()
            Exit Sub
        End If
        If Len(Trim(txtLocation.Text)) = 0 Then
            MessageBox.Show("Please enter location of staff", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtLocation.Focus()
            Exit Sub
        End If
        If Len(Trim(txtContactName.Text)) = 0 Then
            MessageBox.Show("Please enter contact name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtContactName.Focus()
            Exit Sub
        End If
        If Len(Trim(txtContactNo.Text)) = 0 Then
            MessageBox.Show("Please enter contact mobile number ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtContactNo.Focus()
            Exit Sub
        End If
        If (txtMobileNo.TextLength < 10) Then
            MessageBox.Show("Mobile number not complete, must be 10-digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtMobileNo.SelectAll()
            Exit Sub
        End If
        If (txtContactNo.TextLength < 10) Then
            MessageBox.Show("Contact mobile number not complete, must be 10-digits ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtContactNo.SelectAll()
            Exit Sub
        End If
        If (st <> "024") AndAlso (st <> "054") AndAlso (st <> "055") AndAlso (st <> "027") AndAlso (st <> "057") AndAlso (st <> "026") AndAlso (st <> "020") AndAlso (st <> "050") AndAlso (st <> "023") Then
            MsgBox("Contact mobile number not valid." & vbCrLf & "Number should be mtn/airteltigo/vodafone/glo... eg(0241234567)", MsgBoxStyle.Information, "Invalid Mobile / Telephone")
            txtContactNo.Clear() 'clear the text
            Exit Sub
        End If
        If (st1 <> "024") AndAlso (st1 <> "054") AndAlso (st1 <> "055") AndAlso (st1 <> "027") AndAlso (st1 <> "057") AndAlso (st1 <> "026") AndAlso (st1 <> "020") AndAlso (st1 <> "050") AndAlso (st1 <> "023") Then
            MsgBox("Phone or mobile number not valid." & vbCrLf & "Number should be mtn/airteltigo/vodafone/glo... eg(0241234567)", MsgBoxStyle.Information, "Invalid Mobile / Telephone")
            txtMobileNo.Clear() 'clear the text
            Exit Sub
        End If
        If (cboRole.Text) = "" Or (txtUsername.Text = "") Then
            MessageBox.Show("Please you must specify user role or type for staff account", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboRole.Focus()
            Exit Sub
        End If

        If MessageBox.Show("Are you sure you want to add this staff record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            SaveRecord()
        End If
    End Sub
    Sub UpdateRecord()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select * from staff where staffid='" & Val(txtSID.Text) & "'"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader()
            If (dreader.Read() = True) Then
                dreader.Close()
                staffname = lblName.Text
                'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ConnectDB()
                Dim str As String = "update staff set fullname=@d1, gender=@2, mobileno=@d3, location=@d4, email=@d5, contactname=@d6, contactno=@d7 where staffid=@d12"
                Dim cmd As SqlCommand = New SqlCommand(str, Dbconnection)
                cmd.Parameters.AddWithValue("@d1", txtStaffName.Text)
                cmd.Parameters.AddWithValue("@d2", cboGender.Text)
                cmd.Parameters.AddWithValue("@d3", txtMobileNo.Text)
                cmd.Parameters.AddWithValue("@d4", txtLocation.Text)
                cmd.Parameters.AddWithValue("@d5", txtEmail.Text)
                cmd.Parameters.AddWithValue("@d6", (txtContactName.Text))
                cmd.Parameters.AddWithValue("@d7", (txtContactNo.Text))
                cmd.Parameters.AddWithValue("@d12", Val(txtSID.Text))
                cmd.ExecuteNonQuery()
                ''cmd.Parameters.AddWithValue("@d8", txtUsername.Text)
                ''cmd.Parameters.AddWithValue("@d9", Encrypt(txtPassword.Text))
                ''cmd.Parameters.AddWithValue("@d10", cboRole.Text)
                ''cmd.Parameters.AddWithValue("@d11", LogStatus)
                ''Dbconnection.Open()
                AllUserActivities(LogFullName & ", updated staff with name: " & staffname & " on " & Date.Now)
                MessageBox.Show("Record successfully updated.", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            Else
                MessageBox.Show("Sorry... There is no specifiec staff record found to perform operation.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Exclamation, "Update Record Error")
        End Try
    End Sub
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If MessageBox.Show("Are you sure you want to update this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            UpdateRecord()
        End If
    End Sub
    Sub DeleteRecord()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            staffname = lblName.Text
            Dim chk As String = "select * from staff where staffid='" & Val(txtSID.Text) & ""
            Dim com As New SqlCommand(chk, myconnection)
            dreader = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dreader.Read() Then  'if record is found in database, proceed to delete
                dreader.Close()
                'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                'Dbconnection.Open()
                ConnectDB()
                query = "delete from staff where staffid='" & Val(txtSID.Text) & "'"
                command = New SqlCommand(query, myconnection)
                command.ExecuteNonQuery()
                AllUserActivities(LogFullName + ", deleted the staff " & staffname & " on " & Date.Now)
                MessageBox.Show("Record successfully deleted", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            Else
                MessageBox.Show("Staff record not found. Could not complete the process..", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.MsgBoxSetForeground, "Delete Record Error")
        End Try

    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MessageBox.Show("Are you sure you want to delete this staff record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error) = DialogResult.Yes Then
            DeleteRecord()
        End If
    End Sub

    Private Sub cboRole_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboRole.SelectedIndexChanged
        ''Try
        ''    If cboRole.Text <> "" Then
        ''        If txtStaffName.Text <> "" Then
        ''            txtUsername.Text = UserAccount(txtStaffName)
        ''            txtPassword.Text = Defaultpassword
        ''        Else
        ''            MsgBox("Please, staff name is required, to generate account username and password..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Message")
        ''        End If
        ''    End If
        ''Catch ex As Exception

        ''End Try

    End Sub
    Private Sub cboRole_MouseClick(sender As Object, e As MouseEventArgs) Handles cboRole.MouseClick
        If (Len(Trim(txtStaffName.Text)) = 0) Then
            MsgBox("Please, staff name is required, to generate account username and password..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Message")
            txtStaffName.Focus()
            Exit Sub
        End If
    End Sub
    Private Sub txtContactNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtContactNo.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Private Sub txtMobileNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMobileNo.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Private Sub txtEmail_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEmail.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 45, 46, 64, 95, 127, 48 To 57, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
    Private Sub txtStaffName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStaffName.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
    Private Sub txtLocation_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtLocation.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtMobileNo_Leave(sender As Object, e As EventArgs) Handles txtMobileNo.Leave
        If Not txtMobileNo.Text.StartsWith("0") Then
            txtMobileNo.ForeColor = Color.Red
        Else
            txtMobileNo.ForeColor = Color.Black
        End If
    End Sub
    Private Sub txtContactNo_Leave(sender As Object, e As EventArgs) Handles txtContactNo.Leave
        If Not txtContactNo.Text.StartsWith("0") Then
            txtContactNo.ForeColor = Color.Red
        Else
            txtContactNo.ForeColor = Color.Black
        End If
    End Sub
    Private Sub cboRole_Leave(sender As Object, e As EventArgs) Handles cboRole.Leave
        'Try
        '    If cboRole.Text <> "" Then
        '        If txtStaffName.Text <> "" Then
        '            txtUsername.Text = UserAccount(txtStaffName)
        '            txtPassword.Text = Defaultpassword
        '        Else
        '            ''MsgBox("Please, staff name is required, to generate account username and password..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Message")
        '        End If
        '    End If
        'Catch ex As Exception

        'End Try
    End Sub
    Private Sub cboRole_TextChanged(sender As Object, e As EventArgs) Handles cboRole.TextChanged
        ''Try
        ''    If cboRole.Text <> "" Then
        ''        If txtStaffName.Text <> "" Then
        ''            txtUsername.Text = UserAccount(txtStaffName)
        ''            txtPassword.Text = Defaultpassword
        ''        Else
        ''            ''MsgBox("Please, staff name is required, to generate account username and password..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Message")
        ''        End If
        ''    End If
        ''Catch ex As Exception

        ''End Try
    End Sub

    Private Sub txtStaffName_TextChanged(sender As Object, e As EventArgs) Handles txtStaffName.TextChanged
        If txtStaffName.Text = "" Then
            txtPassword.Text = ""
            txtUsername.Text = ""
        Else
            Try
                If cboRole.Text <> "" Then
                    ''txtUsername.Text = UserAccount(txtStaffName)
                    ''txtPassword.Text = Defaultpassword
                Else
                End If
            Catch ex As Exception

            End Try
        End If
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        Try
            If (txtStaffName.Text = "" Or cboRole.Text = "") Then
                MsgBox("Please, staff name and user type is required, to generate account username and password..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Message")
                Return
            Else
                txtUsername.Text = GenerateUserName(txtStaffName)
                txtPassword.Text = Defaultpassword
            End If
        Catch ex As Exception

        End Try
    End Sub

End Class