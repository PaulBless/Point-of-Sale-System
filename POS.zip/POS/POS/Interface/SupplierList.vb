﻿Imports System.Data.SqlClient

Public Class SupplierList
    Public Property CurrentActiveForm As Stock
    Private Sub GetSupplierList()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select supplierid, supplier_id, name, contactno, location from supplier order by name asc"
            dadapter = New SqlDataAdapter(query, myconnection)
            dtable = New DataTable()
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of suppliers found.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                dgv.Rows.Clear()
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    dgv.Rows(i).Cells(0).Value = item("supplierid").ToString()
                    dgv.Rows(i).Cells(1).Value = item("supplier_id").ToString()
                    dgv.Rows(i).Cells(2).Value = item("name").ToString()
                    dgv.Rows(i).Cells(3).Value = item("contactno").ToString()
                    dgv.Rows(i).Cells(4).Value = item("location").ToString()
                Next
            End If

        Catch ex As SqlException
            MessageBox.Show(ex.Message, "Sql Error")
        Catch ex As Exception
            MsgBox(ex.Message, , "Search Data Error")
        End Try
    End Sub
    Private Sub SupplierList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetSupplierList()
    End Sub
    Private Sub dgv_MouseClick(sender As Object, e As MouseEventArgs) Handles dgv.MouseClick
        Try
            If dgv.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgv.SelectedRows(0)
                'determine the current active form
                'using active form method : display record to active form - stock
                CurrentActiveForm.Show()
                CurrentActiveForm.Activate()
                CurrentActiveForm.txtSup_ID.Text = dr.Cells(1).Value.ToString()
                CurrentActiveForm.txtSupplierName.Text = dr.Cells(2).Value.ToString()
                CurrentActiveForm.txtContact.Text = dr.Cells(3).Value.ToString()
                CurrentActiveForm.txtLocation.Text = dr.Cells(4).Value.ToString()
                CurrentActiveForm.lblSet.Text = ""
                Me.Close()  'close popup form
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub
    Private Sub dgv_RowPrePaint(sender As Object, e As DataGridViewRowPrePaintEventArgs) Handles dgv.RowPrePaint
        If e.RowIndex >= 0 Then
            Me.dgv.Rows(e.RowIndex).Cells(0).Value = e.RowIndex + 1
        End If
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
End Class