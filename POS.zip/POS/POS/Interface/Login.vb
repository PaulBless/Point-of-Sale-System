﻿Imports System.Data.SqlClient
Imports System.Timers

Public Class Login
    Dim frm As New Menu

    Private Sub Login_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed

    End Sub
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
  
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'validate user credentials
        If UsernameTextBox.Text = "" Then
            MsgBox("Enter Username", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Login Error")
            UsernameTextBox.Focus()
            Exit Sub
        End If
        If (PasswordTextBox.Text = "") Then
            MsgBox("Enter Password", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Login Error")
            PasswordTextBox.Focus()
            Exit Sub
        End If

        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()   'old db connection
            ConnectDB()
            Dim enteredPassword As String 'variable for entered password
            query = "select staffid,fullname,username,password,type,status from staff where username=@d1"
            command = New SqlCommand(query, myconnection)
            command.Parameters.AddWithValue("@d1", UsernameTextBox.Text)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            If dreader.Read() Then
                LogUid = dreader(0)  'read the userid
                LogFullName = dreader(1).ToString()  'read the fullname
                LogUsername = dreader(2).ToString() 'read the username
                LogUserPassword = dreader(3).ToString() 'read the user password
                LogUserRole = dreader(4).ToString() 'read the role of user
                LogStatus = dreader(5).ToString() 'read the current status of user
                dreader.Close() 'close the database reader class

                enteredPassword = EncryptPassword(PasswordTextBox.Text)    'encrypt the entered password
                If (enteredPassword <> LogUserPassword) Then   'display error password
                    MsgBox("The password is incorrect. Try Again..", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Login Failed")
                    PasswordTextBox.Text = ""
                    PasswordTextBox.Focus()
                    LinkLabel1.Visible = True
                    Exit Sub
                Else
                    LinkLabel1.Visible = False
                End If

                If LogStatus = "Locked" Then   'display error message for deactivated user account
                    MsgBox("Login Denied!" + vbCrLf + "Your account is currently de-activated... See your System Admin", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Account Locked")
                    ''lblLock.Visible = True
                    UsernameTextBox.Clear()
                    PasswordTextBox.Clear()
                    UsernameTextBox.Focus()
                    Exit Sub         
                End If

                'access control method
                'system administrator section
                If (LogUserRole = "ADMINISTRATOR") Then
                    UsernameTextBox.Text = ""
                    PasswordTextBox.Text = ""
                    Me.Hide()
                    frm.Show()
                    frm.lblLogUser.Text = LogUsername
                End If
                'salesperson section
                If (LogUserRole = "SALESPERSON") Then
                    UsernameTextBox.Text = ""
                    PasswordTextBox.Text = ""
                    Me.Hide()
                    frm.Show()
                    frm.lblLogUser.Text = LogUsername
                    frm.btnCompany.Enabled = False
                    frm.btnRegistration.Enabled = False
                    frm.btnStaff.Enabled = False
                    frm.btnStockEntry.Enabled = False
                    frm.btnProduct.Enabled = False
                    frm.btnSystemLogs.Enabled = False
                    frm.btnStocks.Enabled = False
                    frm.btnSales.Enabled = False
                    frm.btnExpenses.Enabled = False
                    frm.btnStaffs.Enabled = False
                    frm.btnCategory.Enabled = False
                End If
                'manager section
                If (LogUserRole = "MANAGER") Then
                    UsernameTextBox.Text = ""
                    PasswordTextBox.Text = ""
                    Me.Hide()
                    frm.Show()
                    frm.lblLogUser.Text = LogUsername
                    frm.btnRegistration.Enabled = False
                    frm.btnDatabase.Enabled = False
                    frm.btnDbConfigure.Enabled = False
                End If
            Else
                MsgBox("The username, '" & UsernameTextBox.Text & "' does not Exists or is Incorrect! " + vbCrLf + "Please check...", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Access Denied")
                UsernameTextBox.Focus()
                UsernameTextBox.SelectAll()
                Exit Sub
            End If

        Catch ex As SqlException
            MsgBox(ex.Message(), MsgBoxStyle.Information, "Database Connection Exception")
      Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Information, "System Login Error")
        End Try

        ''insert userlogs
        Const str As String = "Successfully login into the system"
        UserLogFunction(LogUsername, str)
    End Sub
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Using progressbar
        Try
            ProgressBar1.Value = ProgressBar1.Value + 1
            If (ProgressBar1.Value = 30) Then
                lblvalidate.Visible = True
            End If
            If (ProgressBar1.Value = 60) Then
                lblvalidate.Visible = True
            End If
            If (ProgressBar1.Value = 90) Then
                lblvalidate.Visible = True
            End If
            If (ProgressBar1.Value = 100) Then
                Timer1.Stop()
            End If
        Catch ex As StackOverflowException
        Catch ex As ArgumentOutOfRangeException
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Login_MouseClick(sender As Object, e As MouseEventArgs) Handles Me.MouseClick
        Activate()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked

    End Sub
    Private Sub UsernameTextBox_TextChanged(sender As Object, e As EventArgs) Handles UsernameTextBox.TextChanged
        If (UsernameTextBox.Text = "" Or PasswordTextBox.Text = "") AndAlso (lblLock.Visible = True) Then
            lblLock.Visible = False
        End If
    End Sub
    Private Sub PasswordTextBox_TextChanged(sender As Object, e As EventArgs) Handles PasswordTextBox.TextChanged
        If (UsernameTextBox.Text = "" Or PasswordTextBox.Text = "") AndAlso (lblLock.Visible = True) Then
            lblLock.Visible = False
        End If
    End Sub
End Class