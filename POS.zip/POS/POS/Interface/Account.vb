﻿Imports System.Data.SqlClient

Public Class Account
    Sub GetData()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Dim str As New SqlCommand("select staffid, fullname, gender, mobileno, username, password,type, status from staff", myconnection)
            dreader = str.ExecuteReader()
            dgv.Rows.Clear()
            If (dreader.HasRows()) Then
                While (dreader.Read())
                    dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6), dreader(7))
                End While
            Else
                MsgBox("Sorry.. No record of staff + account information found in the system...", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Message")
            End If
        Catch ex As Exception
            MsgBox(ex.Message, , "Search Error")
        End Try
    End Sub
    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        Try
            txtname.Text = dgv.Item(1, e.RowIndex).Value.ToString()
            txtgender.Text = dgv.Item(2, e.RowIndex).Value
            txtmobile.Text = dgv.Item(3, e.RowIndex).Value
            txtUsername.Text = dgv.Item(4, e.RowIndex).Value
            txtPassword.Text = dgv.Item(5, e.RowIndex).Value
            cboRole.Text = dgv.Item(6, e.RowIndex).Value
            cbostatus.Text = dgv.Item(7, e.RowIndex).Value
            btnUpdate.Enabled = True
            btnLock.Enabled = True
            btnGetData.Enabled = False
        Catch ex As Exception

        End Try
    End Sub
    Private Sub dgv_Click(sender As Object, e As EventArgs) Handles dgv.Click
        dgv.SelectAll()
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
            row.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
    End Sub
    Sub Reset()
        txtUsername.Clear()
        txtPassword.Clear()
        txtgender.Clear()
        txtname.Clear()
        txtmobile.Clear()
        txtgender.Clear()
        cboRole.ResetText()
        cbostatus.ResetText()
        btnUpdate.Enabled = False
        btnLock.Enabled = False
        btnGetData.Enabled = True
        ''GetData()
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Reset()
        GetData()
    End Sub
    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        GetData()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If MessageBox.Show("Do you really want to update (change type and status) of the selected staff account info", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Try
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ConnectDB()
                query = "UPDATE staff SET type=@d1, status=@d2 where staffid='" & (dgv.SelectedRows(0).Cells(0).Value) & "'"
                command1 = New SqlCommand(query, myconnection)
                command1.Parameters.AddWithValue("@d1", cboRole.Text)
                command1.Parameters.AddWithValue("@d2", cbostatus.Text)
                ''Dbconnection.Open()
                command1.ExecuteNonQuery()
                AllUserActivities(LogFullName & ", updated the staff account info with the name: " & txtname.Text & " on " & Date.Now)
                MessageBox.Show("Record updated..", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
                GetData()
            Catch ex As Exception
                MsgBox(ex.ToString(), MsgBoxStyle.Information, "Error")
            End Try
        End If
    End Sub

    Private Sub btnLock_Click(sender As Object, e As EventArgs) Handles btnLock.Click
        If MessageBox.Show("The selected staff account will be locked(de-activated). The user cannot access or log into the system again." + vbCrLf + "Do you want to Continue?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Yes Then
            If cbostatus.Text = "Locked" Then
                MsgBox("Cannot complete process, because the user account is already deactivated..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error")
                Exit Sub
            Else
                Try
                    ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                    ConnectDB()
                    query = "UPDATE staff SET status=@d1 where staffid='" & (dgv.SelectedRows(0).Cells(0).Value) & "'"
                    command = New SqlCommand(query, myconnection)
                    command.Parameters.AddWithValue("@d1", lockuser)
                    ''Dbconnection.Open()
                    command.ExecuteNonQuery()
                    AllUserActivities(LogFullName & ", locked the staff account info with the name: " & txtname.Text & " on " & Date.Now)
                    MessageBox.Show("Account Locked.", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Reset()
                    GetData()
                Catch ex As Exception
                    MsgBox(ex.ToString(), MsgBoxStyle.Information, "Error")
                End Try
            End If

        End If
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub

    Private Sub Account_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Reset()
    End Sub

    Private Sub Account_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class