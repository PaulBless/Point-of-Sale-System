﻿Imports System.Data.SqlClient

Public Class CustomerRecord

    Private Sub CustomerRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetCustomers()
        dgv.RowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    End Sub
    Private Sub GetCustomers()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select customerid,name,gender,contactno, email,location from customer order by name"
            command = New SqlCommand(query, myconnection)
            dtable = New DataTable()
            dadapter = New SqlDataAdapter(command)
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of available customers found in the system", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    'get customers info 
                    dgv.Rows(i).Cells(0).Value = item("customerid").ToString()
                    dgv.Rows(i).Cells(1).Value = item("name").ToString()
                    dgv.Rows(i).Cells(2).Value = item("gender").ToString()
                    dgv.Rows(i).Cells(3).Value = (item("contactno").ToString())
                    dgv.Rows(i).Cells(4).Value = item("email").ToString()
                    dgv.Rows(i).Cells(5).Value = (item("location").ToString())
                Next
            End If
        Catch ex As SqlException
            MessageBox.Show(ex.Message(), "Sql Exception")
        Catch ex As Exception
            MsgBox(ex.Message(), , "Get Data Error")
        End Try
    End Sub

    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
            row.HeaderCell.Style.Alignment = ContentAlignment.MiddleLeft
        Next
    End Sub
    Private Sub txtname_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged
        If txtname.Text <> "" Then
            Try
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                query = "select customerid,name,gender,contactno, email,location from customer where name like '%" & txtname.Text & "%' order by name"
                command = New SqlCommand(query, myconnection)
                dtable = New DataTable()
                dadapter = New SqlDataAdapter(command)
                dadapter.Fill(dtable)
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    'get customers info 
                    dgv.Rows(i).Cells(0).Value = item("customerid").ToString()
                    dgv.Rows(i).Cells(1).Value = item("name").ToString()
                    dgv.Rows(i).Cells(2).Value = item("gender").ToString()
                    dgv.Rows(i).Cells(3).Value = (item("contactno").ToString())
                    dgv.Rows(i).Cells(4).Value = item("email").ToString()
                    dgv.Rows(i).Cells(5).Value = (item("location").ToString())
                Next
            Catch ex As SqlException
                ''MessageBox.Show(ex.Message())
            Catch ex As Exception
                ''MsgBox(ex.Message())
            End Try
        End If
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
End Class