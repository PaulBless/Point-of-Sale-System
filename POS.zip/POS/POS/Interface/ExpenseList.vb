﻿Public Class ExpenseList
    Public Property CurrentForm As Expense
    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        Dim cms As New ContextMenuStrip
        'ContextMenuStrip1.SetBounds(692, 46, 392, 370)
        ContextMenuStrip1.SetBounds(219, 30, 219, 30)
        ContextMenuStrip1.Show()
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click

    End Sub
    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click

    End Sub

    Private Sub ExpenseList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub
End Class