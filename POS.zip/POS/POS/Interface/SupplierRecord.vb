﻿Imports System.Data.SqlClient

Public Class SupplierRecord
    Public Property CurrentActiveForm() As Supplier
    Public Property CurrentForm_Stock As Stock

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub
    Sub Reset()
         txtName.Clear()
        txtLocation.Clear()
        dgv.Rows.Clear()
        Getdata()
    End Sub
    Public Sub Getdata()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            command = New SqlCommand("SELECT RTRIM(supplierid),RTRIM(supplier_id),RTRIM([name]), RTRIM(contactno),RTRIM(location),RTRIM(email),RTRIM(address) from supplier order by name", myconnection)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dreader.Read() = True)
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6))
            End While
            'Dbconnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtName_TextChanged(sender As Object, e As EventArgs) Handles txtName.TextChanged
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "SELECT RTRIM(supplierid),RTRIM(supplier_id),RTRIM([name]), RTRIM(contactno),RTRIM(location),RTRIM(email),RTRIM(address) from supplier where name like '%" & txtName.Text & "%' order by name"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dreader.Read() = True)
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6))
            End While
            'Dbconnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub txtLocation_TextChanged(sender As Object, e As EventArgs) Handles txtLocation.TextChanged
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "SELECT RTRIM(supplierid),RTRIM(supplier_id),RTRIM([name]), RTRIM(contactno),RTRIM(location),RTRIM(email),RTRIM(address) from supplier where location like '%" & txtLocation.Text & "%' order by location"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dreader.Read() = True)
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6))
            End While
            Dbconnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub DisplayData()
        Try
            If dgv.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgv.SelectedRows(0)
                If lblSet.Text = "Supplier Entry" Then
                    Supplier.Show()
                    Me.Close()
                    Supplier.txtSID.Text = dr.Cells(0).Value.ToString()
                    Supplier.txtSupplierID.Text = dr.Cells(1).Value.ToString()
                    Supplier.txtSupplierName.Text = dr.Cells(2).Value.ToString()
                    Supplier.txtContactNo.Text = dr.Cells(7).Value.ToString()
                    Supplier.btnUpdate.Enabled = True
                    Supplier.btnDelete.Enabled = True
                    Supplier.btnSave.Enabled = False
                    lblSet.Text = ""
                End If
                If lblSet.Text = "Stock Entry" Then
                    Stock.Show()
                    Me.Close()
                    Stock.txtSup_ID.Text = dr.Cells(0).Value.ToString()
                    Stock.txtLocation.Text = dr.Cells(1).Value.ToString()
                    Stock.txtContact.Text = dr.Cells(2).Value.ToString()
                    Stock.txtSupplierName.Text = dr.Cells(3).Value.ToString()
                    lblSet.Text = ""
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
  Private Sub dgv_MouseClick(sender As Object, e As MouseEventArgs) Handles dgv.MouseClick
        Try
            If dgv.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgv.SelectedRows(0)
                If lblSet.Text = "Set" Then
                    'do nothing
                    'on mouse_click event
                End If
                If lblSet.Text = "Supplier Entry" Then
                    CurrentActiveForm.Show()
                    CurrentActiveForm.txtSID.Text = dr.Cells(0).Value.ToString()
                    CurrentActiveForm.txtSupplierID.Text = dr.Cells(1).Value.ToString()
                    CurrentActiveForm.txtSupplierName.Text = dr.Cells(2).Value.ToString()
                    CurrentActiveForm.txtContactNo.Text = dr.Cells(3).Value.ToString()
                    CurrentActiveForm.txtLocation.Text = dr.Cells(4).Value.ToString()
                    If Not dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value = String.Empty Then
                        CurrentActiveForm.txtAddress.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value.ToString()
                    Else
                        CurrentActiveForm.txtAddress.Text = ""
                    End If
                    If Not dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value = String.Empty Then
                        CurrentActiveForm.txtEmailID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value.ToString()
                    Else
                        CurrentActiveForm.txtEmailID.Text = ""
                    End If
                    CurrentActiveForm.btnUpdate.Enabled = True
                    CurrentActiveForm.btnDelete.Enabled = True
                    CurrentActiveForm.btnSave.Enabled = False
                    CurrentActiveForm.btnNew.Enabled = True
                    CurrentActiveForm.lblSet.Text = ""
                    Me.Close()
                End If
                If lblSet.Text = "Stock Entry" Then
                    'determine the current active form
                    'using active form method : display record to active form - stock
                    CurrentForm_Stock.Show()
                    CurrentForm_Stock.Activate()
                    CurrentForm_Stock.txtSup_ID.Text = dr.Cells(1).Value.ToString()
                    CurrentForm_Stock.txtSupplierName.Text = dr.Cells(2).Value.ToString()
                    CurrentForm_Stock.txtContact.Text = dr.Cells(3).Value.ToString()
                    CurrentForm_Stock.txtLocation.Text = dr.Cells(4).Value.ToString()
                    CurrentForm_Stock.lblSet.Text = ""
                    Me.Close()  'close popup form
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub DisplayFormValues()
        'If dgv.Rows.Count > 0 Then
        '    Dim dr As DataGridViewRow = dgv.SelectedRows(0)
        '    If CurrentForm_Stock.lblSet.Text = "Stock Entry" Then
        '        'determine the current active form
        '        'using active form method : display record to active form - stock
        '        CurrentForm_Stock.Show()
        '        CurrentForm_Stock.Activate()
        '        CurrentForm_Stock.txtSup_ID.Text = dr.Cells(1).Value.ToString()
        '        CurrentForm_Stock.txtSupplierName.Text = dr.Cells(2).Value.ToString()
        '        CurrentForm_Stock.txtContact.Text = dr.Cells(3).Value.ToString()
        '        CurrentForm_Stock.txtLocation.Text = dr.Cells(4).Value.ToString()
        '        CurrentForm_Stock.lblSet.Text = ""
        '        Me.Close()  'close popup form
        '    End If
        'End If
    End Sub
    Private Sub SupplierRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata()

    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub
    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
    Private Sub dgv_RowPrePaint(sender As Object, e As DataGridViewRowPrePaintEventArgs) Handles dgv.RowPrePaint
        dgv.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    End Sub
End Class