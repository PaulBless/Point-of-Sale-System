﻿Imports System.Data.SqlClient

Public Class ChangePassword

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim pass As String = txtOldPass.Text
        Dim epass As String = EncryptPassword(pass)
        If Len(Trim(txtOldPass.Text)) = 0 Then
            MessageBox.Show("Please enter old password", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtOldPass.Focus()
            Exit Sub
        End If
        If Len(Trim(txtNewPass.Text)) = 0 Then
            MessageBox.Show("Please enter new password", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtNewPass.Focus()
            Exit Sub
        End If
        If Len(Trim(txtNewPassConfirm.Text)) = 0 Then
            MessageBox.Show("Please confirm new password", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtNewPassConfirm.Focus()
            Exit Sub
        End If
        If (txtNewPass.TextLength < 6) Then
            MessageBox.Show("The new password should be of Atleast 6 Characters", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtNewPass.Text = ""
            txtNewPassConfirm.Text = ""
            txtNewPass.Focus()
            Exit Sub
        ElseIf (txtNewPass.Text <> txtNewPassConfirm.Text) Then
            MessageBox.Show("The new password and confirm passwords you entered do not match", "Input error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtNewPass.Text = ""
            txtNewPassConfirm.Text = ""
            txtNewPass.Focus()
            Exit Sub
        ElseIf (txtOldPass.Text = txtNewPass.Text) Then
            MessageBox.Show("The Old password and New password is same.. Re-enter new password", "Input error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtNewPass.Text = ""
            txtNewPassConfirm.Text = ""
            txtNewPass.Focus()
            Exit Sub
        End If
        If epass <> LogUserPassword Then
            MsgBox("The old password is incorrect. Check..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Old-password Error")
            txtOldPass.SelectAll()
            txtOldPass.Focus()
            Exit Sub
        End If

        If MessageBox.Show("Do you really want to change your password?", "Password Change Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
            UpdatePassword()
            Application.Restart()
        End If
    End Sub
    Private Sub UpdatePassword()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ConnectDB()
            command = New SqlCommand("update staff set password=@password where username='" & Me.txtUserId.Text & "' and staffid='" & LogUid & "'", myconnection)
            command.Parameters.AddWithValue("@password", EncryptPassword(txtNewPassConfirm.Text.Trim()))
            ''Dbconnection.Open()
            command.ExecuteNonQuery()
            command.Dispose()
            Dbconnection.Close()
            AllUserActivities(LogFullName & ", changed the account password on " & Now.ToLongDateString())
            MsgBox("Password changed successfully.." & vbCrLf & "Your New Password is: (" + txtNewPassConfirm.Text + ")", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Password Changed!")
            Reset()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "password change error")
        End Try
    End Sub
    Sub Reset()
        txtNewPass.Text = ""
        txtNewPassConfirm.Text = ""
        txtOldPass.Text = ""
        txtUserId.Text = ""

    End Sub

    Private Sub ChangePassword_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Reset()
    End Sub

    Private Sub ChangePassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtUserId.Text = LogUsername
    End Sub
End Class