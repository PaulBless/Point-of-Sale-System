﻿Imports System.Data.SqlClient

Public Class Stockin

    Private Sub dgvinfo_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
    Private Sub GetStocks()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select productid,pcode,pname, punitprice,stocklevel from product p inner join temp_stock ts on p.productid=ts.prodid order by pname"
            command = New SqlCommand(query, myconnection)
            dtable = New DataTable()
            dadapter = New SqlDataAdapter(command)
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                dgv.Rows.Clear()
                MessageBox.Show("Sorry... No available stock list record found", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    'get products info 
                    dgv.Rows(i).Cells(0).Value = (item("productid").ToString())
                    dgv.Rows(i).Cells(1).Value = (item("pcode").ToString())
                    dgv.Rows(i).Cells(2).Value = (item("pname").ToString())
                    dgv.Rows(i).Cells(3).Value = "Gh¢ " + Format(item("punitprice"), "#,##0.00")
                    dgv.Rows(i).Cells(4).Value = (item("stocklevel"))
                Next
            End If
        Catch ex As SqlException
            MessageBox.Show(ex.Message())
        Catch ex As Exception
            MsgBox(ex.Message(), , "Stockin Error")
        End Try
    End Sub

    Private Sub Stockin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetStocks()
    End Sub
    Sub Reset()
        txtProductName.Text = ""
        GetStocks()
    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub txtProductName_TextChanged(sender As Object, e As EventArgs) Handles txtProductName.TextChanged
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select productid,pcode,pname, punitprice,stocklevel from product p inner join temp_stock ts on p.productid=ts.prodid where pname like '%" & txtProductName.Text & "%' order by pname"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader()
            dgv.Rows.Clear()
            While (dreader.Read())
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), "Gh¢ " + Format(dreader(3), "#,##0.00"), dreader(4))
            End While
            dreader.Close()
        Catch ex As SqlException
            ''MessageBox.Show(ex.ToString())
        Catch ex As Exception
            ''MsgBox(ex.ToString())
        End Try
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close() '
    End Sub
    Private Sub dgv_Click(sender As Object, e As EventArgs) Handles dgv.Click
        dgv.SelectAll()
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
            row.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
        Next
    End Sub
End Class