﻿Imports System.Data.SqlClient

Public Class Customer

    Dim gender As String

    Sub Reset()
        txtName.Text = ""
        txtMobile.Text = ""
        txtEmail.Text = ""
        cboLocation.ResetText()
        rbFemale.Checked = False
        rbMale.Checked = False
        txtName.Focus()
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
        btnSave.Enabled = True
    End Sub
    Private Sub GetCustomers()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select customerid,name,gender, contactno, email,location from customer order by name asc"
            dadapter = New SqlDataAdapter(query, myconnection)
            dtable = New DataTable()
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of customers found.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                dgv.Rows.Clear()
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    dgv.Rows(i).Cells(0).Value = (item("customerid").ToString())
                    dgv.Rows(i).Cells(1).Value = (item("name").ToString())
                    dgv.Rows(i).Cells(2).Value = item("gender").ToString()
                    dgv.Rows(i).Cells(3).Value = (item("contactno").ToString())
                    dgv.Rows(i).Cells(4).Value = (item("email").ToString())
                    dgv.Rows(i).Cells(5).Value = (item("location").ToString())
                Next
            End If

        Catch ex As SqlException
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "SQL Search Error")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Search Record Error")
        End Try
    End Sub
    Public Sub FillLocation()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            dset = New Data.DataSet()
            dadapter = New SqlDataAdapter()
            dadapter.SelectCommand = New SqlCommand("select id,lname from location order by lname asc", myconnection)
            dset.Clear()
            dadapter.Fill(dset, "location")
            cboLocation.DataSource = dset.Tables("location")
            cboLocation.DisplayMember = "lname"
            cboLocation.ValueMember = "id"
            cboLocation.Refresh()
            cboLocation.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get category")
            'Dbconnection.Close()
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If Len(Trim(txtName.Text)) = 0 Then
            MessageBox.Show("Please enter Customer name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtName.Focus()
            Exit Sub
        End If
        If ((rbMale.Checked = False) And (rbFemale.Checked = False)) Then
            MessageBox.Show("Please select gender", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        If Len(Trim(txtMobile.Text)) = 0 Then
            MessageBox.Show("Please enter mobile or contact number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtMobile.Focus()
            Exit Sub
        End If
      If txtMobile.TextLength < 10 Then
            MessageBox.Show("Mobile number must be 10-digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtMobile.SelectAll()
            Exit Sub
        End If
        Dim st As String = txtMobile.Text.Substring(0, 3)
        If (st <> "024") AndAlso (st <> "054") AndAlso (st <> "055") AndAlso (st <> "027") AndAlso (st <> "057") AndAlso (st <> "026") AndAlso (st <> "020") AndAlso (st <> "050") AndAlso (st <> "023") Then
            MsgBox("Phone or mobile number not correct." & vbCrLf & "Number should be valid mtn/airteltigo/vodafone/glo... Please check", MsgBoxStyle.Information, "Invalid Mobile / Telephone")
            txtMobile.Clear() 'clear the text
            txtMobile.Focus()
            Exit Sub
        End If

        If MessageBox.Show("Do you really want to add this customer record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            SaveRecord()
            ''GetCustomers()
        End If

    End Sub
    Sub SaveRecord()
        Try
            If (rbMale.Checked = True) Then
                gender = rbMale.Text
            End If
            If (rbFemale.Checked = True) Then
                gender = rbFemale.Text
            End If
            'check mobile no exists
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Dim str As New SqlCommand("select contactno from customer where contactno='" & txtMobile.Text & "'", myconnection)
            dreader = str.ExecuteReader()
            If (dreader.Read()) Then
                MsgBox("The mobile or contact number is already registered", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Message")
                dreader.Close()
            End If

            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ConnectDB()
            query = "insert into customer (name,gender,contactno,email,location) values (@d1,@d2,@d3,@d4,@d5)"
            command = New SqlCommand(query, myconnection)
            command.Parameters.AddWithValue("@d1", txtName.Text)
            command.Parameters.AddWithValue("@d2", gender)
            command.Parameters.AddWithValue("@d3", txtMobile.Text)
            command.Parameters.AddWithValue("@d4", txtEmail.Text)
            command.Parameters.AddWithValue("@d5", cboLocation.Text)
            ''Dbconnection.Open()
            command.ExecuteNonQuery()
            AllUserActivities(LogFullName & ", added a new customer with the name: " & txtName.Text & " on " & Date.Now)
            MessageBox.Show("Record saved..", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Reset()
        Catch ex As Exception
            MsgBox(ex.ToString(), , "Save Record Error")
        End Try
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Reset()
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete this customer record?", "Confirm Customer Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                DeleteRecord()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub DeleteRecord()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            command = New SqlCommand("SELECT * FROM customer where customerid=@d1", myconnection)
            command.Parameters.AddWithValue("@d1", Val(txtCID.Text))
            dreader = command.ExecuteReader()
            If (dreader.Read()) Then
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ConnectDB()
                query = "DELETE FROM customer where customerid='" & txtCID.Text & "'"
                command1 = New SqlCommand(query, myconnection)
                ''Dbconnection.Open()
                command1.ExecuteNonQuery()
                AllUserActivities(LogFullName & ", deleted the customer info with name: " & txtName.Text & " on " & DateTime.Now)
                MessageBox.Show("Customer record deleted", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            Else
                MessageBox.Show("No record found to delete", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Information, "Delete Record Error")
        End Try

    End Sub
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If Len(Trim(txtCID.Text)) = 0 Then
            MessageBox.Show("Sorry.. No record found to perform update", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        If ((rbMale.Checked = False) And (rbFemale.Checked = False)) Then
            MessageBox.Show("Please select gender", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        If MessageBox.Show("Do you really want to update (make changes) to this customer record?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            UpdateRecord()
            ''GetCustomers()
        End If
    End Sub
    Private Sub UpdateRecord()
        Try
            If (rbMale.Checked = True) Then
                gender = rbMale.Text
            End If
            If (rbFemale.Checked = True) Then
                gender = rbFemale.Text
            End If
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ConnectDB()
            query = "UPDATE customer SET [name]=@d1, gender@d2, contactno=@d3, email=@d4, location=@d5 where customerid='" & Val(txtCID.Text) & ""
            command1 = New SqlCommand(query, myconnection)
            command1.Parameters.AddWithValue("@d1", txtName.Text)
            command1.Parameters.AddWithValue("@d2", gender)
            command1.Parameters.AddWithValue("@d3", txtMobile.Text)
            command1.Parameters.AddWithValue("@d4", txtEmail.Text)
            command1.Parameters.AddWithValue("@d5", cboLocation.Text)
            ''Dbconnection.Open()
            command1.ExecuteNonQuery()
            AllUserActivities(LogFullName & ", updated the customer info with the name: " & txtName.Text & " on " & Date.Now)
            MessageBox.Show("Record updated..", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Reset()
        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Information, "Record Update Error")
        End Try
    End Sub
    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        GetCustomers()
    End Sub
    Private Sub cboLocation_DropDown(sender As Object, e As EventArgs) Handles cboLocation.DropDown
        ''FillLocation()
    End Sub
    Private Sub txtMobile_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMobile.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Private Sub txtName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtName.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
    Private Sub txtEmail_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEmail.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 45, 46, 64, 95, 127, 48 To 57, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub

    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
            ''row.HeaderCell.Style.Alignment = DataGridViewContentAlignment.NotSet
        Next
    End Sub

    Private Sub dgv_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellDoubleClick
        Try
            txtCID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            txtMobile.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value
            txtEmail.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value
            cboLocation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value
            If dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value = "Male" Then
                rbMale.Checked = True
            ElseIf dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value = "Female" Then
                rbFemale.Checked = True
            End If
            btnSave.Enabled = False
            btnDelete.Enabled = True
            btnUpdate.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Customer_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Reset()
    End Sub
    Private Sub Customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub
    Private Sub dgv_Click(sender As Object, e As EventArgs) Handles dgv.Click
        dgv.SelectAll()
    End Sub

End Class