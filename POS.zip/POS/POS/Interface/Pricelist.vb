﻿Imports System.Data.SqlClient

Public Class Pricelist
    Private Sub Fetch_Product_Price_List()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "select productid,pname,punitprice from product order by pname"
            command = New SqlCommand(query, myconnection)
            dtable = New DataTable()
            dadapter = New SqlDataAdapter(command)
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of available products found in the system", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    'get products info 
                    dgv.Rows(i).Cells(0).Value = item("productid").ToString()
                    dgv.Rows(i).Cells(1).Value = item("pname").ToString()
                    dgv.Rows(i).Cells(2).Value = "GH¢" & Format(item("punitprice"), "#,##0.00")
                Next
            End If
        Catch ex As SqlException
            MessageBox.Show(ex.ToString())
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

    Private Sub Pricelist_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        dgv.Rows.Clear()
    End Sub

    Private Sub Pricelist_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Fetch_Product_Price_List()
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub
End Class