﻿Imports System.Data.SqlClient

Public Class Product
    Dim pname, pcode As String
    Sub ClearFormData()
        txtPID.Text = ""
        txtCostPrice.Text = ""
        txtCode.Text = ""
        txtName.Text = ""
        txtSellingPrice.Text = ""
        txtReorder.Text = ""
        txtDescription.Text = ""
        cboCategory.ResetText()
        btnSave.Enabled = True
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub
    Sub Reset()
        txtPID.Text = ""
        txtCode.Text = ""
        txtName.Text = ""
        txtCostPrice.Text = ""
        txtSellingPrice.Text = ""
        txtReorder.Text = ""
        txtDescription.Text = ""
        cboCategory.ResetText()
        txtCode.Focus()
        btnSave.Enabled = True
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
        GetProducts()
    End Sub
    Private Sub GetProducts()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select productid,pcode,pname, pcatid, pcostprice,punitprice,preorderlevel,description from product order by pname asc"
            dadapter = New SqlDataAdapter(query, myconnection)
            dtable = New DataTable()
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of products found.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                dgv.Rows.Clear()
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    dgv.Rows(i).Cells(0).Value = (item("productid").ToString())
                    dgv.Rows(i).Cells(1).Value = (item("pcode").ToString())
                    dgv.Rows(i).Cells(2).Value = item("pname").ToString()
                    dgv.Rows(i).Cells(3).Value = (item("pcatid").ToString())
                    dgv.Rows(i).Cells(4).Value = Format(item("pcostprice"), "#,#0.00")
                    dgv.Rows(i).Cells(5).Value = Format(item("punitprice"), "#,#0.00")
                    dgv.Rows(i).Cells(6).Value = (item("preorderlevel"))
                    dgv.Rows(i).Cells(7).Value = (item("description").ToString())
                Next
            End If

        Catch ex As SqlException
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "SQL Error")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Sale System Error")
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If Len(Trim(txtCode.Text)) = 0 Then
            MessageBox.Show("Please enter product or item code", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtCode.Focus()
            Exit Sub
        End If
        If Len(Trim(txtName.Text)) = 0 Then
            MessageBox.Show("Please enter product or item name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtName.Focus()
            Exit Sub
        End If
        If (cboCategory.Text = "") Then
            MessageBox.Show("Please select product category", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboCategory.Focus()
            Exit Sub
        End If
        If Len(Trim(txtCostPrice.Text)) = 0 Then
            MessageBox.Show("Please enter product cost price", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtCostPrice.Focus()
            Exit Sub
        End If
        If Len(Trim(txtSellingPrice.Text)) = 0 Then
            MessageBox.Show("Please enter product selling price", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtSellingPrice.Focus()
            Exit Sub
        End If
        If Len(Trim(txtReorder.Text)) = 0 Then
            MessageBox.Show("Please enter re-order point", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtReorder.Focus()
            Exit Sub
        End If

        If MsgBox("Are you sure you want to add this new product?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = MsgBoxResult.Yes Then
            Try
                'check product code exists
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                Const sql As String = "select RTRIM(pcode) from product where pcode=@d1"
                command = New SqlCommand(sql)
                command.Parameters.AddWithValue("@d1", txtCode.Text)
                command.Connection = myconnection
                dreader = command.ExecuteReader()
                If dreader.Read() Then
                    dreader.Close()
                    MessageBox.Show("A product with the code '" & txtCode.Text & "' is already added", "Product Code Exists", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                    Exit Sub
                End If
                'check product name exists
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                Const check As String = "select RTRIM(pname) from product where pname=@d1"
                command = New SqlCommand(check)
                command.Parameters.AddWithValue("@d1", txtName.Text)
                command.Connection = myconnection
                dreader = command.ExecuteReader()
                If dreader.Read() Then
                    dreader.Close()
                    MessageBox.Show("A product with the name '" & txtName.Text & "' is already added", "Product Name Exists", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                    Exit Sub
                End If

                'proceed to save record
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                query = "insert into product(pcode, pname, pcatid, pcostprice, punitprice,preorderlevel,description) VALUES (@d1,@d2,@d3,@d4,@d5,@d6,@d7)"
                command = New SqlCommand(query, myconnection)
                command.Parameters.AddWithValue("@d1", txtCode.Text)
                command.Parameters.AddWithValue("@d2", txtName.Text)
                command.Parameters.AddWithValue("@d3", cboCategory.SelectedValue)
                command.Parameters.AddWithValue("@d4", (Val(txtCostPrice.Text)))
                command.Parameters.AddWithValue("@d5", (Val(txtSellingPrice.Text)))
                command.Parameters.AddWithValue("@d6", (Val(txtReorder.Text)))
                command.Parameters.AddWithValue("@d7", (txtDescription.Text))
                command.ExecuteNonQuery()
                AllUserActivities(LogFullName + ", added a new product with name: " & txtName.Text & " and product code '" & txtCode.Text & "' on " & DateTime.Now)
                MessageBox.Show("Record saved", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "Sale System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
    Public Sub Fillcategory()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            dset = New Data.DataSet()
            dadapter = New SqlDataAdapter()
            dadapter.SelectCommand = New SqlCommand("select id,catname from category order by catname asc", myconnection)
            dset.Clear()
            dadapter.Fill(dset, "category")
            cboCategory.DataSource = dset.Tables("category")
            cboCategory.DisplayMember = "catname"
            cboCategory.ValueMember = "id"
            cboCategory.Refresh()
            cboCategory.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.Message(), "Sale System Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            myconnection.Close()
        End Try
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Reset()
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        GetProducts()
    End Sub
    Sub DeleteRecord()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Dim chk As String = "select * from product where productid='" & txtPID.Text & ""
            Dim com As New SqlCommand(chk, myconnection)
            dreader = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dreader.Read() Then  'if product is found in database, proceed to delete product record
                dreader.Close()
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                query = "delete from product where productid='" & Val(txtPID.Text) & "'"
                command = New SqlCommand(query, myconnection)
                command.ExecuteNonQuery()
                AllUserActivities(LogFullName + ", deleted the product: " & pname & " with the Code: " & pcode & " on " & Date.Now)
                MessageBox.Show("Record successfully deleted", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            Else
                MessageBox.Show("Product record not found. Could not complete the process..", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Exclamation, "Sale System Error")
        End Try

    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Permanently delete '" & txtName.Text & "' history from the items/products and current stock lists." & vbCrLf & "Do you want to continue?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1) = MsgBoxResult.Yes Then
                DeleteRecord()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Sub UpdateRecord()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Dim chk As String = "select * from product where productid='" & Val(txtPID.Text) & "'"
            Dim com As New SqlCommand(chk, myconnection)
            dreader = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dreader.Read() Then  'if product is found in database, proceed to update product record
                dreader.Close()
                query = "update product set pcode=@d1, pname=@d2, pcatid=@d3, pcostprice=@d4, punitprice=@d5, preorderlevel=@d6, description=@d7 where productid=@productid"
                command = New SqlCommand(query, myconnection)
                command.Parameters.AddWithValue("@d1", txtCode.Text)
                command.Parameters.AddWithValue("@d2", txtName.Text)
                command.Parameters.AddWithValue("@d3", cboCategory.SelectedValue)
                command.Parameters.AddWithValue("@d4", Val(txtCostPrice.Text))
                command.Parameters.AddWithValue("@d5", Val(txtSellingPrice.Text))
                command.Parameters.AddWithValue("@d6", Val(txtReorder.Text))
                command.Parameters.AddWithValue("@d7", txtDescription.Text)
                command.Parameters.AddWithValue("@productid", Val(txtPID.Text))
                'command.Parameters.AddWithValue("@productid", dgv.SelectedRows(0).Cells(0).Value)
                ConnectDB()
                command.ExecuteNonQuery()
                AllUserActivities(LogFullName + ", updated the product with name: " & pname & ", and code: " & pcode & " on " & Date.Now)
                MessageBox.Show("Record successfully updated.", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            Else
                MessageBox.Show("Product record not found. Could not complete the process.. ", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message(), "Sale System Error")
        End Try
    End Sub
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            If MessageBox.Show("Do you really want to update this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = MsgBoxResult.Yes Then
                UpdateRecord()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub cboCategory_DropDown(sender As Object, e As EventArgs) Handles cboCategory.DropDown
        Fillcategory()
    End Sub
   Private Sub txtCostPrice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCostPrice.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Private Sub txtReorder_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtReorder.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Private Sub txtSellingPrice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSellingPrice.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Private Sub txtCode_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCode.KeyPress
        'reject special characters
        Select Case Asc(e.KeyChar)
            Case 32, 33 To 44, 46, 58 To 64, 91 To 96, 123 To 126
                e.Handled = True
            Case Else
                e.Handled = False
        End Select
    End Sub
    Private Sub txtName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtName.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub
    Private Sub dgv_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellDoubleClick
        Try
            txtPID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtCode.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            txtName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
            txtCostPrice.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value
            txtSellingPrice.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value
            txtReorder.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value
            txtDescription.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(7).Value
            pname = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
            pcode = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            btnSave.Enabled = False
            btnDelete.Enabled = True
            btnUpdate.Enabled = True

            'get product category
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            Dim cmd As New SqlCommand("select catname from category where id='" & dgv.SelectedRows(0).Cells(3).Value & "'", Dbconnection)
            dreader = cmd.ExecuteReader()
            If dreader.Read() Then
                cboCategory.Text = dreader(0).ToString()
                dreader.Close()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString(), , "Error")
        End Try
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub
    Private Sub Product_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        ''ClearFormData()
        Reset()
    End Sub
    Private Sub Product_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub

End Class