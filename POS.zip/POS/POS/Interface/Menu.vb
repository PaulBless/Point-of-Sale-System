﻿Imports System.Windows.Forms
Imports System.Data.SqlClient
Imports POS.My
Imports System.Configuration.ConfigurationSettings

Public Class Menu
    Dim second, reorder As Integer
    Private m_ChildFormNumber As Integer
    Private Filename As String
    Dim objdlg As New SaveFileDialog

    Private Declare Function LockWorkStation Lib "user32.dll" () As Long    'invoke system32 lock function

    Private Sub Close_Any_Opened_ChildForm()
        For Each frm As Form In Me.MdiChildren
            If frm.Name = "Tygen Sale System" Then
            Else
                frm.Close()
            End If
        Next
    End Sub
    Private Sub btnStaff_Click(sender As Object, e As EventArgs) Handles btnStaff.Click
        Dim frm As New Staff
        Close_Any_Opened_ChildForm()
        Try
            If Application.OpenForms.OfType(Of Staff).Any Then
                Application.OpenForms.Item("Staff").Activate()
                Exit Sub
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnProduct_Click(sender As Object, e As EventArgs) Handles btnProduct.Click
        Dim frm As New Product
        Close_Any_Opened_ChildForm()
        Try
            If Application.OpenForms.OfType(Of Product).Any Then
                Application.OpenForms.Item("Product").Activate()
                Exit Sub
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnShopping_Click(sender As Object, e As EventArgs) Handles btnShopping.Click
        Dim frm As New Sale
        Close_Any_Opened_ChildForm()
        Try
            If Application.OpenForms.OfType(Of Sale).Any Then
                Application.OpenForms.Item("Sale").Activate()
                Exit Sub
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnSupplier_Click(sender As Object, e As EventArgs) Handles btnSupplier.Click
        Dim frm As New Supplier
        Close_Any_Opened_ChildForm()
        Try
            If Application.OpenForms.OfType(Of Supplier).Any Then
                Application.OpenForms.Item("Supplier").Activate()
                Exit Sub
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnStockEntry_Click(sender As Object, e As EventArgs) Handles btnStockEntry.Click
        Dim frm As New Stock
        Close_Any_Opened_ChildForm()
        Try
            If Application.OpenForms.OfType(Of Stock).Any Then
                Application.OpenForms.Item("Stock").Activate()
                Exit Sub
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnStockIn_Click(sender As Object, e As EventArgs) Handles btnStockIn.Click
        Dim frm As New Stockin
        Close_Any_Opened_ChildForm()
        Try
            If Application.OpenForms.OfType(Of Stockin).Any Then
                Application.OpenForms.Item("Stockin").Activate()
                Exit Sub
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnCategory_Click(sender As Object, e As EventArgs) Handles btnCategory.Click
        Category.ShowDialog()
    End Sub
    Private Sub btnRegistration_Click(sender As Object, e As EventArgs) Handles btnRegistration.Click
        Account.ShowDialog()
    End Sub
    Private Sub btnCustomer_Click(sender As Object, e As EventArgs) Handles btnCustomer.Click
        Dim frm As New Customer
        Close_Any_Opened_ChildForm()
        Try
            If Application.OpenForms.OfType(Of Customer).Any Then
                Application.OpenForms.Item("Customer").Activate()
                Exit Sub
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub PriceListToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles btnPriceList.Click
        Pricelist.ShowDialog()
    End Sub
    Private Sub btnCalculator_Click(sender As Object, e As EventArgs) Handles btnCalculator.Click
        Try
            Shell("Calc.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnNotepad_Click(sender As Object, e As EventArgs) Handles btnNotepad.Click
        Try
            Process.Start("Notepad.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnTaskManager_Click(sender As Object, e As EventArgs) Handles btnTaskManager.Click
        Try
            Process.Start("TaskMgr.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub DisplayNotify()
        'notifyicon on form start
        NotifyIcon1.Icon = SystemIcons.Application
        NotifyIcon1.BalloonTipText = "Tygen Point of Sale System is running.." + vbCrLf + "Developed by Jecmas"
        NotifyIcon1.BalloonTipTitle = "Tygen Sale System"
        NotifyIcon1.ShowBalloonTip(2000)
        NotifyIcon1.Icon = Me.Icon
    End Sub
    Private Sub Menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetProductRecords()
        ''DisplayNotify()
        SetTimer()
        ''UserLogFunction(LogUsername, "Successfull login into the system")
    End Sub
    Public Sub GetProductRecords()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "SELECT RTRIM(product.pcode), RTRIM(product.pname), RTRIM(product.pcostprice), RTRIM(product.punitprice), RTRIM(temp_stock.stocklevel) FROM product, temp_stock where product.productid=temp_stock.prodid and stocklevel > 0 order by pname"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dreader.Read() = True)
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4))
            End While
            For Each r As DataGridViewRow In Me.dgv.Rows
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                Dim ct As String = "SELECT preorderlevel FROM product WHERE pcode=@d1"
                command1 = New SqlCommand(ct)
                command1.Connection = myconnection
                command1.Parameters.AddWithValue("@d1", r.Cells(0).Value.ToString())
                dreader = command1.ExecuteReader()
                If (dreader.Read()) Then
                    reorder = dreader(0)
                    If (r.Cells(4).Value < reorder) Then
                        r.DefaultCellStyle.BackColor = Color.Red 'item qty left < reorder level
                    End If
                    If (r.Cells(4).Value = reorder) Then
                        r.DefaultCellStyle.BackColor = Color.Green 'item qty left = reorder level
                    End If
                End If
            Next
            DisconnectDB()
            dgv.ClearSelection()

        Catch ex As Exception
            MessageBox.Show(ex.Message(), "Sale System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'display date with running time
        lblDateTime.Text = DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToLongTimeString()
    End Sub
    Sub SetTimer()
        Timer2.Interval = 60000    '60seconds interval
        Timer2.Start()
    End Sub
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        second += 1
        If second = 5 Then  'trigger at 5minutes
            Timer2.Stop()
            For Each row As DataGridViewRow In dgv.Rows
                If row.DefaultCellStyle.BackColor = Color.Red Then
                    NotifyIcon1.Icon = SystemIcons.Information
                    NotifyIcon1.BalloonTipText = "The product: '" + row.Cells(1).Value + "' has only '" + row.Cells(4).Value + "' stock available;" + vbNewLine + " Item is getting finished!"
                    NotifyIcon1.BalloonTipTitle = "POS Message"
                    NotifyIcon1.ShowBalloonTip(2000)
                End If
                If row.DefaultCellStyle.BackColor = Color.Green Then
                    NotifyIcon1.Icon = SystemIcons.Information
                    NotifyIcon1.BalloonTipText = "The product: '" + row.Cells(1).Value + "' has reach stock limit!" + vbNewLine + "Re-order Level: " + reorder.ToString()
                    NotifyIcon1.BalloonTipTitle = "Stock Limit Message"
                    NotifyIcon1.ShowBalloonTip(2000)
                End If
            Next
            second = 0
        End If
    End Sub

    Private Sub btnCustomers_Click(sender As Object, e As EventArgs) Handles btnCustomers.Click
        CustomerRecord.ShowDialog()
    End Sub
    Private Sub btnSuppliers_Click(sender As Object, e As EventArgs) Handles btnSuppliers.Click
        SupplierRecord.ShowDialog()
    End Sub
    Private Sub btnProducts_Click(sender As Object, e As EventArgs) Handles btnProducts.Click
        ProductRecord.ShowDialog()
    End Sub
    Private Sub btnStocks_Click(sender As Object, e As EventArgs) Handles btnStocks.Click
        ''StockRecord.ShowDialog()
        StockRecord1.ShowDialog()
    End Sub
    Private Sub btnSales_Click(sender As Object, e As EventArgs) Handles btnSales.Click
        SaleRecord.ShowDialog()
    End Sub
    Private Sub btnStaffs_Click(sender As Object, e As EventArgs) Handles btnStaffs.Click
        StaffRecord.ShowDialog()
    End Sub
    Private Sub btnExpenses_Click(sender As Object, e As EventArgs) Handles btnExpenses.Click
        ExpenseRecord.ShowDialog()
    End Sub
    Private Sub btnCompany_Click(sender As Object, e As EventArgs) Handles btnCompany.Click
        Company.ShowDialog()
    End Sub
    Private Sub LocationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles btnLocations.Click
        Locations.ShowDialog()
    End Sub

    Private Sub Menu_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated

    End Sub

    Private Sub btnSystemLogs_Click(sender As Object, e As EventArgs) Handles btnSystemLogs.Click
        Logs.ShowDialog()
    End Sub
    Sub LogOut()
        Dim st As String = "Successfully logged out from system"
        UserLogFunction(LogUsername, st)
        Login.Show()
        Login.UsernameTextBox.Text = ""
        Login.PasswordTextBox.Text = ""
        Login.UsernameTextBox.Focus()
        Me.Close()
    End Sub
    Public Sub OpenLoginForm()
        Application.Run(New Login)
    End Sub
    Sub LogOff()
        Dim st As String = "Successfully logged out from system"
        UserLogFunction(LogUsername, st)
        Dim fm As New Login
        fm.Show()
        fm.UsernameTextBox.Text = ""
        fm.PasswordTextBox.Text = ""
        fm.UsernameTextBox.Focus()
        Me.Close()
    End Sub
    Sub BackupDb()
        Try
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            Dim destdir As String = "Backup of Tygen Database on  " & DateTime.Now.ToString("dd-MM-yyyy_HH-mm-ss") & ".bak"
            objdlg.FileName = destdir
            objdlg.ShowDialog()
            Filename = objdlg.FileName
            Cursor = Cursors.WaitCursor
            Timer3.Enabled = True
            Dim cb As String = "backup database POS to disk='" & Filename & "'with init,stats=10"
            command = New SqlCommand(cb, Dbconnection)
            command.ExecuteReader()
            Dbconnection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error at Backup", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Cursor = Cursors.Default
        Timer3.Enabled = False
    End Sub
    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Try
            If MessageBox.Show("Do you really want to logout from Tygen Sale System?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                LogOff()
            End If
            ''If MessageBox.Show("Do you really want to logout from Tygen Sale System?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            ''    If MessageBox.Show("Do you want to backup database before logout?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            ''        BackupDb()
            ''        Close_Any_Opened_ChildForm()
            ''        LogOut()
            ''    Else
            ''        Close_Any_Opened_ChildForm()
            ''        LogOut()
            ''    End If
            ''End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Logout Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnBackupDB_Click(sender As Object, e As EventArgs) Handles btnBackupDB.Click
        Try
            BackupDb()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnChangePassword_Click(sender As Object, e As EventArgs) Handles btnChangePassword.Click
        ChangePassword.ShowDialog()
    End Sub
    Private Sub btnDbConfigure_Click(sender As Object, e As EventArgs) Handles btnDbConfigure.Click
        Database.ShowDialog()
    End Sub
    Private Sub btnProfile_Click(sender As Object, e As EventArgs) Handles btnProfile.Click
        Profile.ShowDialog()
    End Sub

    Private Sub btnLockPC_Click(sender As Object, e As EventArgs) Handles btnLockPC.Click
        If MsgBox("Do you want to lock this workstation or PC?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = DialogResult.Yes Then
            LockWorkStation()
        End If
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close_Any_Opened_ChildForm()
        LogOff()
        AllUserActivities(LogFullName + ", exited from the Tygen Sale System at :" + DateTime.Now.ToLongDateString())
        Application.Exit()
    End Sub
    Private Sub btnSalesReport_Click(sender As Object, e As EventArgs) Handles btnSalesReport.Click
        SalesReport.ShowDialog()
    End Sub

    Private Sub btnNewExpense_Click(sender As Object, e As EventArgs) Handles btnNewExpense.Click
        Dim frm As New Expense
        Close_Any_Opened_ChildForm()
        Try
            If Application.OpenForms.OfType(Of Expense).Any Then
                Application.OpenForms.Item("Expense").Activate()
                Exit Sub
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub lblwelcome_Click(sender As Object, e As EventArgs) Handles lblwelcome.Click
        'MsgBox(GetSetting(My.Application.Info.ProductName, "DBSection", "DB_IP", My.Computer.Name) & vbNewLine & GetSetting(My.Application.Info.ProductName, "DBSection", "DB_Name", dbConString))
    End Sub

    Private Sub AnimationLabel_Click(sender As Object, e As EventArgs) Handles AnimationLabel.Click
        Call ConnectDB()
    End Sub

    Private Sub ToolStripMenuItem6_Click(sender As Object, e As EventArgs) Handles btnUserActivities.Click
        MsgBox(My.Application.Info.AssemblyName)

    End Sub

    Private Sub ColorThemeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ColorThemeToolStripMenuItem.Click
        MessageBox.Show(GetSetting(Application.ProductName, "DBSection", "DB_Name", MySettings.Default.POSConnectionString))
    End Sub
    Private Sub btnDailySales_Click(sender As Object, e As EventArgs) Handles btnDailySales.Click
        DailySales.ShowDialog()
    End Sub
    Private Sub btnStockReport_Click(sender As Object, e As EventArgs) Handles btnStockReport.Click
        StocksReport.ShowDialog()
    End Sub
    Private Sub btnStocksIn_Click(sender As Object, e As EventArgs) Handles btnStocksIn.Click
        StocksReport.ShowDialog()
    End Sub
    Private Sub btnStockOutReport_Click(sender As Object, e As EventArgs) Handles btnStockOutReport.Click
        SalesReport.ShowDialog()
    End Sub

    Private Sub btnHelpContent_Click(sender As Object, e As EventArgs) Handles btnHelpContent.Click
        Call CommitDbSettings()
        Call SetDbSettings()
    End Sub
End Class
