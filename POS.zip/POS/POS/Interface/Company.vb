﻿Imports System.Data.SqlClient
Imports System.IO

Public Class Company

    Private Sub Company_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub txtEmail_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEmail.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 45, 46, 64, 95, 127, 48 To 57, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub
    Private Sub txtLocation_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtLocation.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtName.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
    Private Sub txtTelephone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTelephone.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Public Sub Getdata()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            command = New SqlCommand("SELECT RTRIM(id), RTRIM(name), RTRIM(telephone), RTRIM(email), RTRIM(regno), RTRIM(bop) from company", myconnection)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dreader.Read() = True)
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5))
            End While
            Dbconnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If txtName.Text = "" Then
            MessageBox.Show("Please enter company name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtName.Focus()
            Return
        End If
        If txtTelephone.Text = "" Then
            MessageBox.Show("Please enter telephone number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtTelephone.Focus()
            Return
        End If
        If txtLocation.Text = "" Then
            MessageBox.Show("Please enter the location of business.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtLocation.Focus()
            Return
        End If

        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Dim cb As String = "Update company set name=@d1, telephone=@d2, location=@d3, email=@d4, regno=@d5, bop=@d6 where id=" & dgv.SelectedRows(0).Cells(0).Value & ""
            command = New SqlCommand(cb)
            command.Connection = myconnection
            command.Parameters.AddWithValue("@d1", txtName.Text)
            command.Parameters.AddWithValue("@d2", txtTelephone.Text)
            command.Parameters.AddWithValue("@d3", txtLocation.Text)
            command.Parameters.AddWithValue("@d4", txtEmail.Text)
            command.Parameters.AddWithValue("@d5", txtRegNo.Text)
            command.Parameters.AddWithValue("@d6", txtBOP.Text)
            command.ExecuteNonQuery()
            Dbconnection.Close()
            Dim st As String = ", updated the company '" & txtName.Text & "' information or profile on " + DateTime.Now
            AllUserActivities(LogFullName + st)
            MessageBox.Show("Record updated", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnUpdate.Enabled = False
            Getdata()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub Reset()
        txtName.Text = ""
        txtEmail.Text = ""
        txtBOP.Text = ""
        txtLocation.Text = ""
        txtRegNo.Text = ""
        txtTelephone.Text = ""
        dgv.Rows.Clear()
        txtName.Focus()
        btnSave.Enabled = True
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
        Getdata()
    End Sub
    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Reset()
    End Sub
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If txtName.Text = "" Then
            MessageBox.Show("Please enter company name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtName.Focus()
            Return
        End If
        If txtTelephone.Text = "" Then
            MessageBox.Show("Please enter telephone number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtTelephone.Focus()
            Return
        End If
        If txtLocation.Text = "" Then
            MessageBox.Show("Please enter location of business", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtLocation.Focus()
            Return
        End If

        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Dim ct As String = "select * from company"
            command = New SqlCommand(ct)
            command.Connection = myconnection
            dreader = command.ExecuteReader()
            If (dreader.Read() = True) Then
                dreader.Close()
                MessageBox.Show("Record Already Exists" & vbCrLf & " please update the company information or profile", "Profile Exists", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                Dim cb As String = "insert into company(name, telephone, location, email, regno, bop) VALUES (@d1,@d2,@d3,@d4,@d5,@d6)"
                command = New SqlCommand(cb)
                command.Connection = myconnection
                command.Parameters.AddWithValue("@d1", txtName.Text)
                command.Parameters.AddWithValue("@d2", txtTelephone.Text)
                command.Parameters.AddWithValue("@d3", txtLocation.Text)
                command.Parameters.AddWithValue("@d4", txtEmail.Text)
                command.Parameters.AddWithValue("@d5", txtRegNo.Text)
                command.Parameters.AddWithValue("@d6", txtBOP.Text)
                command.ExecuteNonQuery()
                Dim st As String = ", added the company '" & txtName.Text & "' information"
                AllUserActivities(LogFullName + st)
                MessageBox.Show("Successfully saved", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                btnSave.Enabled = False
                Reset()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Private Sub DeleteRecord()
        Try
            Dim RowsAffected As Integer = 0
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Dim cq As String = "delete from company where id=@d1"
            command = New SqlCommand(cq)
            command.Connection = myconnection
            command.Parameters.AddWithValue("@d1", dgv.SelectedRows(0).Cells(0).Value)
            RowsAffected = command.ExecuteNonQuery()
            If RowsAffected > 0 Then
                Dim st As String = ", deleted the company '" & txtName.Text & "' on " + DateTime.Now
                AllUserActivities(LogFullName + st)
                MessageBox.Show("Record deleted", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            Else
                MessageBox.Show("No Record found to complete the delete process", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
            DeleteRecord()
        End If
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub
End Class