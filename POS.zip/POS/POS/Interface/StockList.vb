﻿Imports System.Data.SqlClient

Public Class StockList

    Public Property CurrentActiveForm As Stock
    Sub FetchStockList()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            ''query = "select distinct stid,stockid,datein, RTRIM(supplier.supplierid), supplier.supplier_id, name,grandtotal, totalpayment,paymentdue,payduedate from stock,supplier,stock_payment where supplier.supplierid=stock_payment.supplier_id"
            query = "select distinct stock.stid, stock.stockid, stock.datein, supplier.supplierid, supplier.supplier_id, supplier.name, supplier.contactno, stock_payment.grandtotal, stock_payment.totalpayment, stock_payment.paymentdue, stock_payment.payduedate from stock join stock_payment on stock.stid=stock_payment.stock_id join supplier on stock_payment.supplier_id=supplier.supplierid and stock.datein=stock_payment.stockdate"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader()
            dgv.Rows.Clear()
            While dreader.Read()
                dgv.Rows.Add(dreader(0), dreader(1), Format(dreader(2), "dd/MM/yyyy"), dreader(3), dreader(4), dreader(5), dreader(6), Format(dreader(7), "#,##."), Format(dreader(8), "#,##."), Format(dreader(9), "#,##."), Format(dreader(10), "dd/MM/yyyy"))
            End While
           
        Catch ex As SqlException
            MsgBox(ex.Message(), MsgBoxStyle.Information, "Error")
        Catch ex As Exception
            MsgBox(ex.Message(), , "Fetch Stock Error")
        End Try
    End Sub

    Private Sub dgv_Click(sender As Object, e As EventArgs) Handles dgv.Click
        Try
            dgv.SelectAll()
            ''dtp.Text = dgv.SelectedRows(0).Cells(2).Value
            dtp.Value = dgv.SelectedRows(0).Cells(2).Value
        Catch ex As Exception
            ''MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub dgv_MouseClick(sender As Object, e As MouseEventArgs) Handles dgv.MouseClick
        ''Try
        ''    If dgv.Rows.Count > 0 Then
        ''        Dim dr As DataGridViewRow = dgv.SelectedRows(0)
        ''        CurrentActiveForm.Show()
        ''        CurrentActiveForm.Activate()
        ''        CurrentActiveForm.txtSt_Id.Text = dr.Cells(0).Value
        ''        CurrentActiveForm.txtStockID.Text = dr.Cells(1).Value.ToString()
        ''        CurrentActiveForm.dtpStockDate.Text = dr.Cells(2).Value.ToString()
        ''        CurrentActiveForm.txtSID.Text = dr.Cells(3).Value
        ''        CurrentActiveForm.txtSup_ID.Text = dr.Cells(4).Value.ToString()
        ''        CurrentActiveForm.txtSupplierName.Text = dr.Cells(5).Value.ToString()
        ''        CurrentActiveForm.txtContact.Text = dr.Cells(6).Value
        ''        CurrentActiveForm.txtGrandTotal.Text = dr.Cells(7).Value
        ''        CurrentActiveForm.txtPaymentTotal.Text = dr.Cells(8).Value
        ''        If Not dr.Cells(9).Value = String.Empty Then
        ''            CurrentActiveForm.txtPaymentDue.Text = dr.Cells(9).Value
        ''        Else
        ''            CurrentActiveForm.txtPaymentDue.Text = "0"
        ''        End If
        ''        CurrentActiveForm.btnSave.Enabled = False
        ''        CurrentActiveForm.btnUpdate.Enabled = True
        ''        CurrentActiveForm.btnAdd.Enabled = False
        ''        If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
        ''        Dbconnection.Open()
        ''        'Dim sql As String = "SELECT DISTINCT productid,RTRIM(product.pcode),RTRIM(pname),RTRIM(quantity),RTRIM(price),RTRIM(totalamount) from product, stock, stock_payment where product.productid=stock.product_id and stock_payment.stock_id=stock.stid and stid=" & dr.Cells(0).Value & ""
        ''        Dim sql As String = "SELECT product.productid, product.pcode, product.pname, stock.quantity, stock.price, stock.totalamount from product join stock on product.productid=stock.product_id where stock.stockid='" & dr.Cells(1).Value & "' and stock.datein=@d1"
        ''        command = New SqlCommand(sql, Dbconnection)
        ''        command.Parameters.Add("d1", SqlDbType.Date).Value = dtp.Value
        ''        dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
        ''        CurrentActiveForm.dgv.Rows.Clear()
        ''        If dreader.HasRows = True Then
        ''            While (dreader.Read())
        ''                CurrentActiveForm.dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), Format(dreader(4), "#,##0."), Format(dreader(5), "#,##0."))
        ''            End While
        ''        End If
        ''        Me.Close()
        ''    End If
        ''Catch ex As Exception
        ''    MsgBox(ex.ToString(), , "Error")
        ''End Try
    End Sub
    Private Sub dgv_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles dgv.MouseDoubleClick
        Try
            If dgv.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgv.SelectedRows(0)
                CurrentActiveForm.Show()
                CurrentActiveForm.Activate()
                CurrentActiveForm.txtSt_Id.Text = dr.Cells(0).Value
                CurrentActiveForm.txtStockID.Text = dr.Cells(1).Value.ToString()
                CurrentActiveForm.dtpStockDate.Text = dr.Cells(2).Value.ToString()
                CurrentActiveForm.txtSID.Text = dr.Cells(3).Value
                CurrentActiveForm.txtSup_ID.Text = dr.Cells(4).Value.ToString()
                CurrentActiveForm.txtSupplierName.Text = dr.Cells(5).Value.ToString()
                CurrentActiveForm.txtContact.Text = dr.Cells(6).Value
                CurrentActiveForm.txtGrandTotal.Text = dr.Cells(7).Value
                CurrentActiveForm.txtPaymentTotal.Text = dr.Cells(8).Value
                If Not dr.Cells(9).Value = String.Empty Then
                    CurrentActiveForm.txtPaymentDue.Text = dr.Cells(9).Value
                Else
                    CurrentActiveForm.txtPaymentDue.Text = "0"
                End If
                CurrentActiveForm.btnSave.Enabled = False
                CurrentActiveForm.btnUpdate.Enabled = True
                CurrentActiveForm.btnAdd.Enabled = False
                If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                Dbconnection.Open()
                'Dim sql As String = "SELECT DISTINCT productid,RTRIM(product.pcode),RTRIM(pname),RTRIM(quantity),RTRIM(price),RTRIM(totalamount) from product, stock, stock_payment where product.productid=stock.product_id and stock_payment.stock_id=stock.stid and stid=" & dr.Cells(0).Value & ""
                Dim sql As String = "SELECT product.productid, product.pcode, product.pname, stock.quantity, stock.price, stock.totalamount from product join stock on product.productid=stock.product_id where stock.stockid='" & dr.Cells(1).Value & "' and stock.datein=@d1"
                command = New SqlCommand(sql, Dbconnection)
                command.Parameters.Add("d1", SqlDbType.Date).Value = dtp.Value
                dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
                CurrentActiveForm.dgv.Rows.Clear()
                If dreader.HasRows = True Then
                    While (dreader.Read())
                        CurrentActiveForm.dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), Format(dreader(4), "#,##0."), Format(dreader(5), "#,##0."))
                    End While
                End If
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString(), , "Error")
        End Try
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub
    Private Sub GetStockList()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            'query = "select distinct stock.stid, stock.stockid, stock.datein, supplier.supplierid, supplier.supplier_id, supplier.name, supplier.contactno, stock_payment.grandtotal, stock_payment.totalpayment, stock_payment.paymentdue, stock_payment.payduedate from stock join stock_payment on stock.stid=stock_payment.stock_id join supplier on stock_payment.supplier_id=supplier.supplierid and stock.datein=stock_payment.stockdate"
            query = "select stid,stockid,datein, RTRIM(supplier.supplierid), supplier.supplier_id, name,grandtotal, totalpayment,paymentdue,payduedate from stock,supplier,stock_payment where supplier.supplierid=stock_payment.supplier_id"
            command = New SqlCommand(query, myconnection)
            dtable = New DataTable()
            dadapter = New SqlDataAdapter(command)
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("Sorry... No list record of stocking found", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    'get products info 
                    dgv.Rows(i).Cells(0).Value = (item("stid").ToString())
                    dgv.Rows(i).Cells(1).Value = (item("stockid").ToString())
                    dgv.Rows(i).Cells(2).Value = (item("datein").ToString())
                    dgv.Rows(i).Cells(3).Value = (item("supplierid"))
                    dgv.Rows(i).Cells(4).Value = (item("supplier_id".ToString()))
                    dgv.Rows(i).Cells(5).Value = (item("name").ToString())
                    dgv.Rows(i).Cells(6).Value = "Gh¢" + Format(item("grandtotal"), "#,##0.00")
                    dgv.Rows(i).Cells(7).Value = "Gh¢" + Format(item("totalpayment"), "#,##0.00")
                    dgv.Rows(i).Cells(8).Value = "Gh¢" + Format(item("paymentdue"), "#,##0.00")
                    dgv.Rows(i).Cells(9).Value = (item("payduedate").ToString())
                Next
            End If
        Catch ex As SqlException
            MessageBox.Show(ex.ToString())
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub
    Sub Reset()
        searchName.Text = ""
        searchDate.Text = Now
        dgv.Rows.Clear()
        dgv.Refresh()
    End Sub
    Private Sub StockList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ''FetchStockList()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select distinct stock.stid, stock.stockid, stock.datein, supplier.supplierid, supplier.supplier_id, supplier.name, supplier.contactno, stock_payment.grandtotal, stock_payment.totalpayment, stock_payment.paymentdue, stock_payment.payduedate from stock join stock_payment on stock.stid=stock_payment.stock_id join supplier on stock_payment.supplier_id=supplier.supplierid and stock.datein=stock_payment.stockdate and datein=@d1"
            command = New SqlCommand(query, myconnection)
            command.Parameters.Add("@d1", SqlDbType.Date).Value = searchDate.Value
            dreader = command.ExecuteReader()
            dgv.Rows.Clear()
            If (dreader.HasRows) = True Then
                While dreader.Read()
                    dgv.Rows.Add(dreader(0), dreader(1), Format(dreader(2), "dd/MM/yyyy"), dreader(3), dreader(4), dreader(5), dreader(6), Format(dreader(7), "#,##."), Format(dreader(8), "#,##."), Format(dreader(9), "#,##."), dreader(10))
                End While
            Else
                MsgBox("There was no stock taken for the search date you entered", MsgBoxStyle.Information, "Date Not Found")
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Search Record Error")
        End Try
    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        MsgBox(dtp.Value)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If searchName.Text <> "" Then
            Try
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                query = "select distinct stock.stid, stock.stockid, stock.datein, supplier.supplierid, supplier.supplier_id, supplier.name, supplier.contactno, stock_payment.grandtotal, stock_payment.totalpayment, stock_payment.paymentdue, stock_payment.payduedate from stock join stock_payment on stock.stid=stock_payment.stock_id join supplier on stock_payment.supplier_id=supplier.supplierid and stock.datein=stock_payment.stockdate and supplier.name like '%" & searchName.Text & "%'"
                command = New SqlCommand(query, myconnection)
                dreader = command.ExecuteReader()
                dgv.Rows.Clear()
                If dreader.Read() = True Then
                    While dreader.Read()
                        dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6), Format(dreader(7), "#,##."), Format(dreader(8), "#,##."), Format(dreader(9), "#,##."), dreader(10))
                    End While
                Else
                    MsgBox("The supplier name you entered has no stock history. Record not found", MsgBoxStyle.Information, "Ooops!")
                End If
 Catch ex As SqlException
                ''MessageBox.Show(ex.ToString())
            Catch ex As Exception
                ''MsgBox(ex.ToString())
            End Try
        Else
            MsgBox("Enter name of supplier", MsgBoxStyle.Exclamation, "Search Error")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        FetchStockList()
    End Sub
End Class