﻿Imports System.Data.SqlClient


Public Class Sale
    Dim invid As Integer = 0
    Dim curInv, lastInv As Integer
    Dim invValue As String
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Close()
    End Sub
    Sub GetLastInvoiceId()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "select invid from invoice where invoiceno=@d1"
            command = New SqlCommand(query, myconnection)
            command.Parameters.AddWithValue("@d1", txtInvoiceNo.Text)
            dreader = command.ExecuteReader()
            If dreader.Read() Then
                lastInv = dreader.GetValue(0)
                dreader.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString(), , "Last Invoice ID Error")
        End Try
    End Sub
    Sub GetCompanyInfo()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            Const str As String = "SELECT name,location FROM company"
            command1 = New SqlCommand(str, myconnection)
            dreader = command1.ExecuteReader()
            If dreader.Read() Then
                lbl_POS_Heading.Text = dreader.GetValue(0) + " - " + dreader.GetValue(1).ToString.ToUpper()
                dreader.Close()
            Else
                Const defaultName As String = "TYGEN SALE SYSTEM"
                lbl_POS_Heading.Text = defaultName
            End If
        Catch ex As Exception
            MsgBox(ex.Message, , "at company name")
        End Try
    End Sub

    Private Sub Sale_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        'GetsAllProducts()
    End Sub
    Private Sub Sale_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ResetItemInfo()
        GetNewInvoiceNo()
        GetCompanyInfo()
        GetsAllProducts()
        'set user info
        txtCurrentUser.Text = LogFullName
        txtUserRole.Text = LogUserRole
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub
    Private Sub GetNewInvoiceNo()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            Const str As String = "SELECT  Max(Right(invid,2)) FROM invoice"
            command1 = New SqlCommand(str, myconnection)
            dreader = command1.ExecuteReader()
            While dreader.Read()
                If Not dreader.HasRows Or IsDBNull(dreader.Item(0)) Then
                    txtInvID.Text = 1
                    txtInvoiceNo.Text = "TSS/" & DateTime.Now.Year & DateTime.Now.Month & "01"
                Else
                    invid = CInt(dreader.Item(0))
                    invid += 1
                    txtInvID.Text = invid
                    txtInvoiceNo.Text = "TSS/" & DateTime.Now.Year & DateTime.Now.Month & invid.ToString("00")
                End If
            End While
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Invoice Number Error")
        End Try
    End Sub
    Private Function GenerateInvoice() As String
        Dim cmd As SqlCommand
        Dim rdr As SqlDataReader
        Dim sql As String
        Dim invoice As String = "0000"
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            sql = "SELECT  invid,invoiceno FROM invoice ORDER BY invid DESC"
            cmd = New SqlCommand(sql, myconnection)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            If (rdr.HasRows) Then
                rdr.Read()
                invid = rdr.Item("invid")
                invoice = rdr.Item("invoiceno")
            End If
            rdr.Close()
            ' Increase the ID by 1
            invoice += 1
            'because incrementing a string with an integer removes 0's
            ' we need to replace them. If necessary.
            If invoice <= 9 Then 'Value is between 0 and 10
                invoice = "000" & invoice
            ElseIf invoice <= 99 Then 'Value is between 9 and 100
                invoice = "00" & invoice
            ElseIf invoice <= 999 Then 'Value is between 999 and 1000
                invoice = "0" & invoice
            End If
        Catch ex As Exception
            ' If an error occurs, check the connection state and close it if necessary.
            'If Dbconnection.State = ConnectionState.Open Then
            '    Dbconnection.Close()
            'End If
            MsgBox(ex.Message)
            invoice = "0000"
        End Try
        Return invoice
    End Function
    Sub SetInvoice()
     Try
            txtInvID.Text = GenerateInvoice()
            txtInvoiceNo.Text = "TSS-" & DateTime.Now.Year & DateTime.Now.Month & GenerateInvoice()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "set invoice error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Sub ResetItemInfo()
        txtcode.Text = ""
        txtproduct.Text = ""
        txtprice.Text = ""
        txtProductId.Text = ""
        noQty.Value = "0"
        btnAddItem.Enabled = False
        txtproduct.Focus()
    End Sub
    Sub RefreshCart()
        dgvCart.Rows.Clear()
        ResetItemInfo()
        txtGrandTotal.Text = "0.00"
        txtTotalItems.Text = "0"
        txtInvID.Clear()
        txtInvoiceNo.Clear()
        txtCustomer.Clear()
        txtChange.Clear()
        txtPaymentCash.Clear()
        cboPaymentMode.ResetText()
        txtproduct.Focus()
        GetNewInvoiceNo()
    End Sub
    Sub Compute()
        Dim i As Double = 0
        i = Val(txtGrandTotal.Text) - Val(txtPaymentCash.Text)
        i = Math.Round(i, 2)
        txtChange.Text = i
    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        If MessageBox.Show("Are you sure you want to clear the shopping cart ; and reset for new sale?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            RefreshCart()
        End If
    End Sub

#Region "remove an item from cart"
    Private Sub btnRemoveItem_Click(sender As Object, e As EventArgs) Handles btnRemoveItem.Click
        If dgvCart.Rows.Count = 0 Then
            MsgBox("Sorry.. There is no item(s) in the shopping cart.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Exclamation, "Empty Cart")
            Exit Sub
        End If

        If MessageBox.Show("Remove the selected item '" + dgvCart.SelectedRows(0).Cells(2).Value + "' from the shopping cart?", "Confirm Item Remove", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                If dgvCart.SelectedRows.Count > 0 Then
                    For Each r As DataGridViewRow In dgvCart.SelectedRows
                        Dim n As Decimal = dgvCart.SelectedRows(n).Cells(6).Value
                        Dim nn As Integer = Val(txtGrandTotal.Text) - n
                        txtGrandTotal.Text = Format(nn, "#,#0.00")
                        dgvCart.Rows.Remove(dgvCart.SelectedRows(0))
                        dgvCart.EndEdit()

                        'set total rows count to txtTotalItems
                        txtTotalItems.Text = dgvCart.Rows.Count - 0
                        If dgvCart.Rows.Count = 0 Then txtGrandTotal.Text = "0.00"
                        ' if dgvinfo.Rows.Count > 0 then txtGrandTotal.Text = 
                        'clear payment textbox when an item is deleted . or removed from cart
                        If RTrim(txtPaymentCash.Text > 0) Then
                            txtPaymentCash.Clear()
                            txtChange.Clear()
                        End If
                        Exit Sub
                    Next
                End If

            Catch ex As Exception

            End Try
        End If

    End Sub
#End Region
#Region "add an item to cart"
    Private Sub btnAddItem_Click(sender As Object, e As EventArgs) Handles btnAddItem.Click
        If txtcode.Text = "" Then
            MessageBox.Show("Please, retrieve product or item info", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtcode.Focus()
            Exit Sub
        End If
        If noQty.Text = 0 Then
            MessageBox.Show("Quantity can not be zero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            noQty.Focus()
            Exit Sub
        End If

        'check item exists in gridview
        Dim i As Integer
        Dim itemloc As Integer = -1
        For i = 0 To dgvCart.Rows.Count - 1
            If dgvCart.Rows(i).Cells(0).Value = Me.txtProductId.Text Then
                itemloc = i     'item is found in gridview
                Exit For
            End If
        Next
        'remove commas from price
        Dim price As String = txtprice.Text.Replace(",", "")

        If itemloc = -1 Then
            'if item not found, add value to gridview
            dgvCart.Rows.Add(txtProductId.Text, txtcode.Text, txtproduct.Text, txtprice.Text, noQty.Text, (price * Val(noQty.Text)))
            'validate total grid_rows count
            txtTotalItems.Text = dgvCart.Rows.Count
            'compute total price
            Dim sum As Double = 0
            For i = 0 To dgvCart.Rows.Count - 1
                sum += dgvCart.Rows(i).Cells(5).Value
                txtGrandTotal.Text = Format(sum, ".00")
            Next
            ResetItemInfo()            'clear the textfields for new item
            Exit Sub
        Else
            'increase quantity and totalprice if item is found in gridview/cart
            Dim itemqty As Long = dgvCart.Rows(itemloc).Cells(4).Value
            Dim itemprice As String = (dgvCart.Rows(itemloc).Cells(3).Value)
            Dim ip As String = itemprice.Replace(",", "")
            itemqty = itemqty + Val(noQty.Text)
            Dim nprice As Decimal = ip * itemqty
            dgvCart.Rows(itemloc).Cells(4).Value = itemqty
            dgvCart.Rows(itemloc).Cells(5).Value = nprice
            'compute total price
            Dim sum As Double = 0
            For i = 0 To dgvCart.Rows.Count - 1
                sum += dgvCart.Rows(i).Cells(5).Value
                txtGrandTotal.Text = Format(sum, ".00")
                txtTotalItems.Text = dgvCart.Rows.Count
            Next
            ResetItemInfo()
        End If
    End Sub
#End Region

    Private Sub txtcode_TextChanged(sender As Object, e As EventArgs) Handles txtcode.TextChanged
        If (txtcode.Text = "") Then
            ResetItemInfo()
        Else
            Try
                If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                Dbconnection.Open()
                query = "select productid,pcode,pname,punitprice from product where pcode='" & txtcode.Text & "'"
                command = New SqlCommand(query, Dbconnection)
                dtable = New DataTable()
                dadapter = New SqlDataAdapter(command)
                dadapter.Fill(dtable)
                For Each item As DataRow In dtable.Rows
                    txtProductId.Text = item("productid").ToString()
                    txtcode.Text = item("pcode")
                    txtproduct.Text = item("pname").ToString()
                    txtprice.Text = Format(item("punitprice"), "#,##0.")
                    btnAddItem.Enabled = True
                Next
            Catch ex As SqlException

            Catch ex As Exception

            End Try
        End If

    End Sub
    Sub GetsAllProducts()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "select pname from product order by pname asc"
            command = New SqlCommand(query, myconnection)
            dtable = New DataTable()
            dadapter = New SqlDataAdapter(command)
            'dset.Tables.Add(dtable)
            dadapter.Fill(dtable)
            txtproduct.AutoCompleteCustomSource.Clear()
            For Each item As DataRow In dtable.Rows
                txtproduct.AutoCompleteCustomSource.Add(item.Item("pname").ToString())
            Next
        Catch ex As SqlException

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub txtproduct_TextChanged(sender As Object, e As EventArgs) Handles txtproduct.TextChanged
        If (txtproduct.Text = "") Then
            ResetItemInfo()
        Else
            Try
                If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                Dbconnection.Open()
                query = "select productid,pcode,pname,punitprice from product where pname='" & txtproduct.Text & "'"
                command = New SqlCommand(query, Dbconnection)
                dtable = New DataTable()
                dadapter = New SqlDataAdapter(command)
                dadapter.Fill(dtable)
                For Each item As DataRow In dtable.Rows
                    txtProductId.Text = item("productid").ToString()
                    txtcode.Text = item("pcode").ToString()
                    txtproduct.Text = item("pname").ToString()
                    txtprice.Text = Format(item("punitprice"), "#,##0.")
                Next
            Catch ex As SqlException

            Catch ex As Exception

            End Try
        End If

    End Sub

   Private Sub txtPaymentCash_TextChanged(sender As Object, e As EventArgs) Handles txtPaymentCash.TextChanged
        Compute()
    End Sub
    Private Sub label2_Click(sender As Object, e As EventArgs) Handles label2.Click
        Dim mm As Integer = DateTime.Now.Year
        Dim nn As Integer = dtpPayDue.Value.Year

        'If (nn < mm) Then
        '    txtInvoiceNo.Text = "TSS/" & nn & "-" & GenerateInvoice()
        'Else
        '    txtInvoiceNo.Text = "TSS/" & mm & "-" & GenerateInvoice()
        'End If
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim fm As New CustomerList
        fm.CurrentActiveForm = Me
        fm.ShowDialog()
    End Sub

#Region "pay for transaction"
    Private Sub btnPayment_Click(sender As Object, e As EventArgs) Handles btnPayment.Click
        If dgvCart.Rows.Count = 0 Then
            MessageBox.Show("Sorry...! No items added to the shopping cart;" + vbCrLf + "You must add product or items to the cart", "Cart Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtGrandTotal.Text = "0.00"
            txtTotalItems.Text = "0"
            txtChange.Text = ""
            Exit Sub
        End If
        Try
            'this code triggers to check empty stock info
            For Each row As DataGridViewRow In Me.dgvCart.Rows
                If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                Dbconnection.Open()
                Dim cmd As New SqlCommand("SELECT stocklevel from temp_stock where prodid=@d1", Dbconnection)
                cmd.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                Dim da As New SqlDataAdapter(cmd)
                Dim ds As DataSet = New DataSet()
                da.Fill(ds)
                If ds.Tables(0).Rows.Count = 0 Then
                    'show item stock error and remove affected item from cart
                    MessageBox.Show("The item added to cart has no stock history!" & vbCrLf & " Item Code : '" & row.Cells(1).Value.ToString() & "' and Item Name : '" & row.Cells(2).Value & "'" + vbCrLf + "Cannot proceed transaction, please re-stock ITEM..", "Item Stock Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'subtract item's amount from total cart amount
                    Dim newvalue As Integer = Val(txtGrandTotal.Text) - (row.Cells(5).Value)
                    txtGrandTotal.Text = Format(newvalue, "#,##0.00")
                    txtTotalItems.Text = txtTotalItems.Text - 1
                    dgvCart.Rows.Remove(row)
                    Exit Sub
                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message(), "No Stock Available", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try

        'this section of code select stockonhand from temporary stock table
        'to validate if quantity ordered exceeds available stock quantity 
        Try
            For Each row As DataGridViewRow In Me.dgvCart.Rows
                If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                Dbconnection.Open()
                Dim cmd As New SqlCommand("SELECT stocklevel from temp_stock where prodid=@d1", Dbconnection)
                cmd.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                Dim da As New SqlDataAdapter(cmd)
                Dim ds As DataSet = New DataSet()
                da.Fill(ds)
                If ds.Tables(0).Rows.Count > 0 Then
                    Dim qty As Integer = ds.Tables(0).Rows(0)("stocklevel")
                    If CInt(Val(row.Cells(4).Value)) > qty Then
                        MessageBox.Show("Quantity added exceeds available stock value" & vbCrLf & "Item Code : '" & row.Cells(1).Value.ToString() & "' and Item Name : '" & row.Cells(2).Value & "'" + vbCrLf + "Cannot proceed transaction, please re-stock and Try Again.. " + vbCrLf + "Item Available Quantity =" & qty, "Error - Limited Stock", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        'subtract item's amount from total cart amount
                        Dim newvalue As Integer = (Val(txtGrandTotal.Text) - (row.Cells(5).Value))
                        txtGrandTotal.Text = Format(newvalue, "#,##0.00")
                        txtTotalItems.Text = txtTotalItems.Text - 1
                        dgvCart.Rows.Remove(row)
                        Exit Sub
                    End If
                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Low Stock-Quantity", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Dbconnection.Close()
        End Try

        'check payment mode
        If cboPaymentMode.Text = "" Then
            MessageBox.Show("Please select the payment mode", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            cboPaymentMode.Focus()
            Exit Sub
        End If
        'check payment amount
        If txtPaymentCash.Text = "" Then
            MessageBox.Show("Please enter sale payment amount", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtPaymentCash.Focus()
            Exit Sub
        End If
        'If MessageBox.Show("There is no customer info added to shopping cart;" + vbCrLf + "Do you want to add customer name to this transaction?", "Add Customer", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then

      Try
                'proceed to payment
                '1st - save invoice
                Try
                    If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                Dbconnection.Open()
                    Dim str As String = "insert into invoice(invoiceno,invdate) values(@d1,@d2)"
                    Dim cdm As New SqlCommand(str, Dbconnection)
                    cdm.Parameters.AddWithValue("@d1", txtInvoiceNo.Text)
                    cdm.Parameters.AddWithValue("@d2", Date.Now)
                    cdm.ExecuteNonQuery()
                GetLastInvoiceId() 'get last invoiceid; the id of invoice just inserted
                Catch ex As Exception
                    MessageBox.Show(ex.ToString(), "@ invoice", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
                '2nd - save invoice_info
                For Each r As DataGridViewRow In dgvCart.Rows
                    If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                    Dbconnection.Open()
                Dim cmd As SqlCommand = New SqlCommand("insert into invoice_info(invoice_id, prod_id, infoprice, infoqty, infototal, infodate,customer) values (@d1,@d2,@d3,@d4,@d5,@d6,@d7)", Dbconnection)
                cmd.Parameters.AddWithValue("@d1", lastInv) '
                cmd.Parameters.AddWithValue("@d2", r.Cells(0).Value)
                cmd.Parameters.AddWithValue("@d3", r.Cells(3).Value)
                cmd.Parameters.AddWithValue("@d4", r.Cells(4).Value)
                cmd.Parameters.AddWithValue("@d5", r.Cells(5).Value)
                cmd.Parameters.AddWithValue("@d6", Date.Now)
                cmd.Parameters.AddWithValue("@d7", txtCustomer.Text)
                cmd.ExecuteNonQuery()
                Next

                '3rd - save invoice-payment
                If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                Dbconnection.Open()
                Dim cmd1 As SqlCommand = New SqlCommand("insert into invoice_payment(invoiceid, paymode, paytotal, paydate) values (@d1,@d2,@d3,@d4)", Dbconnection)
                cmd1.Parameters.AddWithValue("@d1", lastInv) '
                cmd1.Parameters.AddWithValue("@d2", cboPaymentMode.Text)
                cmd1.Parameters.AddWithValue("@d3", txtPaymentCash.Text)
                cmd1.Parameters.AddWithValue("@d4", Date.Now)
                cmd1.ExecuteNonQuery()

                'step 4: update temporary stock, subtract item sold from avaliable stock
                For Each row As DataGridViewRow In dgvCart.Rows
                    If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                    Dbconnection.Open()
                    Try
                        Dim sql As SqlCommand = New SqlCommand("update temp_stock set stocklevel = stocklevel - (" & row.Cells(4).Value & ") where prodid='" & row.Cells(0).Value & "'", Dbconnection)
                        sql.ExecuteNonQuery()
                    Catch ex As Exception
                        MsgBox(ex.ToString(), , "@ temp-stock")
                    End Try
                Next

            Print()
            AllUserActivities(LogFullName + ", added a new sale bill with invoice no: " & txtInvoiceNo.Text & " on " & Date.Now)
            MessageBox.Show("Transaction completed successfully;" + vbCrLf + "Invoice No-(" + txtInvoiceNo.Text + ")", "Sale System Billing", MessageBoxButtons.OK, MessageBoxIcon.Information)
            RefreshCart()

            Catch ex As Exception
            MessageBox.Show(ex.ToString(), "@ payment error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

    End Sub
#End Region
#Region "section to print invoice or receipt, using microsoft reporting, or crystal report"
    Sub PrintReceipt()
        Try
            Cursor = Cursors.WaitCursor
            Timer1.Enabled = True
            'Dim report As New rptReceipt 
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            Dim myCommand As New SqlCommand("SELECT product.name,  invoice_info.infoqty, invoice_info.infoprice, invoice_info.infototal, invoice.invoiceno FROM product INNER JOIN invoice_info ON product.productid = invoice_info.prod_id INNER JOIN invoice ON invoice_info.invoice_id = invoice.invid where invoice.invid = invoice_info.invoice_id AND product.productid = invoice_info.prod_id AND invoice.invoiceno=@d1 AND invoice.invdate=@d2", Dbconnection)
            myCommand.Parameters.AddWithValue("@d1", txtInvoiceNo.Text)
            myCommand.Parameters.AddWithValue("@d2", Date.Now)
            Dim myCommand1 As New SqlCommand("SELECT name, telephone,location from company", Dbconnection)
            Dim myDa, myDa1 As New SqlDataAdapter()
            Dim myDs As New Data.DataSet 'The DataSet  created.
            myDa.SelectCommand = myCommand
            myDa1.SelectCommand = myCommand1
            myDa.Fill(myDs, "product")
            myDa.Fill(myDs, "invoice")
            myDa.Fill(myDs, "invoice_info")
            myDa1.Fill(myDs, "company")
            'report.SetDataSource(myDs)
            'report.SetParameterValue("pInvoice", txtInvoiceNo.Text)
            'frmDailySalesReport1.CrystalReportViewer1.ReportSource = report
            'frmDailySalesReport1.ShowDialog()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error @ print of cr of cash invoice", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Dbconnection.Close()
        End Try

    End Sub
    Private Sub Print()
        Try
            Cursor = Cursors.WaitCursor
            Timer1.Enabled = True
            Dim objcmd As SqlCommand
            Dim objdr As SqlDataReader
            Dim objds As DataSet = New dsetTygen
            Dim sql, sql1 As String
            sql1 = "select name, telephone, location from company"
            'sql = "select pname, infoprice, infoqty, infototal, invdate from product inner join invoice_info on product.productid=invoice_info.prod_id inner join invoice on invoice_info.invoice_id=invoice.invid where invoice_info.infodate=invoice.invdate and invoice.invoiceno='" & txtInvoiceNo.Text & "'"
            sql = "select pname, infoprice, infoqty, infototal, invdate,invoiceno from product p, invoice_info ii, invoice i where p.productid=ii.prod_id and i.invid=ii.invoice_id and ii.infodate=i.invdate and i.invoiceno=@d1"
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            objcmd = New SqlCommand(sql, myconnection)
            objcmd.CommandType = CommandType.Text
            objcmd.Parameters.AddWithValue("@d1", Me.txtInvoiceNo.Text)
            objdr = objcmd.ExecuteReader()
            objds.Tables(0).Clear()
            objds.Tables(0).Load((objdr))
            objdr.Close()
            Dim rds As ReportDataSource = New ReportDataSource()
            rds.Name = "myReceipt"
            rds.Value = objds.Tables(0)
            Dim param As New List(Of ReportParameter)
            param.Add(New ReportParameter("pInvoice", Me.txtInvoiceNo.Text))
            param.Add(New ReportParameter("pDate", Date.Now))
            With Report
                .ReportViewer1.LocalReport.ReportEmbeddedResource = "POS.rptReceipt.rdlc"
                .ReportViewer1.LocalReport.DataSources.Clear()
                .ReportViewer1.LocalReport.DataSources.Add(rds)
                .ReportViewer1.LocalReport.SetParameters(param)
                .ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
                .ReportViewer1.Refresh()
                .Text = "Sale Invoice"
                .ShowDialog()
            End With

        Catch ex As Exception
            MsgBox(ex.ToString(), , "Receipt Printing Error")
        End Try
    End Sub
#End Region

    Private Sub dgvCart_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgvCart.RowsAdded
        For Each row As DataGridViewRow In dgvCart.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
        dgvCart.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim fm As New CustomerList
        fm.CurrentActiveForm = Me
        fm.ShowDialog()
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Cursor = Cursors.Default
        Timer1.Enabled = False
    End Sub

    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click

    End Sub
End Class