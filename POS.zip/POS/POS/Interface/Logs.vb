﻿Imports System.Data.SqlClient

Public Class Logs

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
    Sub Reset()
        dtpDateFrom.Text = Now
        dtpDateTo.Text = Now
        cmbUserID.Text = ""
        cmbUserID.SelectedIndex = -1
        btnSearch.Enabled = True
        dgv.Rows.Clear()
        GetLogs()
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub
    Sub DeleteSelected()
        Try
            'check product name exists
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            Const check As String = "select * from systemlogs where logid=@d1"
            command = New SqlCommand(check)
            command.Parameters.AddWithValue("@d1", dgv.SelectedRows(0).Cells(0).Value)
            command.Connection = myconnection
            dreader = command.ExecuteReader()
            If dreader.Read() Then
                dreader.Close()
                'proceed to delete record
                'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ConnectDB()
                Dim dr As DataGridViewRow = dgv.SelectedRows(0)
                query = "delete from systemlogs where logid=@d1"
                command = New SqlCommand(query, myconnection)
                command.Parameters.AddWithValue("@d1", dr.Cells(0).Value)
                'Dbconnection.Open()
                command.ExecuteNonQuery()
                'Dbconnection.Close()
                AllUserActivities(LogFullName + ", deleted the log record with user id '" & dgv.SelectedRows(0).Cells(0).Value & "' on " & DateTime.Now)
                MessageBox.Show("One system log record deleted..", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            End If

        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Information, "Record delete error")
        End Try
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If dgv.Rows.Count > 0 Then
            Dim selected As DataGridViewRow = dgv.SelectedRows(0)
            If MessageBox.Show("Delete the selected log?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                DeleteSelected()
            End If
        End If
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub
    Private Sub GetLogs()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "SELECT RTRIM(logid), RTRIM(logname), RTRIM(logdate), RTRIM(logtime), RTRIM(operation) from systemlogs order by logdate desc"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            If (dreader.HasRows = True) Then
                dgv.Rows.Clear()
                While (dreader.Read() = True)
                    dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4))
                End While
            Else
                MessageBox.Show("No record of system logs found.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As SqlException
            MsgBox(ex.Message, MsgBoxStyle.Information, "sql exception")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "exception")
        End Try
    End Sub
    Public Sub DeleteAllRecords()
        Try
            'delete all records
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ConnectDB()
            Dim ct As String = "delete from systemlogs"
            command = New SqlCommand(ct)
            command.Connection = myconnection
            command.ExecuteNonQuery()
            'insert new log record
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ConnectDB()
            Dim st As String = "deleted all system logs till date '" & Now & "'"
            UserLogFunction(LogUsername, st)
            AllUserActivities(LogFullName & ", deleted all the logs of system with total of: '" & dgv.Rows.Count + "'")
            MessageBox.Show("System logs successfully deleted", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Reset()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnTruncate_Click(sender As Object, e As EventArgs) Handles btnTruncate.Click
        If MessageBox.Show("Do you really want to delete all '" & dgv.Rows.Count & "' records of system logs?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
            DeleteAllRecords()
        End If
    End Sub

    Private Sub Logs_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        dtpDateFrom.Text = Now
        dtpDateTo.Text = Now
        cmbUserID.SelectedIndex = -1
        cmbUserID.ResetText()
        btnSearch.Enabled = False
    End Sub
    Private Sub Logs_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        GetLogs()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
        'Dbconnection.Open()
        ConnectDB()
        query = "SELECT RTRIM(logid), RTRIM(logname),RTRIM(logdate),RTRIM(logtime),RTRIM(operation) from systemlogs where logname='" & cmbUserID.Text & "' order by logdate desc"
        command = New SqlCommand(query, myconnection)
        dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
        If dreader.HasRows Then
            dgv.Rows.Clear()
            While (dreader.Read() = True)
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4))
            End While
        Else
            MsgBox("No logs record was found for the specified user id", MsgBoxStyle.Information, "Message")
        End If
    End Sub

    Private Sub cmbUserID_DropDown(sender As Object, e As EventArgs) Handles cmbUserID.DropDown
        GetUserId()
    End Sub
    Private Sub cmbUserID_TextChanged(sender As Object, e As EventArgs) Handles cmbUserID.TextChanged
        If cmbUserID.Text = "" Then
            btnSearch.Enabled = False
        Else
            btnSearch.Enabled = True
        End If
    End Sub
    Sub GetUserId()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            dadapter = New SqlDataAdapter()
            dadapter.SelectCommand = New SqlCommand("SELECT distinct RTRIM(username) FROM staff", myconnection)
            dset.Clear()
            dadapter.Fill(dset, "staff")
            Dim dtable As DataTable = dset.Tables(0)
            cmbUserID.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbUserID.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub

    Private Sub btnGet_Click(sender As Object, e As EventArgs) Handles btnGet.Click
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            Dim cmd As SqlCommand
            cmd = New SqlCommand("SELECT RTRIM(logid),RTRIM(logname),RTRIM(logdate),RTRIM(logtime),RTRIM(operation) from systemlogs where logdate between @date1 and @date2 order by logdate desc", myconnection)
            cmd.Parameters.Add("@date1", SqlDbType.Date, 30, "Date").Value = dtpDateFrom.Value.Date
            cmd.Parameters.Add("@date2", SqlDbType.Date, 30, "Date").Value = dtpDateTo.Value.Date
            dreader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            If (dreader.HasRows) Then
                While (dreader.Read() = True)
                    dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4))
                End While
            Else
                MsgBox("Sorry.. No records of logs found for your search dates", MsgBoxStyle.Information, "Message")
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "search error")
        End Try
    End Sub
End Class