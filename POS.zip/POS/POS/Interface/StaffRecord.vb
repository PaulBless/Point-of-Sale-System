﻿Imports System.Data.SqlClient

Public Class StaffRecord
    Public Property ActiveFormStaff As Staff
    Private Sub StaffRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FetchRecords()
    End Sub

    Public Sub Reset()
        txtLocation.Clear()
        txtName.Clear()
        txtStatus.Clear()
        dgv.Rows.Clear()
        FetchRecords()
    End Sub
    Private Sub GetStaff()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select staffid,fullname,gender, mobileno, location,email,contactname,contactno,username,password,type from staff order by regdate asc"
            dadapter = New SqlDataAdapter(query, myconnection)
            dtable = New DataTable()
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("Sorry.... No record of staff found.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                dgv.Rows.Clear()
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    dgv.Rows(i).Cells(0).Value = (item("staffid").ToString())
                    dgv.Rows(i).Cells(1).Value = (item("fullname").ToString())
                    dgv.Rows(i).Cells(2).Value = item("gender").ToString()
                    dgv.Rows(i).Cells(3).Value = (item("mobileno").ToString())
                    dgv.Rows(i).Cells(4).Value = (item("location").ToString())
                    dgv.Rows(i).Cells(5).Value = (item("email").ToString())
                    dgv.Rows(i).Cells(6).Value = (item("contactname").ToString())
                    dgv.Rows(i).Cells(7).Value = (item("contactno").ToString())
                    dgv.Rows(1).Cells(8).Value = (item("username").ToString())
                    dgv.Rows(i).Cells(9).Value = (item("password").ToString())
                    dgv.Rows(i).Cells(10).Value = (item("type").ToString())
                Next
            End If

        Catch ex As SqlException
            MessageBox.Show(ex.ToString())
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub
    Sub FetchRecords()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select staffid,fullname,gender, mobileno, location,email,contactname,contactno,username,password,type from staff order by regdate asc"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader()
            If dreader.HasRows() Then
                dgv.Rows.Clear()
                While dreader.Read()
                    dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6), dreader(7), dreader(8), dreader(9), dreader(10))
                End While
            Else
                MsgBox("No records of staff was found in the system", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Message")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Information, "Search Error")
        End Try
    End Sub
    Private Sub dgw_MouseClick(sender As Object, e As MouseEventArgs) Handles dgv.MouseClick
        Try
            If dgv.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgv.SelectedRows(0)
                If lblSet.Text = "Staff Entry" Then
                    ActiveFormStaff.Show()
                    ActiveFormStaff.Activate()
                    ActiveFormStaff.txtSID.Text = dr.Cells(0).Value.ToString()
                    ActiveFormStaff.txtStaffName.Text = dr.Cells(1).Value.ToString()
                    ActiveFormStaff.cboGender.Text = dr.Cells(2).Value.ToString()
                    ActiveFormStaff.txtMobileNo.Text = dr.Cells(3).Value.ToString()
                    ActiveFormStaff.txtLocation.Text = dr.Cells(4).Value.ToString()
                    ActiveFormStaff.txtEmail.Text = dr.Cells(5).Value.ToString()
                    ActiveFormStaff.txtContactName.Text = dr.Cells(6).Value.ToString()
                    ActiveFormStaff.txtContactNo.Text = dr.Cells(7).Value.ToString()
                    ActiveFormStaff.txtUsername.Text = dr.Cells(8).Value.ToString()
                    ActiveFormStaff.txtPassword.Text = (dr.Cells(9).Value.ToString())
                    ActiveFormStaff.cboRole.Text = dr.Cells(10).Value.ToString()
                    ActiveFormStaff.lblName.Text = dr.Cells(1).Value.ToString()
                    ActiveFormStaff.txtPassword.Enabled = False
                    ActiveFormStaff.txtPassword.PasswordChar = "•"
                    ActiveFormStaff.txtPasswordConfirm.Enabled = False
                    ActiveFormStaff.txtUsername.Enabled = False
                    ActiveFormStaff.cboRole.Enabled = False
                    ActiveFormStaff.btnSave.Enabled = False
                    ActiveFormStaff.btnNew.Enabled = True
                    ActiveFormStaff.btnUpdate.Enabled = True
                    ActiveFormStaff.btnDelete.Enabled = True
                    ActiveFormStaff.btnCreate.Enabled = False
                    Me.Close()
                End If
                If lblSet.Text = "Set" Then
                    'do nothing
                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub
    Private Sub dgw_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
        ''FetchRecords()
    End Sub

    Private Sub txtName_TextChanged(sender As Object, e As EventArgs) Handles txtName.TextChanged
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select staffid,fullname,gender, mobileno, location,email,contactname,contactno,username,password,type from staff  where fullname like '%" & txtName.Text & "%' order by fullname asc"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader()
            dgv.Rows.Clear()
            While (dreader.Read())
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), (dreader(3)), dreader(4), dreader(5), dreader(6), dreader(7), dreader(8), dreader(9), dreader(10))
            End While
            dreader.Close()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub txtLocation_TextChanged(sender As Object, e As EventArgs) Handles txtLocation.TextChanged
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select staffid,fullname,gender, mobileno, location,email,contactname,contactno,username,password,type from staff  where location like '%" & txtLocation.Text & "%' order by fullname asc"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader()
            dgv.Rows.Clear()
            While (dreader.Read())
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), (dreader(3)), dreader(4), dreader(5), dreader(6), dreader(7), dreader(8), dreader(9), dreader(10))
            End While
            dreader.Close()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub txtStatus_TextChanged(sender As Object, e As EventArgs) Handles txtStatus.TextChanged
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select staffid,fullname,gender, mobileno, location,email,contactname,contactno,username,password,type from staff  where status like '%" & txtStatus.Text & "%' group by status order by fullname asc"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader()
            dgv.Rows.Clear()
            While (dreader.Read())
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), (dreader(3)), dreader(4), dreader(5), dreader(6), dreader(7), dreader(8), dreader(9), dreader(10))
            End While
            dreader.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
End Class