﻿Public Class SaleRecord

End Class