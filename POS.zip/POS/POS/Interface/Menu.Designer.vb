﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Menu))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.FileMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnCompany = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnCategory = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnLocations = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnLockPC = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.POSOptionsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnPriceList = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnNewExpense = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnStockReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnStockOutReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSalesReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnCalculator = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnNotepad = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnTaskManager = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnDbConfigure = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnUserActivities = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColorThemeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfileMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnChangePassword = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnProfile = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnHelpContent = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnRegistration = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnStaff = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnCustomer = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnSupplier = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnProduct = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnShopping = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnStockEntry = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnStockIn = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnRecords = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnCustomers = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSuppliers = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnProducts = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnStocks = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSales = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnStaffs = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnExpenses = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnDatabase = New System.Windows.Forms.ToolStripDropDownButton()
        Me.btnBackupDB = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnRestoreDB = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnReports = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnStocksIn = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnStocksOut = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnDailySales = New System.Windows.Forms.ToolStripMenuItem()
        Me.WeeklySalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonthlySalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnSystemLogs = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnLogout = New System.Windows.Forms.ToolStripButton()
        Me.MainPanel = New System.Windows.Forms.Panel()
        Me.AnimationLabel = New System.Windows.Forms.Label()
        Me.lblDateTime = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblwelcome = New System.Windows.Forms.Label()
        Me.lblLogUser = New System.Windows.Forms.Label()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.colCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colQuantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPackPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.MainPanel.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.BackColor = System.Drawing.SystemColors.Control
        Me.MenuStrip.GripMargin = New System.Windows.Forms.Padding(2)
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileMenu, Me.POSOptionsMenu, Me.ReportsMenu, Me.ToolsMenu, Me.SettingsMenu, Me.ProfileMenu, Me.HelpMenu})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(1176, 24)
        Me.MenuStrip.TabIndex = 5
        Me.MenuStrip.Text = "MenuStrip"
        '
        'FileMenu
        '
        Me.FileMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnCompany, Me.ToolStripSeparator3, Me.btnCategory, Me.btnLocations, Me.ToolStripSeparator5, Me.btnLockPC, Me.btnExit})
        Me.FileMenu.Font = New System.Drawing.Font("Lucida Sans", 10.0!)
        Me.FileMenu.ForeColor = System.Drawing.Color.Teal
        Me.FileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder
        Me.FileMenu.Name = "FileMenu"
        Me.FileMenu.Size = New System.Drawing.Size(89, 20)
        Me.FileMenu.Text = "&Main Menu"
        '
        'btnCompany
        '
        Me.btnCompany.ForeColor = System.Drawing.Color.Teal
        Me.btnCompany.Image = CType(resources.GetObject("btnCompany.Image"), System.Drawing.Image)
        Me.btnCompany.ImageTransparentColor = System.Drawing.Color.Black
        Me.btnCompany.Name = "btnCompany"
        Me.btnCompany.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.btnCompany.Size = New System.Drawing.Size(235, 22)
        Me.btnCompany.Text = "&Company Profile"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.ForeColor = System.Drawing.Color.Teal
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(232, 6)
        '
        'btnCategory
        '
        Me.btnCategory.ForeColor = System.Drawing.Color.Teal
        Me.btnCategory.Image = CType(resources.GetObject("btnCategory.Image"), System.Drawing.Image)
        Me.btnCategory.ImageTransparentColor = System.Drawing.Color.Black
        Me.btnCategory.Name = "btnCategory"
        Me.btnCategory.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.btnCategory.Size = New System.Drawing.Size(235, 22)
        Me.btnCategory.Text = "&Category"
        '
        'btnLocations
        '
        Me.btnLocations.ForeColor = System.Drawing.Color.Teal
        Me.btnLocations.Image = CType(resources.GetObject("btnLocations.Image"), System.Drawing.Image)
        Me.btnLocations.Name = "btnLocations"
        Me.btnLocations.Size = New System.Drawing.Size(235, 22)
        Me.btnLocations.Text = "Location"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.ForeColor = System.Drawing.Color.Teal
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(232, 6)
        '
        'btnLockPC
        '
        Me.btnLockPC.ForeColor = System.Drawing.Color.Teal
        Me.btnLockPC.Name = "btnLockPC"
        Me.btnLockPC.Size = New System.Drawing.Size(235, 22)
        Me.btnLockPC.Text = "Lock PC / Workstation"
        '
        'btnExit
        '
        Me.btnExit.ForeColor = System.Drawing.Color.Teal
        Me.btnExit.Image = CType(resources.GetObject("btnExit.Image"), System.Drawing.Image)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(235, 22)
        Me.btnExit.Text = "E&xit"
        '
        'POSOptionsMenu
        '
        Me.POSOptionsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnPriceList, Me.btnNewExpense})
        Me.POSOptionsMenu.Font = New System.Drawing.Font("Lucida Sans", 10.0!)
        Me.POSOptionsMenu.ForeColor = System.Drawing.Color.Teal
        Me.POSOptionsMenu.Name = "POSOptionsMenu"
        Me.POSOptionsMenu.Size = New System.Drawing.Size(102, 20)
        Me.POSOptionsMenu.Text = "POS Options"
        '
        'btnPriceList
        '
        Me.btnPriceList.ForeColor = System.Drawing.Color.Teal
        Me.btnPriceList.Image = CType(resources.GetObject("btnPriceList.Image"), System.Drawing.Image)
        Me.btnPriceList.Name = "btnPriceList"
        Me.btnPriceList.Size = New System.Drawing.Size(179, 22)
        Me.btnPriceList.Text = "Price List"
        '
        'btnNewExpense
        '
        Me.btnNewExpense.ForeColor = System.Drawing.Color.Teal
        Me.btnNewExpense.Name = "btnNewExpense"
        Me.btnNewExpense.Size = New System.Drawing.Size(179, 22)
        Me.btnNewExpense.Text = "Create Expense"
        '
        'ReportsMenu
        '
        Me.ReportsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnStockReport, Me.btnStockOutReport, Me.btnSalesReport})
        Me.ReportsMenu.Font = New System.Drawing.Font("Lucida Sans", 10.0!)
        Me.ReportsMenu.ForeColor = System.Drawing.Color.Teal
        Me.ReportsMenu.Name = "ReportsMenu"
        Me.ReportsMenu.Size = New System.Drawing.Size(72, 20)
        Me.ReportsMenu.Text = "Reports"
        '
        'btnStockReport
        '
        Me.btnStockReport.ForeColor = System.Drawing.Color.Teal
        Me.btnStockReport.Image = CType(resources.GetObject("btnStockReport.Image"), System.Drawing.Image)
        Me.btnStockReport.Name = "btnStockReport"
        Me.btnStockReport.Size = New System.Drawing.Size(159, 22)
        Me.btnStockReport.Text = "Stock In"
        '
        'btnStockOutReport
        '
        Me.btnStockOutReport.ForeColor = System.Drawing.Color.Teal
        Me.btnStockOutReport.Image = CType(resources.GetObject("btnStockOutReport.Image"), System.Drawing.Image)
        Me.btnStockOutReport.Name = "btnStockOutReport"
        Me.btnStockOutReport.Size = New System.Drawing.Size(159, 22)
        Me.btnStockOutReport.Text = "Stock Out"
        '
        'btnSalesReport
        '
        Me.btnSalesReport.ForeColor = System.Drawing.Color.Teal
        Me.btnSalesReport.Image = CType(resources.GetObject("btnSalesReport.Image"), System.Drawing.Image)
        Me.btnSalesReport.Name = "btnSalesReport"
        Me.btnSalesReport.Size = New System.Drawing.Size(159, 22)
        Me.btnSalesReport.Text = "Sales Report"
        '
        'ToolsMenu
        '
        Me.ToolsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnCalculator, Me.btnNotepad, Me.btnTaskManager})
        Me.ToolsMenu.Font = New System.Drawing.Font("Lucida Sans", 10.0!)
        Me.ToolsMenu.ForeColor = System.Drawing.Color.Teal
        Me.ToolsMenu.Name = "ToolsMenu"
        Me.ToolsMenu.Size = New System.Drawing.Size(57, 20)
        Me.ToolsMenu.Text = "Tools"
        '
        'btnCalculator
        '
        Me.btnCalculator.ForeColor = System.Drawing.Color.Teal
        Me.btnCalculator.Image = CType(resources.GetObject("btnCalculator.Image"), System.Drawing.Image)
        Me.btnCalculator.Name = "btnCalculator"
        Me.btnCalculator.Size = New System.Drawing.Size(169, 22)
        Me.btnCalculator.Text = "Calculator"
        '
        'btnNotepad
        '
        Me.btnNotepad.ForeColor = System.Drawing.Color.Teal
        Me.btnNotepad.Image = CType(resources.GetObject("btnNotepad.Image"), System.Drawing.Image)
        Me.btnNotepad.Name = "btnNotepad"
        Me.btnNotepad.Size = New System.Drawing.Size(169, 22)
        Me.btnNotepad.Text = "Notepad"
        '
        'btnTaskManager
        '
        Me.btnTaskManager.ForeColor = System.Drawing.Color.Teal
        Me.btnTaskManager.Image = CType(resources.GetObject("btnTaskManager.Image"), System.Drawing.Image)
        Me.btnTaskManager.Name = "btnTaskManager"
        Me.btnTaskManager.Size = New System.Drawing.Size(169, 22)
        Me.btnTaskManager.Text = "Task Manager"
        '
        'SettingsMenu
        '
        Me.SettingsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnDbConfigure, Me.btnUserActivities, Me.ColorThemeToolStripMenuItem})
        Me.SettingsMenu.Font = New System.Drawing.Font("Lucida Sans", 10.0!)
        Me.SettingsMenu.ForeColor = System.Drawing.Color.Teal
        Me.SettingsMenu.Name = "SettingsMenu"
        Me.SettingsMenu.Size = New System.Drawing.Size(73, 20)
        Me.SettingsMenu.Text = "Settings"
        '
        'btnDbConfigure
        '
        Me.btnDbConfigure.ForeColor = System.Drawing.Color.Teal
        Me.btnDbConfigure.Image = CType(resources.GetObject("btnDbConfigure.Image"), System.Drawing.Image)
        Me.btnDbConfigure.Name = "btnDbConfigure"
        Me.btnDbConfigure.Size = New System.Drawing.Size(233, 22)
        Me.btnDbConfigure.Text = "Database Configuration"
        '
        'btnUserActivities
        '
        Me.btnUserActivities.ForeColor = System.Drawing.Color.Teal
        Me.btnUserActivities.Image = CType(resources.GetObject("btnUserActivities.Image"), System.Drawing.Image)
        Me.btnUserActivities.Name = "btnUserActivities"
        Me.btnUserActivities.Size = New System.Drawing.Size(233, 22)
        Me.btnUserActivities.Text = "User Activities"
        '
        'ColorThemeToolStripMenuItem
        '
        Me.ColorThemeToolStripMenuItem.Name = "ColorThemeToolStripMenuItem"
        Me.ColorThemeToolStripMenuItem.Size = New System.Drawing.Size(233, 22)
        Me.ColorThemeToolStripMenuItem.Text = "Color Theme"
        '
        'ProfileMenu
        '
        Me.ProfileMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnChangePassword, Me.btnProfile})
        Me.ProfileMenu.Font = New System.Drawing.Font("Lucida Sans", 10.0!)
        Me.ProfileMenu.ForeColor = System.Drawing.Color.Teal
        Me.ProfileMenu.Name = "ProfileMenu"
        Me.ProfileMenu.Size = New System.Drawing.Size(93, 20)
        Me.ProfileMenu.Text = "User Profile"
        '
        'btnChangePassword
        '
        Me.btnChangePassword.ForeColor = System.Drawing.Color.Teal
        Me.btnChangePassword.Image = Global.POS.My.Resources.Resources.employee
        Me.btnChangePassword.Name = "btnChangePassword"
        Me.btnChangePassword.Size = New System.Drawing.Size(194, 22)
        Me.btnChangePassword.Text = "Change Password"
        '
        'btnProfile
        '
        Me.btnProfile.ForeColor = System.Drawing.Color.Teal
        Me.btnProfile.Image = CType(resources.GetObject("btnProfile.Image"), System.Drawing.Image)
        Me.btnProfile.Name = "btnProfile"
        Me.btnProfile.Size = New System.Drawing.Size(194, 22)
        Me.btnProfile.Text = "View Profile"
        '
        'HelpMenu
        '
        Me.HelpMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnHelpContent, Me.btnAbout})
        Me.HelpMenu.Font = New System.Drawing.Font("Lucida Sans", 10.0!)
        Me.HelpMenu.ForeColor = System.Drawing.Color.Teal
        Me.HelpMenu.Name = "HelpMenu"
        Me.HelpMenu.Size = New System.Drawing.Size(50, 20)
        Me.HelpMenu.Text = "Help"
        '
        'btnHelpContent
        '
        Me.btnHelpContent.ForeColor = System.Drawing.Color.Teal
        Me.btnHelpContent.Image = CType(resources.GetObject("btnHelpContent.Image"), System.Drawing.Image)
        Me.btnHelpContent.Name = "btnHelpContent"
        Me.btnHelpContent.ShortcutKeys = CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.F1), System.Windows.Forms.Keys)
        Me.btnHelpContent.Size = New System.Drawing.Size(246, 22)
        Me.btnHelpContent.Text = "View Help"
        '
        'btnAbout
        '
        Me.btnAbout.ForeColor = System.Drawing.Color.Teal
        Me.btnAbout.Image = CType(resources.GetObject("btnAbout.Image"), System.Drawing.Image)
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Size = New System.Drawing.Size(246, 22)
        Me.btnAbout.Text = "About Tygen Sale System"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.BackColor = System.Drawing.Color.White
        Me.ToolStrip1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnRegistration, Me.ToolStripSeparator14, Me.btnStaff, Me.ToolStripSeparator15, Me.btnCustomer, Me.ToolStripSeparator6, Me.btnSupplier, Me.ToolStripSeparator1, Me.btnProduct, Me.ToolStripSeparator9, Me.btnShopping, Me.ToolStripSeparator10, Me.btnStockEntry, Me.ToolStripSeparator11, Me.btnStockIn, Me.ToolStripSeparator12, Me.btnRecords, Me.ToolStripSeparator8, Me.btnDatabase, Me.ToolStripSeparator2, Me.btnReports, Me.ToolStripSeparator7, Me.btnSystemLogs, Me.ToolStripSeparator4, Me.btnLogout})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1176, 73)
        Me.ToolStrip1.TabIndex = 19
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnRegistration
        '
        Me.btnRegistration.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnRegistration.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnRegistration.Image = CType(resources.GetObject("btnRegistration.Image"), System.Drawing.Image)
        Me.btnRegistration.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnRegistration.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnRegistration.Name = "btnRegistration"
        Me.btnRegistration.Size = New System.Drawing.Size(97, 70)
        Me.btnRegistration.Text = "&User Account"
        Me.btnRegistration.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 73)
        '
        'btnStaff
        '
        Me.btnStaff.AutoSize = False
        Me.btnStaff.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnStaff.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnStaff.Image = CType(resources.GetObject("btnStaff.Image"), System.Drawing.Image)
        Me.btnStaff.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnStaff.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnStaff.Name = "btnStaff"
        Me.btnStaff.Size = New System.Drawing.Size(70, 72)
        Me.btnStaff.Text = "Staff"
        Me.btnStaff.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btnStaff.ToolTipText = "Staff"
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(6, 73)
        '
        'btnCustomer
        '
        Me.btnCustomer.AutoSize = False
        Me.btnCustomer.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnCustomer.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnCustomer.Image = CType(resources.GetObject("btnCustomer.Image"), System.Drawing.Image)
        Me.btnCustomer.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnCustomer.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnCustomer.Name = "btnCustomer"
        Me.btnCustomer.Size = New System.Drawing.Size(70, 72)
        Me.btnCustomer.Text = "&Customers"
        Me.btnCustomer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 73)
        '
        'btnSupplier
        '
        Me.btnSupplier.AutoSize = False
        Me.btnSupplier.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnSupplier.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnSupplier.Image = CType(resources.GetObject("btnSupplier.Image"), System.Drawing.Image)
        Me.btnSupplier.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnSupplier.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSupplier.Name = "btnSupplier"
        Me.btnSupplier.Size = New System.Drawing.Size(70, 72)
        Me.btnSupplier.Text = "&Suppliers"
        Me.btnSupplier.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 73)
        '
        'btnProduct
        '
        Me.btnProduct.AutoSize = False
        Me.btnProduct.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnProduct.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnProduct.Image = CType(resources.GetObject("btnProduct.Image"), System.Drawing.Image)
        Me.btnProduct.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnProduct.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnProduct.Name = "btnProduct"
        Me.btnProduct.Size = New System.Drawing.Size(90, 72)
        Me.btnProduct.Text = "&Products"
        Me.btnProduct.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btnProduct.ToolTipText = "Products/Items"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 73)
        '
        'btnShopping
        '
        Me.btnShopping.AutoSize = False
        Me.btnShopping.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnShopping.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnShopping.Image = CType(resources.GetObject("btnShopping.Image"), System.Drawing.Image)
        Me.btnShopping.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnShopping.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnShopping.Name = "btnShopping"
        Me.btnShopping.Size = New System.Drawing.Size(70, 72)
        Me.btnShopping.Text = "Shopping"
        Me.btnShopping.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 73)
        '
        'btnStockEntry
        '
        Me.btnStockEntry.AutoSize = False
        Me.btnStockEntry.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnStockEntry.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnStockEntry.Image = CType(resources.GetObject("btnStockEntry.Image"), System.Drawing.Image)
        Me.btnStockEntry.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnStockEntry.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnStockEntry.Name = "btnStockEntry"
        Me.btnStockEntry.Size = New System.Drawing.Size(82, 72)
        Me.btnStockEntry.Text = "&Stock Entry"
        Me.btnStockEntry.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 73)
        '
        'btnStockIn
        '
        Me.btnStockIn.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnStockIn.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnStockIn.Image = CType(resources.GetObject("btnStockIn.Image"), System.Drawing.Image)
        Me.btnStockIn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnStockIn.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnStockIn.Name = "btnStockIn"
        Me.btnStockIn.Size = New System.Drawing.Size(64, 70)
        Me.btnStockIn.Text = "Stock In"
        Me.btnStockIn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 73)
        '
        'btnRecords
        '
        Me.btnRecords.AutoSize = False
        Me.btnRecords.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnCustomers, Me.btnSuppliers, Me.btnProducts, Me.btnStocks, Me.btnSales, Me.btnStaffs, Me.btnExpenses})
        Me.btnRecords.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnRecords.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnRecords.Image = CType(resources.GetObject("btnRecords.Image"), System.Drawing.Image)
        Me.btnRecords.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnRecords.Name = "btnRecords"
        Me.btnRecords.Size = New System.Drawing.Size(68, 75)
        Me.btnRecords.Text = "&Records"
        Me.btnRecords.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'btnCustomers
        '
        Me.btnCustomers.Name = "btnCustomers"
        Me.btnCustomers.Size = New System.Drawing.Size(152, 24)
        Me.btnCustomers.Text = "Customers"
        '
        'btnSuppliers
        '
        Me.btnSuppliers.Name = "btnSuppliers"
        Me.btnSuppliers.Size = New System.Drawing.Size(152, 24)
        Me.btnSuppliers.Text = "Suppliers"
        '
        'btnProducts
        '
        Me.btnProducts.Name = "btnProducts"
        Me.btnProducts.Size = New System.Drawing.Size(152, 24)
        Me.btnProducts.Text = "Products"
        '
        'btnStocks
        '
        Me.btnStocks.Name = "btnStocks"
        Me.btnStocks.Size = New System.Drawing.Size(152, 24)
        Me.btnStocks.Text = "Stock"
        '
        'btnSales
        '
        Me.btnSales.Name = "btnSales"
        Me.btnSales.Size = New System.Drawing.Size(152, 24)
        Me.btnSales.Text = "Sales"
        '
        'btnStaffs
        '
        Me.btnStaffs.Name = "btnStaffs"
        Me.btnStaffs.Size = New System.Drawing.Size(152, 24)
        Me.btnStaffs.Text = "Staff"
        '
        'btnExpenses
        '
        Me.btnExpenses.Name = "btnExpenses"
        Me.btnExpenses.Size = New System.Drawing.Size(152, 24)
        Me.btnExpenses.Text = "Expenses"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 73)
        '
        'btnDatabase
        '
        Me.btnDatabase.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnBackupDB, Me.btnRestoreDB})
        Me.btnDatabase.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnDatabase.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnDatabase.Image = CType(resources.GetObject("btnDatabase.Image"), System.Drawing.Image)
        Me.btnDatabase.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnDatabase.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnDatabase.Name = "btnDatabase"
        Me.btnDatabase.Size = New System.Drawing.Size(79, 70)
        Me.btnDatabase.Text = "Database"
        Me.btnDatabase.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'btnBackupDB
        '
        Me.btnBackupDB.Name = "btnBackupDB"
        Me.btnBackupDB.Size = New System.Drawing.Size(152, 24)
        Me.btnBackupDB.Text = "Backup"
        '
        'btnRestoreDB
        '
        Me.btnRestoreDB.Name = "btnRestoreDB"
        Me.btnRestoreDB.Size = New System.Drawing.Size(152, 24)
        Me.btnRestoreDB.Text = "Restore"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 73)
        '
        'btnReports
        '
        Me.btnReports.AutoSize = False
        Me.btnReports.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnStocksIn, Me.btnStocksOut, Me.btnDailySales, Me.WeeklySalesToolStripMenuItem, Me.MonthlySalesToolStripMenuItem})
        Me.btnReports.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnReports.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnReports.Image = CType(resources.GetObject("btnReports.Image"), System.Drawing.Image)
        Me.btnReports.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Size = New System.Drawing.Size(68, 75)
        Me.btnReports.Text = "&Reports"
        Me.btnReports.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'btnStocksIn
        '
        Me.btnStocksIn.Name = "btnStocksIn"
        Me.btnStocksIn.Size = New System.Drawing.Size(167, 24)
        Me.btnStocksIn.Text = "Stock In"
        '
        'btnStocksOut
        '
        Me.btnStocksOut.Name = "btnStocksOut"
        Me.btnStocksOut.Size = New System.Drawing.Size(167, 24)
        Me.btnStocksOut.Text = "Stock Out"
        '
        'btnDailySales
        '
        Me.btnDailySales.Name = "btnDailySales"
        Me.btnDailySales.Size = New System.Drawing.Size(167, 24)
        Me.btnDailySales.Text = "Daily Sales"
        '
        'WeeklySalesToolStripMenuItem
        '
        Me.WeeklySalesToolStripMenuItem.Name = "WeeklySalesToolStripMenuItem"
        Me.WeeklySalesToolStripMenuItem.Size = New System.Drawing.Size(167, 24)
        Me.WeeklySalesToolStripMenuItem.Text = "Weekly Sales"
        '
        'MonthlySalesToolStripMenuItem
        '
        Me.MonthlySalesToolStripMenuItem.Name = "MonthlySalesToolStripMenuItem"
        Me.MonthlySalesToolStripMenuItem.Size = New System.Drawing.Size(167, 24)
        Me.MonthlySalesToolStripMenuItem.Text = "Monthly Sales"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 73)
        '
        'btnSystemLogs
        '
        Me.btnSystemLogs.AutoSize = False
        Me.btnSystemLogs.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnSystemLogs.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnSystemLogs.Image = CType(resources.GetObject("btnSystemLogs.Image"), System.Drawing.Image)
        Me.btnSystemLogs.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnSystemLogs.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSystemLogs.Name = "btnSystemLogs"
        Me.btnSystemLogs.Size = New System.Drawing.Size(88, 72)
        Me.btnSystemLogs.Text = "System Logs"
        Me.btnSystemLogs.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btnSystemLogs.ToolTipText = "Staff"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 73)
        '
        'btnLogout
        '
        Me.btnLogout.AutoSize = False
        Me.btnLogout.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnLogout.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnLogout.Image = CType(resources.GetObject("btnLogout.Image"), System.Drawing.Image)
        Me.btnLogout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.btnLogout.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(59, 72)
        Me.btnLogout.Text = "Logout "
        Me.btnLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'MainPanel
        '
        Me.MainPanel.BackColor = System.Drawing.Color.SteelBlue
        Me.MainPanel.Controls.Add(Me.AnimationLabel)
        Me.MainPanel.Controls.Add(Me.lblDateTime)
        Me.MainPanel.Controls.Add(Me.Label2)
        Me.MainPanel.Controls.Add(Me.lblwelcome)
        Me.MainPanel.Controls.Add(Me.lblLogUser)
        Me.MainPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.MainPanel.Location = New System.Drawing.Point(0, 429)
        Me.MainPanel.Name = "MainPanel"
        Me.MainPanel.Size = New System.Drawing.Size(1176, 33)
        Me.MainPanel.TabIndex = 21
        '
        'AnimationLabel
        '
        Me.AnimationLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AnimationLabel.Font = New System.Drawing.Font("Trebuchet MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AnimationLabel.ForeColor = System.Drawing.Color.White
        Me.AnimationLabel.Location = New System.Drawing.Point(445, 7)
        Me.AnimationLabel.Name = "AnimationLabel"
        Me.AnimationLabel.Size = New System.Drawing.Size(287, 24)
        Me.AnimationLabel.TabIndex = 11
        Me.AnimationLabel.Text = "Powered by Jecmas Solutions"
        Me.AnimationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDateTime
        '
        Me.lblDateTime.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDateTime.AutoSize = True
        Me.lblDateTime.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateTime.Location = New System.Drawing.Point(850, 8)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(55, 21)
        Me.lblDateTime.TabIndex = 10
        Me.lblDateTime.Text = "00000"
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(748, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 21)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Date - Time :"
        '
        'lblwelcome
        '
        Me.lblwelcome.AutoSize = True
        Me.lblwelcome.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblwelcome.ForeColor = System.Drawing.Color.White
        Me.lblwelcome.Location = New System.Drawing.Point(10, 8)
        Me.lblwelcome.Name = "lblwelcome"
        Me.lblwelcome.Size = New System.Drawing.Size(90, 21)
        Me.lblwelcome.TabIndex = 10
        Me.lblwelcome.Text = "Welcome :"
        '
        'lblLogUser
        '
        Me.lblLogUser.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogUser.ForeColor = System.Drawing.Color.Maroon
        Me.lblLogUser.Location = New System.Drawing.Point(101, 8)
        Me.lblLogUser.Name = "lblLogUser"
        Me.lblLogUser.Size = New System.Drawing.Size(199, 21)
        Me.lblLogUser.TabIndex = 10
        Me.lblLogUser.Text = "00000"
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.AllowUserToResizeColumns = False
        Me.dgv.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.dgv.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv.BackgroundColor = System.Drawing.Color.White
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.DarkSlateGray
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgv.ColumnHeadersHeight = 25
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgv.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCode, Me.colName, Me.colTotal, Me.colQuantity, Me.colPackPrice})
        Me.dgv.Cursor = System.Windows.Forms.Cursors.Arrow
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.Transparent
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Brown
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgv.EnableHeadersVisualStyles = False
        Me.dgv.GridColor = System.Drawing.Color.LightGreen
        Me.dgv.Location = New System.Drawing.Point(0, 318)
        Me.dgv.MultiSelect = False
        Me.dgv.Name = "dgv"
        Me.dgv.ReadOnly = True
        Me.dgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.Transparent
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgv.RowHeadersWidth = 40
        Me.dgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black
        Me.dgv.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.dgv.RowTemplate.Height = 18
        Me.dgv.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgv.Size = New System.Drawing.Size(685, 98)
        Me.dgv.TabIndex = 55
        Me.dgv.Visible = False
        '
        'colCode
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.colCode.DefaultCellStyle = DataGridViewCellStyle3
        Me.colCode.HeaderText = "Product Code"
        Me.colCode.Name = "colCode"
        Me.colCode.ReadOnly = True
        Me.colCode.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'colName
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.colName.DefaultCellStyle = DataGridViewCellStyle4
        Me.colName.HeaderText = "Product Name / Description"
        Me.colName.Name = "colName"
        Me.colName.ReadOnly = True
        Me.colName.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.colName.Width = 350
        '
        'colTotal
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colTotal.DefaultCellStyle = DataGridViewCellStyle5
        Me.colTotal.HeaderText = "Cost Price"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.colTotal.Width = 110
        '
        'colQuantity
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colQuantity.DefaultCellStyle = DataGridViewCellStyle6
        Me.colQuantity.HeaderText = "Unit Price"
        Me.colQuantity.Name = "colQuantity"
        Me.colQuantity.ReadOnly = True
        Me.colQuantity.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.colQuantity.Width = 110
        '
        'colPackPrice
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colPackPrice.DefaultCellStyle = DataGridViewCellStyle7
        Me.colPackPrice.HeaderText = "Qty Left"
        Me.colPackPrice.Name = "colPackPrice"
        Me.colPackPrice.ReadOnly = True
        Me.colPackPrice.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.colPackPrice.Width = 110
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Text = "Tygen Sale System"
        Me.NotifyIcon1.Visible = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Timer2
        '
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        '
        'Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1176, 462)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.MainPanel)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "Menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tygen Sale System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.MainPanel.ResumeLayout(False)
        Me.MainPanel.PerformLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents btnRegistration As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator15 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents btnSystemLogs As System.Windows.Forms.ToolStripButton
    Public WithEvents btnProduct As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents btnStaff As System.Windows.Forms.ToolStripButton
    Public WithEvents btnCustomer As System.Windows.Forms.ToolStripButton
    Public WithEvents btnSupplier As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnCustomers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnSuppliers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnProducts As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnStocks As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnSales As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnExpenses As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents btnStockIn As System.Windows.Forms.ToolStripButton
    Public WithEvents btnRecords As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnShopping As System.Windows.Forms.ToolStripButton
    Public WithEvents btnStockEntry As System.Windows.Forms.ToolStripButton
    Public WithEvents btnLogout As System.Windows.Forms.ToolStripButton
    Public WithEvents btnDatabase As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents btnBackupDB As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnRestoreDB As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnCategory As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnExit As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnCompany As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ToolsMenu As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnCalculator As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnNotepad As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents HelpMenu As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnHelpContent As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnAbout As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents FileMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MainPanel As System.Windows.Forms.Panel
    Private WithEvents AnimationLabel As System.Windows.Forms.Label
    Public WithEvents lblDateTime As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents lblwelcome As System.Windows.Forms.Label
    Public WithEvents lblLogUser As System.Windows.Forms.Label
    Friend WithEvents btnLocations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnLockPC As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnPriceList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnTaskManager As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents colCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colQuantity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPackPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents btnStaffs As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents POSOptionsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnStockReport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnStockOutReport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnSalesReport As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnReports As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnStocksIn As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnStocksOut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnDailySales As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Public WithEvents SettingsMenu As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnDbConfigure As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnUserActivities As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ProfileMenu As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnChangePassword As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents btnProfile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnNewExpense As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WeeklySalesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MonthlySalesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColorThemeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
