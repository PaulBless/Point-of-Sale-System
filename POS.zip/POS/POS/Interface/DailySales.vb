﻿Public Class DailySales

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
    Sub GenerateSalesReport()
        Try
            Cursor = Cursors.WaitCursor
            Timer1.Enabled = True
            Dim objcmd As SqlCommand
            Dim objdr As SqlDataReader
            Dim objds As DataSet = New dsetTygen
            Dim sql As String = " select invoiceno, (invdate), (pname), (infoprice), (infoqty), (infototal) from product p inner join invoice_info info on p.productid= info.prod_id inner join invoice i on info.invoice_id=i.invid where  info.infodate=i.invdate and invdate =@d1 order by invdate desc"
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            objcmd = New SqlCommand(sql, myconnection)
            objcmd.CommandType = CommandType.Text
            objcmd.Parameters.Add("@d1", SqlDbType.Date, 30, "Date").Value = dtpDate.Value.Date
            objdr = objcmd.ExecuteReader()
            objds.Tables(0).Clear()
            objds.Tables(0).Load((objdr))
            objdr.Close()
            Dim rds As ReportDataSource = New ReportDataSource()
            rds.Name = "myDailySales"
            rds.Value = objds.Tables(0)
            Dim param As New List(Of ReportParameter)
            param.Add(New ReportParameter("pDate", Me.dtpDate.Value.Date))
            With Report
                .ReportViewer1.LocalReport.ReportEmbeddedResource = "POS.rptDailySales.rdlc"
                .ReportViewer1.LocalReport.DataSources.Clear()
                .ReportViewer1.LocalReport.DataSources.Add(rds)
                .ReportViewer1.LocalReport.SetParameters(param)
                .ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
                .ReportViewer1.Refresh()
                .Text = "Daily Sales"
                .ShowDialog()
            End With

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Information, "Sales Report Error")
        End Try
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Cursor = Cursors.Default
        Timer1.Enabled = False
    End Sub

    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        GenerateSalesReport()
    End Sub
End Class