﻿Public Class Splash
    Private Declare Function Sendmessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal aParam As Integer) As Integer
    Dim myprogress As Integer

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            Sendmessage(ProgressBar1.Handle, 1040, 3, 0)
            ''ProgressBar1.Increment(+1)
            ''ProgressBar1.Value += 1
            ProgressBar1.Value = ProgressBar1.Value + 1
            Label2.Text = ProgressBar1.Value & "%" & " complete"
            If ProgressBar1.Value = 15 Then
                Label1.Text = "Loading application modules.."
            End If
            If ProgressBar1.Value = 30 Then
                Label1.Text = "Reading Add-Ins and extensions.."
            End If
            If ProgressBar1.Value = 50 Then
                Label1.Text = "Loading and configuring database.."
            End If
            If ProgressBar1.Value = 70 Then
                Label1.Text = "Initializing Tools and Preferences.."
            End If
            If ProgressBar1.Value = 90 Then
                Label1.Text = "Setting application environment for use.."
            End If
            If ProgressBar1.Value = 100 Then
                'Timer1.Enabled = False
                Timer1.Stop()
                Login.Show()
                Me.Hide()
            End If

        Catch ex As ArgumentOutOfRangeException
            MessageBox.Show(ex.Message())
        Catch ex As ArgumentNullException
            MessageBox.Show(ex.Message())
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Sub CheckUserAccount()
        Try

        Catch ex As Exception

        End Try
    End Sub
    Sub CheckSchoolProfile()
        Try

        Catch ex As Exception

        End Try
    End Sub
    Private Sub Splash_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
       
    End Sub
    Sub changecolor()
        Dim formcolor As String = "#c8c8c8"
        Me.BackColor = ColorTranslator.FromHtml(formcolor)
    End Sub
End Class