﻿Imports System.Data.SqlClient

Public Class ProductRecord
    Sub GetProductsRecord()
        Try
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            query = "SELECT productid, pcode, pname, catname, pcostprice, punitprice, preorderlevel FROM product,category where product.pcatid = category.id order by pname"
            command1 = New SqlCommand(query, Dbconnection)
            dreader = command1.ExecuteReader()
            While dreader.Read()
                dgw.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), "Gh¢" + Format(dreader(4), "#,##0.00"), "Gh¢" + Format(dreader(5), "#,##0.00"), dreader(6))
            End While
        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Information, "Message")
        End Try
    End Sub
    Private Sub txtProductName_TextChanged(sender As Object, e As EventArgs) Handles txtProductName.TextChanged
        Try
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            query = "SELECT productid, pcode, pname, catname, pcostprice, punitprice, preorderlevel FROM product,category where product.pcatid = category.id and pname like '%" & txtProductName.Text & "%' order by pname"
            command1 = New SqlCommand(query, Dbconnection)
            dreader = command1.ExecuteReader()
            While dreader.Read()
                dgw.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), "Gh¢" + Format(dreader(4), "#,##0.00"), "Gh¢" + Format(dreader(5), "#,##0.00"), dreader(6))
            End While
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try
    End Sub

    Private Sub ProductRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetProductsRecord()
        dgw.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    End Sub

    Private Sub txtCategory_TextChanged(sender As Object, e As EventArgs) Handles txtCategory.TextChanged
        Try
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            query = "SELECT productid, pcode, pname, catname, pcostprice, punitprice, preorderlevel FROM product,category where product.pcatid = category.id and catname like '%" & txtCategory.Text & "%' order by catname"
            command1 = New SqlCommand(query, Dbconnection)
            dreader = command1.ExecuteReader()
            While dreader.Read()
                dgw.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), "Gh¢" + Format(dreader(4), "#,##0.00"), "Gh¢" + Format(dreader(5), "#,##0.00"), dreader(6))
            End While
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try
    End Sub

    Private Sub txtCode_TextChanged(sender As Object, e As EventArgs) Handles txtCode.TextChanged
        Try
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            query = "SELECT productid, pcode, pname, catname, pcostprice, punitprice, preorderlevel FROM product,category where product.pcatid = category.id and pcode like '%" & txtCode.Text & "%' order by pname"
            command1 = New SqlCommand(query, Dbconnection)
            dreader = command1.ExecuteReader()
            While dreader.Read()
                dgw.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), "Gh¢" + Format(dreader(4), "#,##0.00"), "Gh¢" + Format(dreader(5), "#,##0.00"), dreader(6))
            End While
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try
    End Sub
    Sub Reset()
        txtCode.Text = ""
        txtCategory.Text = ""
        txtProductName.Text = ""
        dgw.Rows.Clear()
    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub dgw_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgw.RowsAdded
        For Each row As DataGridViewRow In dgw.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub

End Class