﻿Imports System.Data.SqlClient

Public Class ProductList
    Public Property CurrentActiveForm() As Stock
    Private Sub ProductList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetProductList()
    End Sub
    Private Sub GetProductList()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select productid,pcode,pname,punitprice from product order by pname"
            command = New SqlCommand(query, myconnection)
            dtable = New DataTable()
            dadapter = New SqlDataAdapter(command)
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of available products found in the system", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    'get products info 
                    dgv.Rows(i).Cells(0).Value = item("productid").ToString()
                    dgv.Rows(i).Cells(1).Value = item("pcode").ToString()
                    dgv.Rows(i).Cells(2).Value = item("pname").ToString()
                    dgv.Rows(i).Cells(3).Value = Format(item("punitprice"), "#,##0.")
                Next
            End If
        Catch ex As SqlException
            MessageBox.Show(ex.Message(), "Sql Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Critical, "Sale System Error")
        End Try
    End Sub
    Sub FetchProducts()
        ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
        ''Dbconnection.Open()
        ConnectDB()
        query = "select productid,pcode,pname,punitprice,stocklevel from product p inner join temp_stock ts on p.productid=ts.prodid order by pname"
        command = New SqlCommand(query, myconnection)
        dtable = New DataTable()
        dadapter = New SqlDataAdapter(command)
        dadapter.Fill(dtable)
        If (dtable.Rows.Count = 0) Then
            MessageBox.Show("No record of products + stock found." + vbLf + "List of available products would be shown", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            'dgv.Rows.Clear()
            'get products info with no stocklevel record
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Dim str As String = "select productid,pcode,pname,punitprice from product order by pname"
            command1 = New SqlCommand(str, myconnection)
            dreader = command1.ExecuteReader(CommandBehavior.CloseConnection)
            While dreader.Read()
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), Format(dreader(3), "#,#0."))
            End While
        Else
            dgv.Rows.Clear()
            For Each item As DataRow In dtable.Rows
                Dim i As Integer = dgv.Rows.Add()
                'get products info with stocklevel
                dgv.Rows(i).Cells(0).Value = item("productid").ToString()
                dgv.Rows(i).Cells(1).Value = item("pcode").ToString()
                dgv.Rows(i).Cells(2).Value = item("pname").ToString()
                dgv.Rows(i).Cells(3).Value = Format(item("punitprice"), "#,##0.")
                dgv.Rows(i).Cells(4).Value = item("stocklevel").ToString()
            Next
        End If

    End Sub

    Private Sub dgv_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgv.CellFormatting
        'dgv.Rows(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    End Sub
    Private Sub dgv_MouseClick(sender As Object, e As MouseEventArgs) Handles dgv.MouseClick
        Try
            If dgv.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgv.SelectedRows(0)
                'determine the current active form
                'using active form method : display record to active form - stock
                CurrentActiveForm.Show()
                CurrentActiveForm.Activate()
                CurrentActiveForm.txtProductID.Text = dr.Cells(0).Value.ToString()
                CurrentActiveForm.txtProductCode.Text = dr.Cells(1).Value.ToString()
                CurrentActiveForm.txtProductName.Text = dr.Cells(2).Value.ToString()
                CurrentActiveForm.txtPrice.Text = dr.Cells(3).Value.ToString()
                'If Not dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value = String.Empty Then
                '    CurrentActiveForm.txtStock.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value.ToString()
                'Else
                '    CurrentActiveForm.txtStock.Text = "0"
                'End If

                'get current stocklevel of item
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                Dim cmd As New SqlCommand("select RTRIM(stocklevel) from temp_stock where prodid='" & dgv.SelectedRows(0).Cells(0).Value & "'", myconnection)
                dreader = cmd.ExecuteReader()
                If dreader.Read() Then
                    CurrentActiveForm.txtStock.Text = dreader(0).ToString()
                    dreader.Close()
                Else
                    CurrentActiveForm.txtStock.Text = "0"
                End If
                CurrentActiveForm.btnAdd.Enabled = True
                Me.Close()  'close popup form
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message(), "Sale System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        dgv.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft

        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub

    Private Sub txtSupplierID_TextChanged(sender As Object, e As EventArgs) Handles txtSupplierID.TextChanged
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select productid,pcode,pname,punitprice from product where pname like '%" & txtSupplierID.Text & "%' order by pname"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader()
            dgv.Rows.Clear()
            While dreader.Read()
                dgv.Rows.Add(dreader(0), dreader(1), dreader(2), Format(dreader(3), "#,##0."))
            End While
            myconnection.Close()
        Catch ex As SqlException
            MessageBox.Show(ex.Message(), "Sql Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Critical, "Sale System Error")
        End Try
    End Sub
End Class