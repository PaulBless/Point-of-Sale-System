﻿Imports System.Runtime.CompilerServices
Imports System.Data.SqlClient

Public Class Stock
    Dim newid As Integer = 0
    Dim newprice, nid As String

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If txtProductCode.Text = "" Then
            MessageBox.Show("Please retrieve product code or information", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtProductCode.Focus()
            Exit Sub
        End If
        If txtQty.Text = "" Then
            MessageBox.Show("Please enter quantity", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtQty.Focus()
            Exit Sub
        End If
        If txtQty.Text = 0 Then
            MessageBox.Show("Quantity can not be zero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtQty.Focus()
            Exit Sub
        End If

        'check item exists in gridview
        Dim i As Integer
        Dim itemloc As Integer = -1
        For i = 0 To dgv.Rows.Count - 1
            If dgv.Rows(i).Cells(0).Value = Me.txtProductID.Text Then
                itemloc = i     'item is found in gridview
                Exit For
            End If
        Next

        If itemloc = -1 Then
            'if item not found, add value to gridview
            dgv.Rows.Add(txtProductID.Text, txtProductCode.Text, txtProductName.Text, txtQty.Text, txtPrice.Text, newprice)
            'compute total price
            Dim sum As Double = 0
            For i = 0 To dgv.Rows.Count - 1
                sum += dgv.Rows(i).Cells(5).Value
                txtGrandTotal.Text = sum
                txtPaymentDue.Text = txtGrandTotal.Text
            Next
            ClearItemInfo()            'clear the textfields for new item
            Exit Sub
        Else
            'increase quantity and totalprice if item is found in gridview/cart
            Dim itemqty As Long = dgv.Rows(itemloc).Cells(3).Value
            itemqty = itemqty + Val(txtQty.Text)
            Dim nprice As Decimal = (dgv.Rows(itemloc).Cells(4).Value) * itemqty
            Dim formatvalue As Integer = Format(nprice, "#,#0.00")
            dgv.Rows(itemloc).Cells(3).Value = itemqty
            dgv.Rows(itemloc).Cells(5).Value = nprice
            'compute total price
            Dim sum As Double = 0
            For i = 0 To dgv.Rows.Count - 1
                sum += dgv.Rows(i).Cells(5).Value
                txtGrandTotal.Text = sum
                txtPaymentDue.Text = txtGrandTotal.Text
            Next
            ClearItemInfo()
        End If
    End Sub
    Public Function GrandTotal() As Double
        Dim sum As Double = 0
        Try
            For Each r As DataGridViewRow In Me.dgv.Rows
                sum = sum + r.Cells(5).Value
            Next
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
        Return sum
    End Function
    Sub ClearItemInfo()
        txtProductID.Text = ""
        txtProductCode.Text = ""
        txtProductName.Text = ""
        txtStock.Text = ""
        txtTotalStock.Text = ""
        txtQty.Text = ""
        txtPrice.Text = ""
        btnAdd.Enabled = False
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If dgv.Rows.Count = 0 Then
            MessageBox.Show("Sorry.. No product with stocking history found to process. Please check..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        If txtPaymentTotal.Text = "" Then
            MessageBox.Show("Please enter total stock payment..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPaymentTotal.Focus()
            Exit Sub
        End If
        If Val(txtPaymentTotal.Text) > Val(txtGrandTotal.Text) Then
            MessageBox.Show("Stock payment total can not be more than grand total", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtPaymentTotal.SelectAll()
            Exit Sub
        End If
        If (dtpPayDue.Value.Date = Date.Today) And (Val(txtPaymentTotal.Text) < Val(txtGrandTotal.Text)) Then
            MessageBox.Show("Please specify date for due payment of the stock items", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If

        If MsgBox("Are you sure you want to add this stock record?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = MsgBoxResult.Yes Then
            'step 1: save record into stock table 
            Try
                For Each row As DataGridViewRow In dgv.Rows
                    ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                    ''Dbconnection.Open()
                    ConnectDB()
                    query = "insert into stock(stockid,product_id,quantity,price,totalamount,datein) values (@d1,@d2,@d3,@d4,@d5,@d6)"
                    command = New SqlCommand(query, myconnection)
                    command.Parameters.AddWithValue("@d1", txtStockID.Text)
                    command.Parameters.AddWithValue("@d2", row.Cells(0).Value)
                    command.Parameters.AddWithValue("@d3", row.Cells(3).Value)
                    command.Parameters.AddWithValue("@d4", row.Cells(4).Value)
                    command.Parameters.AddWithValue("@d5", row.Cells(5).Value)
                    command.Parameters.AddWithValue("@d6", Date.Now)
                    command.ExecuteNonQuery()
                Next
            Catch ex As Exception
                MsgBox(ex.ToString(), , "Stock Error")
            End Try

            'step 2: save record into stockpayment table
            Try
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                Const st As String = "insert into stock_payment(stock_id,supplier_id,grandtotal,totalpayment,paymentdue,payduedate,stockdate) values (@d1,@d2,@d3,@d4,@d5,@d6,@d7)"
                Dim com As SqlCommand = New SqlCommand(st, myconnection)
                com.Parameters.AddWithValue("@d1", Val(txtSt_Id.Text))
                com.Parameters.AddWithValue("@d2", Val(txtSID.Text))
                com.Parameters.AddWithValue("@d3", Val(txtGrandTotal.Text))
                com.Parameters.AddWithValue("@d4", Val(txtPaymentTotal.Text))
                com.Parameters.AddWithValue("@d5", Val(txtPaymentDue.Text))
                com.Parameters.AddWithValue("@d6", dtpPayDue.Value.ToString())
                com.Parameters.AddWithValue("@d7", Date.Now)
                com.ExecuteNonQuery()
                com.Parameters.Clear()
            Catch ex As Exception
                MsgBox(ex.ToString(), , "Stock Payment Error")
            End Try

            Try
                'finally: save temp_stock record
                For Each r As DataGridViewRow In dgv.Rows
                    ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                    ''Dbconnection.Open()
                    ConnectDB()
                    'step 1: check item in temp_stock list/table and update if exists else insert as new stock
                    Dim cmd As SqlCommand = New SqlCommand("SELECT prodid FROM temp_stock where prodid=@d1", myconnection)
                    cmd.Parameters.AddWithValue("@d1", r.Cells(0).Value)
                    dreader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                    If dreader.Read() Then
                        dreader.Close()
                        'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                        'Dbconnection.Open()
                        ConnectDB()
                        Dim cmd1 As SqlCommand = New SqlCommand("UPDATE temp_stock SET stocklevel=stocklevel + (" & r.Cells(3).Value & ") where prodid=@prodid", myconnection)
                        cmd1.Parameters.AddWithValue("@prodid", r.Cells(0).Value)
                        cmd1.ExecuteNonQuery()
                        cmd1.Parameters.Clear()
                    Else
                        ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                        ''Dbconnection.Open()
                        ConnectDB()
                        'take new stockin if productid does not exists in temporary stocks
                        Dim cmd2 As SqlCommand = New SqlCommand("INSERT INTO temp_stock(prodid,stocklevel) values (@d1,@d2)", myconnection)
                        cmd2.Parameters.AddWithValue("@d1", r.Cells(0).Value)
                        cmd2.Parameters.AddWithValue("@d2", r.Cells(3).Value)
                        cmd2.ExecuteNonQuery()
                        cmd2.Parameters.Clear()
                    End If
                Next
            Catch ex As Exception
                MsgBox(ex.ToString(), , "Temporary-stock Error")
            End Try
            AllUserActivities(LogFullName + ", added new stock record with Stock ID: " + txtStockID.Text + " and Supplier ID: " + txtSup_ID.Text + " into the system on " & DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString())
            MessageBox.Show("Stock successfully added", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Reset()
        End If
    End Sub
    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
       'using another method
        Dim fm As New StockList
        fm.CurrentActiveForm = Me
        fm.Reset()
        fm.ShowDialog()
    End Sub
    Private Sub btnSearch_Click_1(sender As Object, e As EventArgs) Handles btnSearch.Click
        ''using supplier_list form
        'Dim frm As New SupplierList
        'frm.CurrentActiveForm = Me
        'frm.ShowDialog()

        'Using supplier_record form
        Dim frm As New SupplierRecord
        frm.CurrentForm_Stock = Me
        frm.lblSet.Text = "Stock Entry"
        frm.Reset()
        frm.ShowDialog()
    End Sub
    Private Sub btnRetrieve_Click(sender As Object, e As EventArgs) Handles btnRetrieve.Click
        'another method()
        Dim frm As New ProductList
        frm.CurrentActiveForm = Me
        frm.ShowDialog()
    End Sub
    Private Sub txtSup_ID_TextChanged(sender As Object, e As EventArgs) Handles txtSup_ID.TextChanged
        If (txtSup_ID.Text = "") Then
            ClearValues()
        Else
            Try
                If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                Dbconnection.Open()
                query = "select supplierid, supplier_id, name, contactno, location from supplier where supplier_id='" & txtSup_ID.Text & "'"
                command = New SqlCommand(query, Dbconnection)
                dtable = New DataTable()
                dadapter = New SqlDataAdapter(command)
                dadapter.Fill(dtable)
                For Each item As DataRow In dtable.Rows
                    txtSID.Text = item("supplierid").ToString()
                    txtSup_ID.Text = item("supplier_id").ToString()
                    txtSupplierName.Text = item("name").ToString()
                    txtContact.Text = item("contactno").ToString()
                    txtLocation.Text = item("location").ToString()
                Next

            Catch ex As SqlException
                ''MessageBox.Show(ex.Message)
            Catch ex As Exception
                ''MsgBox(ex.Message)
            End Try
        End If
    End Sub
    Sub ClearValues()
        txtLocation.Text = ""
        txtContact.Text = ""
        txtSupplierName.Text = ""
        txtSup_ID.Text = ""
        txtSID.Text = ""
    End Sub
    Private Sub txtProductCode_TextChanged(sender As Object, e As EventArgs) Handles txtProductCode.TextChanged
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select productid,pcode,pname,punitprice,stocklevel from product p inner join temp_stock ts on p.productid=ts.prodid where p.pcode='" & txtProductCode.Text & "'"
            command = New SqlCommand(query, myconnection)
            dtable = New DataTable()
            dadapter = New SqlDataAdapter(command)
            dadapter.Fill(dtable)
            For Each item As DataRow In dtable.Rows
                txtProductID.Text = item("productid").ToString()
                txtProductCode.Text = item("pcode").ToString()
                txtProductName.Text = item("pname").ToString()
                txtPrice.Text = Format(item("punitprice").ToString(), "#,##0.")
                txtStock.Text = item("stocklevel").ToString()
            Next

        Catch ex As SqlException
            MessageBox.Show(ex.Message)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub Stock_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetStockId()
    End Sub
    Sub GetStockId()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            'Dim yy As DateTime = DateTime.Now.ToString("yy")
            Const str As String = "SELECT Max(stid) FROM stock"
            command1 = New SqlCommand(str, myconnection)
            dreader = command1.ExecuteReader(CommandBehavior.CloseConnection)
            While dreader.Read()
                If Not dreader.HasRows Or IsDBNull(dreader.Item(0)) Then
                    newid = 1
                    txtSt_Id.Text = newid.ToString()
                    txtStockID.Text = "ST/" & DateTime.Now.Year & Now.Month & "-01"
                Else
                    newid = (dreader.Item(0).ToString())
                    newid += 1
                    txtSt_Id.Text = newid.ToString()
                    txtStockID.Text = "ST/" & DateTime.Now.Year & Now.Month & newid.ToString("-00")
                End If
            End While
            DisconnectDB()
        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Exclamation, "System Error")
        End Try
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Reset()
    End Sub
    Sub Reset()
        ClearItemInfo()
        ClearValues()
        txtSt_Id.Text = ""
        txtStockID.Text = ""
        txtGrandTotal.Text = ""
        txtPaymentTotal.Text = ""
        txtPaymentDue.Text = ""
        dtpPayDue.Text = Today
        txtSup_ID.Focus()
        btnSave.Enabled = True
        btnUpdate.Enabled = False
        dgv.Rows.Clear()
        GetStockId()
    End Sub
    Private Sub txtQty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQty.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Private Sub txtQty_TextChanged(sender As Object, e As EventArgs) Handles txtQty.TextChanged
        'remove and replace commas
        newprice = txtPrice.Text.Replace(",", "")
        Try
            'calculate total stocklevel of product/item
            Dim current_stock, qty, newStock As Integer
            If txtQty.Text = "" Then
                txtTotalStock.Text = txtStock.Text
            Else
                current_stock = Val(txtStock.Text)
                qty = Val(txtQty.Text)
                newStock = (current_stock + qty)
                txtTotalStock.Text = newStock
            End If
            'calculate totalamt of product stocking
            newprice *= Val(txtQty.Text)
        Catch ex As OverflowException

        Catch ex As Exception

        End Try
    End Sub
    Sub Compute()
        Dim i As Double = 0
        i = Val(txtGrandTotal.Text) - Val(txtPaymentTotal.Text)
        i = Math.Round(i, 2)
        txtPaymentDue.Text = i
    End Sub
   Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If dgv.Rows.Count < 1 Then
            MsgBox("There is no record of products/items", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Message")
        End If
        If MessageBox.Show("Remove the selected item from the stocking list?", "Confirm Remove", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                For Each r As DataGridViewRow In dgv.SelectedRows
                    dgv.Rows.Remove(r)
                Next
                Dim k As Double = 0
                k = GrandTotal()
                k = Math.Round(k, 2)
                txtGrandTotal.Text = k
                Compute()
            Catch ex As Exception

            End Try
        End If
    End Sub
    Private Sub txtPaymentTotal_TextChanged(sender As Object, e As EventArgs) Handles txtPaymentTotal.TextChanged
        Compute()
    End Sub
    Private Sub dgv_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellDoubleClick
        Try
            txtProductID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtProductCode.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            txtProductName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
            txtQty.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value
            txtPrice.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            Dim st As String = "select stocklevel from temp_stock where prodid='" & dgv.SelectedRows(0).Cells(0).Value & "'"
            Dim com As New SqlCommand(st, Dbconnection)
            dreader = com.ExecuteReader()
            If (dreader.HasRows()) Then
                dreader.Read()
                txtStock.Text = dreader(0).ToString()
            Else
                txtStock.Text = "0"
            End If
            txtTotalStock.Text = ""
            btnAdd.Enabled = True
            btnUpdate.Enabled = True
        Catch ex As Exception

        End Try
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            If dgv.Rows.Count = 0 Then
                MessageBox.Show("Sorry.. No product with stocking history found to process. Please check..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If dgv.SelectedRows(0).Cells(3).Value = txtQty.Text Then
                MsgBox("Please, make sure you give new values (quantity) to the products selected in gridview", MsgBoxStyle.Exclamation, "Update Error")
                Exit Sub
            End If
            If txtPaymentTotal.Text = "" Then
                MessageBox.Show("Please enter stock payment total..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtPaymentTotal.Focus()
                Exit Sub
            End If
            If Val(txtPaymentTotal.Text) > Val(txtGrandTotal.Text) Then
                MessageBox.Show("Stock payment total can not be more than grand total", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtPaymentTotal.SelectAll()
                Exit Sub
            End If
            If dtpPayDue.Value.ToString() = Today Then
                MessageBox.Show("Please specify date for payment of the stock items", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            If MsgBox("Are you sure you want the stock record?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = MsgBoxResult.Yes Then
                'first update stocks
                If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                Dbconnection.Open()
                For Each row As DataGridViewRow In dgv.Rows
                    ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                    ''Dbconnection.Open()
                    ConnectDB()
                    query = "update stock set quantity=@d2, price=@d3, totalamount=@d4 where stockid=@d1"
                    command = New SqlCommand(query, myconnection)
                    command.Parameters.AddWithValue("@d2", row.Cells(3).Value)
                    command.Parameters.AddWithValue("@d3", row.Cells(4).Value)
                    command.Parameters.AddWithValue("@d4", row.Cells(5).Value)
                    command.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                    command.ExecuteNonQuery()
                Next

                'second update stockpayment
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                query = "update stock_payment set grandtotal=@d2, totalpayment=@d3, paymentdue=@d4, payduedate=@d5 where stock_id=@d1"
                command = New SqlCommand(query, myconnection)
                command.Parameters.AddWithValue("@d2", txtGrandTotal.Text)
                command.Parameters.AddWithValue("@d3", txtPaymentTotal.Text)
                command.Parameters.AddWithValue("@d4", txtPaymentDue.Text)
                command.Parameters.AddWithValue("@d5", dtpPayDue.Text.ToString())
                command.Parameters.AddWithValue("@d1", txtSt_Id.Text)
                command.ExecuteNonQuery()

                'finally: save temp_stock record
                For Each r As DataGridViewRow In dgv.Rows
                    ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                    ''Dbconnection.Open()
                    ConnectDB()
                    Dim cmd As SqlCommand = New SqlCommand("SELECT prodid FROM temp_stock where prodid=@d1", myconnection)
                    cmd.Parameters.AddWithValue("@d1", r.Cells(0).Value)
                    dreader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                    If dreader.Read() Then
                        dreader.Close()
                        ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                        ''Dbconnection.Open()
                        ConnectDB()
                        Dim cmd1 As SqlCommand = New SqlCommand("UPDATE temp_stock SET stocklevel=stocklevel + (" & r.Cells(3).Value & ") where prodid=@prodid", myconnection)
                        cmd1.Parameters.AddWithValue("@prodid", r.Cells(0).Value)
                        cmd1.ExecuteNonQuery()
                        cmd1.Parameters.Clear()
                    End If
                Next

                AllUserActivities(LogFullName + ", updated the stock record with Stock ID: " + txtStockID.Text + " and Supplier ID: " + txtSup_ID.Text + " in the system on " & DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString())
                MessageBox.Show("Stock record  updated!", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString(), , "Update Stock Error")
        End Try
    End Sub

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub
End Class