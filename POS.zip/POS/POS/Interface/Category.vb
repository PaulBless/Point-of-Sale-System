﻿Imports System.Data.SqlClient

Public Class Category
    Private Sub GetCategories()
        Try
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            query = "select id,catname,description from category order by catname asc"
            dadapter = New SqlDataAdapter(query, Dbconnection)
            dtable = New DataTable()
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of categories types found.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                dgv.Rows.Clear()
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    dgv.Rows(i).Cells(0).Value = item("id").ToString()
                    dgv.Rows(i).Cells(1).Value = item("catname").ToString()
                    dgv.Rows(i).Cells(2).Value = item("description").ToString()
                Next
            End If

        Catch ex As SqlException
            MessageBox.Show(ex.Message)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub dgv_MouseClick(sender As Object, e As MouseEventArgs) Handles dgv.MouseClick
        Try
            txtCategory.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            txtDescription.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
            txtCatName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            btnUpdate.Enabled = True
            btnDelete.Enabled = True
            btnSave.Enabled = False
        Catch ex As Exception

        End Try
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Sub Reset()
        txtCategory.Text = ""
        txtDescription.Text = ""
        btnSave.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        txtCategory.Focus()
        GetCategories()
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Reset()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtCategory.Text = "" Then
            MessageBox.Show("Please enter category", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtCategory.Focus()
            Return
        End If
        Try
            'check product name exists
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            Const check As String = "select RTRIM(catname) from category where catname=@d1"
            command = New SqlCommand(check)
            command.Parameters.AddWithValue("@d1", txtCategory.Text)
            command.Connection = Dbconnection
            dreader = command.ExecuteReader()
            If dreader.Read() Then
                dreader.Close()
                MessageBox.Show("The category '" & txtCategory.Text & "' is already added", "Record Exists", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            End If
            'proceed to save record
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            query = "insert into category(catname, description) VALUES (@d1,@d2)"
            command = New SqlCommand(query, Dbconnection)
            command.Parameters.AddWithValue("@d1", txtCategory.Text)
            command.Parameters.AddWithValue("@d2", txtDescription.Text)
            Dbconnection.Open()
            command.ExecuteNonQuery()
            AllUserActivities(LogFullName + ", added a new category with name '" & txtCategory.Text & "' on " & DateTime.Now)
            MessageBox.Show("Record saved", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Reset()
        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Information, "save error")
        End Try
    End Sub

    Private Sub Category_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        GetCategories()
    End Sub

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub
    Sub UpdateRecord()
        Try
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            query = "update category set catname=@d1, description=@d2 where id='" & dgv.SelectedRows(0).Cells(0).Value & "'"
            command = New SqlCommand(query, Dbconnection)
            command.Parameters.AddWithValue("@d1", txtCategory.Text)
            command.Parameters.AddWithValue("@d2", txtDescription.Text)
            Dbconnection.Open()
            command1.ExecuteReader()
            Dbconnection.Close()
            AllUserActivities(LogFullName & ", updated the product category '" & txtCatName.Text & "' on " & Now)
            MsgBox("Record updated!", MsgBoxStyle.Information, "Sale System")
            Reset()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Update Record Error")
        End Try

    End Sub
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        UpdateRecord()
    End Sub
    Sub DeleteRecord()
        Try
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            query = "delete from category where id='" & dgv.SelectedRows(0).Cells(0).Value & "'"
            command1 = New SqlCommand(query, Dbconnection)
            Dbconnection.Open()
            command1.ExecuteReader()
            Dbconnection.Close()
            AllUserActivities(LogFullName & ", deleted the product category '" & txtCategory.Text & "' from system on " & Now)
            MsgBox("Record deleted!", MsgBoxStyle.Information, "Sale System")
            Reset()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Deletion Record Error")
        End Try

    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MsgBox("Permanently delete '" & txtCategory.Text & "' from system?", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Confirmation") = DialogResult.OK Then
            DeleteRecord()
        End If
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
End Class