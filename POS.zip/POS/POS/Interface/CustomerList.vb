﻿Imports System.Data.SqlClient

Public Class CustomerList
    Public Property CurrentActiveForm() As Sale
    Private Sub CustomerList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetCustomerList()
    End Sub
    Private Sub GetCustomerList()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select customerid,name,gender,contactno from customer order by name"
            command = New SqlCommand(query, myconnection)
            dtable = New DataTable()
            dadapter = New SqlDataAdapter(command)
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of available customers found in the system", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    'get customers info 
                    dgv.Rows(i).Cells(0).Value = item("customerid").ToString()
                    dgv.Rows(i).Cells(1).Value = item("name").ToString()
                    dgv.Rows(i).Cells(2).Value = item("gender").ToString()
                    dgv.Rows(i).Cells(3).Value = (item("contactno").ToString())
                Next
            End If
        Catch ex As SqlException
            MessageBox.Show(ex.ToString())
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub
    Private Sub dgv_MouseClick(sender As Object, e As MouseEventArgs) Handles dgv.MouseClick
        Try
            If dgv.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgv.SelectedRows(0)
                'determine the current active form
                'using active form method : display record to active form - stock
                CurrentActiveForm.Show()
                CurrentActiveForm.Activate()
                CurrentActiveForm.txtCustomer.Text = dr.Cells(1).Value.ToString()
                Me.Close()  'close popup form
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub

End Class