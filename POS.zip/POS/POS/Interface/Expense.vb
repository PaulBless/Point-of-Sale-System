﻿Imports System.Data.SqlClient
Public Class Expense
    Sub GetExpenses()
        Try
            ConnectDB()
            query = "select id,title,amount,description,date,createdby from expense order by date desc"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader()
            dgv.Rows.Clear()
            While (dreader.Read()) = True
                dgv.Rows.Add(dreader(0), dreader(1), Format(dreader(2), "#,##.00"), dreader(3), dreader(4), dreader(5))
            End While
            myconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Exclamation, "Sale System Error")
        End Try
    End Sub
    Sub SaveExpense()
        Try
            ConnectDB()
            query = "insert into expense (title,amount,description,date,createdby) values (@d1,@d2,@d3,@d4,@d5)"
            command = New SqlCommand(query, myconnection)
            command.Parameters.AddWithValue("@d1", txtTitle.Text)
            command.Parameters.AddWithValue("@d2", txtAmount.Text)
            command.Parameters.AddWithValue("@d3", txtDescription.Text)
            command.Parameters.AddWithValue("@d4", (Date.Now))
            command.Parameters.AddWithValue("@d5", LogUsername)
            command.ExecuteNonQuery()
            AllUserActivities(LogFullName & ", added a new expense record with the title:" & txtTitle.Text & " on " & Date.Now)
            MsgBox("Expense record saved..", MsgBoxStyle.Information, "Sale System")
            Reset()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Sale System Error")
        End Try
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        If txtAmount.Text = "" Then
            MsgBox("Please enter expense amount.", MsgBoxStyle.Information, "Error")
            txtAmount.Focus()
            Exit Sub
        End If
        If txtTitle.Text = "" Then
            MsgBox("Please enter the expense title.", MsgBoxStyle.Information, "Error")
            txtTitle.Focus()
            Exit Sub
        End If
        If txtDescription.Text = "" Then
            MsgBox("Please enter expense description.", MsgBoxStyle.Information, "Error")
            txtAmount.Focus()
            Exit Sub
        End If
        If MsgBox("Are you sure you want to create and save this expense record.", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = DialogResult.Yes Then
            SaveExpense()
        End If
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Sub Reset()
        dtpDate.Text = Now
        txtDescription.Text = ""
        txtAmount.Text = ""
        txtTitle.Text = ""
        dgv.Rows.Clear()
        GetExpenses()

    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub
    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
    Private Sub dgv_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellDoubleClick
        Dim fm As New ExpenseList
        fm.txtTitle.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
        fm.txtAmount.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
        fm.txtDescription.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value
        fm.dtpDate.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value
        fm.txtCreatedby.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value
        fm.ShowDialog()
    End Sub
    Private Sub dgv_Click(sender As Object, e As EventArgs) Handles dgv.Click
        dgv.SelectAll()
    End Sub

    Private Sub Expense_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetExpenses()
    End Sub
    Private Sub txtAmount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAmount.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Private Sub txtTitle_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTitle.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
End Class