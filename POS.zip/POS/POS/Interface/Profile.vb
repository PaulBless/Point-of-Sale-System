﻿Imports System.Data.SqlClient

Public Class Profile
    Sub GetProfile()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            command = New SqlCommand("select fullname, mobileno, location,username,password from staff where staffid=@d1 or username=@d2", myconnection)
            command.Parameters.AddWithValue("@d1", LogUid)
            command.Parameters.AddWithValue("@d2", LogUsername)
            dreader = command.ExecuteReader()
            While (dreader.Read() = True)
                txtName.Text = dreader(0).ToString()
                txtMobile.Text = dreader(1).ToString()
                txtLocation.Text = dreader(2).ToString()
                txtUser.Text = dreader(3).ToString()
                txtPassword.Text = DecryptPassword(dreader(4).ToString())
                txtPassword.PasswordChar = "•"
            End While
            command.Dispose()
            dreader.Close()
            'Dbconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Get Profile Error")
        End Try
    End Sub
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            txtPassword.PasswordChar = ""
        Else
            txtPassword.PasswordChar = "•"
        End If
    End Sub
    Private Sub Profile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetProfile()
    End Sub
End Class