﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles

Public Class Supplier

    Dim newid As Integer
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub GetSuppliers()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "select supplierid,supplier_id,name,contactno, location, email,address from supplier order by name asc"
            dadapter = New SqlDataAdapter(query, myconnection)
            dtable = New DataTable()
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of suppliers found.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                dgv.Rows.Clear()
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    dgv.Rows(i).Cells(0).Value = (item("supplierid").ToString())
                    dgv.Rows(i).Cells(1).Value = (item("supplier_id").ToString())
                    dgv.Rows(i).Cells(2).Value = item("name").ToString()
                    dgv.Rows(i).Cells(3).Value = (item("contactno").ToString())
                    dgv.Rows(i).Cells(4).Value = (item("location").ToString())
                    dgv.Rows(i).Cells(5).Value = (item("email").ToString())
                    dgv.Rows(i).Cells(6).Value = (item("address").ToString())
                Next
            End If

        Catch ex As SqlException
            MessageBox.Show(ex.Message)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub GetSupplierId()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Const str As String = "SELECT  Max(Right(supplierid,4)) FROM supplier"
            command1 = New SqlCommand(str, myconnection)
            dreader = command1.ExecuteReader()
            While dreader.Read()
                If Not dreader.HasRows Or IsDBNull(dreader.Item(0)) Then
                    txtSupplierID.Text = "SS/" & DateTime.Now.Year & "/0001"
                Else
                    newid = CInt(dreader.Item(0))
                    newid += 1
                    txtSupplierID.Text = "SS/" & DateTime.Now.Year & "/" & newid.ToString("0000")
                End If
            End While
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub
    Private Function GenerateID() As String
        Dim value As String = "0000"
        Try
            ' Fetch the latest ID from the database
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            command = New SqlCommand("SELECT TOP 1 supplierid FROM supplier ORDER BY supplierid DESC", myconnection)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            If dreader.HasRows Then
                dreader.Read()
                value = dreader.Item("supplierid")
            End If
            dreader.Close()
            ' Increase the ID by 1
            value += 1
            ' Because incrementing a string with an integer removes 0's
            ' we need to replace them. If necessary.
            If value <= 9 Then 'Value is between 0 and 10
                value = "000" & value
            ElseIf value <= 99 Then 'Value is between 9 and 100
                value = "00" & value
            ElseIf value <= 999 Then 'Value is between 999 and 1000
                value = "0" & value
            End If
        Catch ex As Exception
            ' If an error occurs, check the connection state and close it if necessary.
            If myconnection.State = ConnectionState.Open Then
                myconnection.Close()
            End If
            value = "0000"
        End Try
        Return value
    End Function
    Sub auto()
        Try
            Dim regyear As DateTime = DateTime.Now
            txtSupplierID.Text = GenerateID() & "/" & regyear.ToString("yy")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Sub Reset()
        txtSID.Text = ""
        txtSupplierID.Text = ""
        txtSupplierName.Text = ""
        txtLocation.Text = ""
        txtContactNo.Text = ""
        txtEmailID.Text = ""
        txtAddress.Text = ""
        txtSupplierName.Focus()
        btnSave.Enabled = True
        btnNew.Enabled = True
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Reset()
        auto()
    End Sub
    Private Sub DeleteRecord()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "select * from supplier where supplierid =" & Val(txtSID.Text) & ""
            command = New SqlCommand(query)
            command.Connection = myconnection
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            If dreader.Read() Then
                ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''Dbconnection.Open()
                ConnectDB()
                Dim delete As String = "delete from supplier where supplierid =" & Val(txtSID.Text) & ""
                command1 = New SqlCommand(delete, myconnection)
                command1.ExecuteNonQuery()
                AllUserActivities(LogFullName + ", deleted the supplier record having supplier id '" & txtSupplierID.Text & "'")
                MessageBox.Show("Record deleted", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
                auto()
            Else
                MessageBox.Show("Sorry.. No specific record found to process", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Reset()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If Len(Trim(txtSupplierName.Text)) = 0 Then
            MessageBox.Show("Please enter supplier name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtSupplierName.Focus()
            Exit Sub
        End If
        If Len(Trim(txtLocation.Text)) = 0 Then
            MessageBox.Show("Please enter location", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtLocation.Focus()
            Exit Sub
        End If
        If Len(Trim(txtContactNo.Text)) = 0 Then
            MessageBox.Show("Please enter telephone or contact number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtContactNo.Focus()
            Exit Sub
        End If
        If (txtContactNo.TextLength < 10) Then
            MessageBox.Show("Invalid supplier contact number." + vbCrLf + "Number must be 10-digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtContactNo.Focus()
            Exit Sub
        End If
        Dim st As String = txtContactNo.Text.Substring(0, 3)
        If (st <> "024") AndAlso (st <> "054") AndAlso (st <> "055") AndAlso (st <> "027") AndAlso (st <> "057") AndAlso (st <> "026") AndAlso (st <> "020") AndAlso (st <> "050") AndAlso (st <> "023") Then
            MsgBox("Phone or mobile number not valid." & vbCrLf & "Number should be mtn/airteltigo/vodafone/glo... eg(0241234567)", MsgBoxStyle.Information, "Invalid Mobile / Telephone")
            txtContactNo.Clear() 'clear the text
            Exit Sub
        End If

        'proceed to save record
        If MsgBox("Are you sure you want to add  new supplier?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = MsgBoxResult.Yes Then
            SaveRecord()
        End If
    End Sub
    Sub SaveRecord()
        Try
            'check supplier name
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Const check As String = "select RTRIM(name) from supplier where name=@d1"
            command = New SqlCommand(check)
            command.Parameters.AddWithValue("@d1", txtSupplierName.Text)
            command.Connection = myconnection
            dreader = command.ExecuteReader()
            If dreader.Read() Then
                dreader.Close()
                MessageBox.Show("A supplier with the name '" & txtSupplierName.Text & "' is already registered.." & vbNewLine & "Cannot save duplicate record", "Supplier Name Exists", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                Exit Sub
            End If
            'check supplier contact number
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            Const chk As String = "select RTRIM(contactno) from supplier where contactno=@d1"
            command = New SqlCommand(chk)
            command.Parameters.AddWithValue("@d1", txtContactNo.Text)
            command.Connection = myconnection
            dreader = command.ExecuteReader()
            If dreader.Read() Then
                dreader.Close()
                MessageBox.Show("The contact number '" & txtContactNo.Text & "' is already registered.." & vbNewLine & "Cannot save duplicate record", "Supplier Number Exists", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                Exit Sub
            End If
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "insert into supplier(supplier_id, [name], contactno, location, email,address) VALUES (@d1,@d2,@d3,@d4,@d5,@d6)"
            command = New SqlCommand(query, myconnection)
            command.Parameters.AddWithValue("@d1", txtSupplierID.Text)
            command.Parameters.AddWithValue("@d2", txtSupplierName.Text)
            command.Parameters.AddWithValue("@d3", txtContactNo.Text)
            command.Parameters.AddWithValue("@d4", txtLocation.Text)
            command.Parameters.AddWithValue("@d5", txtEmailID.Text)
            command.Parameters.AddWithValue("@d6", txtAddress.Text)
            command.ExecuteNonQuery()
            AllUserActivities(LogFullName + ", added the new supplier having supplier id '" & txtSupplierID.Text & "' on " & DateTime.Now)
            MessageBox.Show("Record saved", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Reset()
            auto()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "Saving Record Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MessageBox.Show(txtSupplierName.Text + " will be deleted permanently?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = MsgBoxResult.Ok Then
            DeleteRecord()
        End If
    End Sub
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If Len(Trim(txtSupplierName.Text)) = 0 Then
            MessageBox.Show("Please enter supplier name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtSupplierName.Focus()
            Exit Sub
        End If
        If Len(Trim(txtLocation.Text)) = 0 Then
            MessageBox.Show("Please enter location", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtLocation.Focus()
            Exit Sub
        End If
        If Len(Trim(txtContactNo.Text)) = 0 Then
            MessageBox.Show("Please enter telephone or contact number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtContactNo.Focus()
            Exit Sub
        End If
        Dim st As String = txtContactNo.Text.Substring(0, 3)
        If (st <> "024") AndAlso (st <> "054") AndAlso (st <> "055") AndAlso (st <> "027") AndAlso (st <> "057") AndAlso (st <> "026") AndAlso (st <> "020") AndAlso (st <> "050") AndAlso (st <> "023") Then
            MsgBox("Phone or mobile number not valid." & vbCrLf & "Number should be mtn/airteltigo/vodafone/glo... eg(0241234567)", MsgBoxStyle.Information, "Invalid Mobile / Telephone")
            txtContactNo.Clear() 'clear the text
            Exit Sub
        End If
        If MsgBox("The changes will be made to selected supplier record. Do you want to continue?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = MsgBoxResult.Yes Then
            Try
                'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                'Dbconnection.Open()
                ConnectDB()
                query = "update supplier set [name]=@d1, contactno=@d2, location=@d3, email=@d4, address=@d5 where supplierid=" & Val(txtSID.Text) & ""
                command = New SqlCommand(query, myconnection)
                command.Parameters.AddWithValue("@d1", txtSupplierName.Text)
                command.Parameters.AddWithValue("@d2", txtContactNo.Text)
                command.Parameters.AddWithValue("@d3", txtLocation.Text)
                command.Parameters.AddWithValue("@d4", txtEmailID.Text)
                command.Parameters.AddWithValue("@d5", txtAddress.Text)
                command.ExecuteNonQuery()
                AllUserActivities(LogFullName + ", updated the supplier having supplier id '" & txtSupplierID.Text & "' on " & DateTime.Now)
                MessageBox.Show("Record updated", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
                auto()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub Supplier_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Reset()
    End Sub
    Private Sub Supplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reset()
        auto()
    End Sub
    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        ''another Form invokemethod
        Dim frm As New SupplierRecord
        frm.CurrentActiveForm = Me
        frm.lblSet.Text = "Supplier Entry"
        frm.Reset()
        frm.ShowDialog()
    End Sub

    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub
    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
    Private Sub dgv_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellDoubleClick
        Try
            txtSID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtSupplierID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            txtSupplierName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
            txtContactNo.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value
            txtLocation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value
            txtEmailID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value
            txtAddress.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value
            btnSave.Enabled = False
            btnNew.Enabled = False
            btnDelete.Enabled = True
            btnUpdate.Enabled = True
        Catch ex As Exception

        End Try
    End Sub
    Private Sub txtEmailID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEmailID.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 45, 46, 64, 95, 127, 48 To 57, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub
    Private Sub txtSupplierName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSupplierName.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
    Private Sub txtContactNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtContactNo.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True    ' accepts numbers only
        End If
    End Sub
    Private Sub txtAddress_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAddress.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
    Private Sub txtLocation_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtLocation.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub
    Private Sub txtContactNo_Leave(sender As Object, e As EventArgs) Handles txtContactNo.Leave
        If Not (txtContactNo.Text.StartsWith("0")) Then
            txtContactNo.ForeColor = Color.Brown
        Else
            txtContactNo.ForeColor = Color.Black
        End If
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Close()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        ''Dim yy As DateTime = DateTime.Now
        ''MsgBox(yy.ToString("yy"))
    End Sub
End Class
