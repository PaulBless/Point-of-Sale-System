﻿Public Class SalesReport

    Sub GenerateSalesReport()
        Try
            Cursor = Cursors.WaitCursor
            Timer1.Enabled = True
            Dim objcmd As SqlCommand
            Dim objdr As SqlDataReader
            Dim objds As DataSet = New dsetTygen
            Dim sql As String = " select invoiceno, (invdate), (pname), (infoprice), (infoqty), (infototal) from product p inner join invoice_info info on p.productid= info.prod_id inner join invoice i on info.invoice_id=i.invid where  info.infodate=i.invdate and invdate between  @d1 and @d2 order by invdate desc"
            query = "select invoiceno, RTRIM(invdate), RTRIM(pname), RTRIM(infoprice), RTRIM(infoqty), RTRIM(infototal) from product, invoice, invoice_info where product.productid=invoice_info.prod_id and invoice.invid=invoice_info.invoice_id and invdate between @d1 and @d2 order by invdate desc"
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            objcmd = New SqlCommand(sql, myconnection)
            objcmd.CommandType = CommandType.Text
            objcmd.Parameters.Add("@d1", SqlDbType.Date, 30, "Date").Value = dtpDateFrom.Value.Date
            objcmd.Parameters.Add("@d2", SqlDbType.Date, 30, "Date").Value = dtpDateTo.Value.Date
            objdr = objcmd.ExecuteReader()
            objds.Tables(0).Clear()
            objds.Tables(0).Load((objdr))
            objdr.Close()
            Dim rds As ReportDataSource = New ReportDataSource()
            rds.Name = "mySalesReport"
            rds.Value = objds.Tables(0)
            Dim param As New List(Of ReportParameter)
            param.Add(New ReportParameter("pDateFrom", Me.dtpDateFrom.Value.Date))
            param.Add(New ReportParameter("pDateTo", Me.dtpDateTo.Value.Date))
            With Report
                .ReportViewer1.LocalReport.ReportEmbeddedResource = "POS.rptSalesReport1.rdlc"
                .ReportViewer1.LocalReport.DataSources.Clear()
                .ReportViewer1.LocalReport.DataSources.Add(rds)
                .ReportViewer1.LocalReport.SetParameters(param)
                .ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
                .ReportViewer1.Refresh()
                .Text = "Sales Report"
                .ShowDialog()
            End With

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Information, "Sales Report Error")
        End Try
    End Sub
    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        GenerateSalesReport()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Cursor = Cursors.Default
        Timer1.Enabled = False
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
End Class