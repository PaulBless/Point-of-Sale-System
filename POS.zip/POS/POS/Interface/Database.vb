﻿Imports POS.My

Public Class Database
    Private TstServerSQL As String
    Private TstPortSQL As String
    Private TstUserNameSQL As String
    Private TstPwdSQL As String
    Private TstDBNameSQL As String
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub Database_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        TstServerSQL = txtServer.Text
        TstDBNameSQL = txtDbName.Text

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        
    End Sub
End Class