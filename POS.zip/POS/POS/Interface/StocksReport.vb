﻿Public Class StocksReport

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
    Sub GeneratReport()
        Try
            Cursor = Cursors.WaitCursor
            Timer1.Enabled = True
            Dim objcmd As SqlCommand
            Dim objdr As SqlDataReader
            Dim objds As DataSet = New dsetTygen
            Dim sql As String = "select stockid, (pname), (quantity), (price), (totalamount),(datein), supplier.supplier_id, [name], contactno from product p inner join stock s on p.productid= s.product_id inner join stock_payment sp on s.stid=sp.stock_id left outer join supplier on sp.supplier_id=supplier.supplierid where s.datein=sp.stockdate and datein between  @d1 and @d2 order by datein desc"
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            objcmd = New SqlCommand(sql, myconnection)
            objcmd.CommandType = CommandType.Text
            objcmd.Parameters.Add("@d1", SqlDbType.Date, 30, "Date").Value = dtpDateFrom.Value.Date
            objcmd.Parameters.Add("@d2", SqlDbType.Date, 30, "Date").Value = dtpDateTo.Value.Date
            objdr = objcmd.ExecuteReader()
            objds.Tables(0).Clear()
            objds.Tables(0).Load((objdr))
            objdr.Close()
            Dim rds As ReportDataSource = New ReportDataSource()
            rds.Name = "myStocksReport"
            rds.Value = objds.Tables(0)
            Dim param As New List(Of ReportParameter)
            param.Add(New ReportParameter("pDateFrom", Me.dtpDateFrom.Value.Date))
            param.Add(New ReportParameter("pDateTo", Me.dtpDateTo.Value.Date))
            With Report
                .ReportViewer1.LocalReport.ReportEmbeddedResource = "POS.rptStocksReport.rdlc"
                .ReportViewer1.LocalReport.DataSources.Clear()
                .ReportViewer1.LocalReport.DataSources.Add(rds)
                .ReportViewer1.LocalReport.SetParameters(param)
                .ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
                .ReportViewer1.Refresh()
                .Text = "Stocks Report"
                .ShowDialog()
            End With

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Information, "Sales Report Error")
        End Try
    End Sub

    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        GeneratReport()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Cursor = Cursors.Default
        Timer1.Enabled = False
    End Sub
End Class