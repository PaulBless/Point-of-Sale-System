﻿Imports System.Data.SqlClient

Public Class StockRecord
    Public Sub Getdata()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "SELECT DISTINCT(stock.stid), RTRIM(stock.stockid), RTRIM(stock.datein), RTRIM(supplier.supplierid),RTRIM(supplier.name),RTRIM(stock_payment.grandtotal),RTRIM(stock_payment.totalpayment), RTRIM(stock_payment.paymentdue) from stock,supplier,stock_payment where supplier.supplierid=stock_payment.supplier_id order by stock.datein desc"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (dreader.Read() = True)
                dgw.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6), dreader(7))
            End While
            'Dbconnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub Reset()
        txtSupplierName.Text = ""
        dtpDateFrom.Text = Today
        dtpDateTo.Text = Now
        dtPayFrom.Text = Today
        dtPayTo.Text = Now
        Getdata()
    End Sub

    Private Sub StockRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata()
    End Sub
    Private Sub dgw_MouseClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                ''    Stock.Show()
                ''    Me.Hide()
                ''    'Stock.txtST_ID.Text = dr.Cells(0).Value.ToString()
                ''    Stock.txtStockID.Text = dr.Cells(1).Value.ToString()
                ''    'Stock.dtpDate.Text = dr.Cells(2).Value.ToString()
                ''    Stock.txtSup_ID.Text = dr.Cells(3).Value.ToString()
                ''    'Stock.txtSupplierID.Text = dr.Cells(4).Value.ToString()
                ''    Stock.txtSupplierName.Text = dr.Cells(5).Value.ToString()
                ''    Stock.txtGrandTotal.Text = dr.Cells(6).Value.ToString()
                ''    'Stock.txtTotalPayment.Text = dr.Cells(7).Value.ToString()
                ''    Stock.btnSave.Enabled = False
                ''    Stock.btnUpdate.Enabled = True
                ''    Stock.dtpStockDate.Enabled = False
                ''    Stock.dgv.Enabled = False
                ''    Stock.btnAdd.Enabled = False
                ''    If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                ''    Dbconnection.Open()
                ''    Dim sql As String = "SELECT PID,RTRIM(Product.ProductCode),RTRIM(Productname),Qty,Price,TotalAmount from Stock,Stock_Product,product where product.PID=Stock_product.ProductID and Stock.ST_ID=Stock_Product.StockID and ST_ID=" & dr.Cells(0).Value & ""
                ''    command = New SqlCommand(sql, Dbconnection)
                ''    dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
                ''    Stock.dgv.Rows.Clear()
                ''    While (dreader.Read() = True)
                ''        Stock.dgv.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5))
                ''    End While
                ''    Dbconnection.Close()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub txtSupplierName_TextChanged(sender As Object, e As EventArgs) Handles txtSupplierName.TextChanged
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "SELECT RTRIM(stock.stid), RTRIM(stock.stockid), RTRIM(stock.datein), RTRIM(supplier.supplierid),RTRIM(supplier.name),RTRIM(stock_payment.grandtotal),RTRIM(stock_payment.totalpayment), RTRIM(stock_payment.paymentdue) from stock,supplier,stock_payment where supplier.supplierid=stock_payment.supplier_id and supplier.name like '%" & txtSupplierName.Text & "%' order by stock.datein"
            command = New SqlCommand(query, myconnection)
            dreader = command.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (dreader.Read() = True)
                dgw.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6), dreader(7))
            End While
            'Dbconnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "SELECT RTRIM(stock.stid), RTRIM(stock.stockid), RTRIM(stock.datein), RTRIM(supplier.supplierid),RTRIM(supplier.name),RTRIM(stock_payment.grandtotal),RTRIM(stock_payment.totalpayment), RTRIM(stock_payment.paymentdue) from stock,supplier,stock_payment where supplier.supplierid=stock_payment.supplier_id and [datein] between @d1 and @d2  order by stock.datein"
            command = New SqlCommand(query, myconnection)
            command.Parameters.Add("@d1", SqlDbType.Date, 30, "Date").Value = dtpDateFrom.Value.Date
            command.Parameters.Add("@d2", SqlDbType.Date, 30, "Date").Value = dtpDateTo.Value.Date
            dreader = command.ExecuteReader()
            While (dreader.Read())
                dgw.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6), dreader(7))
            End While
            'Dbconnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub

    Private Sub btnGet_Click(sender As Object, e As EventArgs) Handles btnGet.Click
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            query = "SELECT RTRIM(stock.stid), RTRIM(stock.stockid), RTRIM(stock.datein), RTRIM(supplier.supplierid),RTRIM(supplier.name),RTRIM(stock_payment.grandtotal),RTRIM(stock_payment.totalpayment), RTRIM(stock_payment.paymentdue) from stock,supplier,stock_payment where supplier.supplierid=stock_payment.supplier_id and [payduedate] between @d1 and @d2  order by stock.datein"
            command = New SqlCommand(query, myconnection)
            command.Parameters.Add("@d1", SqlDbType.Date, 30, "Date").Value = dtPayFrom.Value.Date
            command.Parameters.Add("@d2", SqlDbType.Date, 30, "Date").Value = dtPayTo.Value.Date
            dreader = command.ExecuteReader()
            While (dreader.Read())
                dgw.Rows.Add(dreader(0), dreader(1), dreader(2), dreader(3), dreader(4), dreader(5), dreader(6), dreader(7))
            End While
            ''Dbconnection.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub
End Class