﻿Imports System.Data.SqlClient

Public Class Locations
    Dim locname As String
    Private Sub Location_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub GetData()
        Try
            If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            Dbconnection.Open()
            query = "select locid,locname from location order by locname asc"
            dadapter = New SqlDataAdapter(query, Dbconnection)
            dtable = New DataTable()
            dadapter.Fill(dtable)
            If (dtable.Rows.Count = 0) Then
                MessageBox.Show("No record of location or towns found.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                dgv.Rows.Clear()
            Else
                dgv.Rows.Clear()
                For Each item As DataRow In dtable.Rows
                    Dim i As Integer = dgv.Rows.Add()
                    dgv.Rows(i).Cells(0).Value = item("locid").ToString()
                    dgv.Rows(i).Cells(1).Value = item("locname").ToString()
                Next
            End If

        Catch ex As SqlException
            MessageBox.Show(ex.Message)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub dgv_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles dgv.RowsAdded
        For Each row As DataGridViewRow In dgv.Rows
            row.HeaderCell.Value = String.Format("{0}", (row.Index + 1).ToString())
        Next
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Sub Reset()
        txtLocation.Text = ""
        btnSave.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        txtLocation.Focus()
        GetData()
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Reset()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtLocation.Text = "" Then
            MessageBox.Show("Please enter location name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtLocation.Focus()
            Return
        End If
        Try
            'check product name exists
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Const check As String = "select RTRIM(locname) from location where locname=@d1"
            command = New SqlCommand(check)
            command.Parameters.AddWithValue("@d1", txtLocation.Text)
            command.Connection = myconnection
            dreader = command.ExecuteReader()
            If dreader.Read() Then
                dreader.Close()
                MessageBox.Show("The location '" & txtLocation.Text & "' is already added", "Record Exists", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            End If
            'proceed to save record
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            query = "insert into location(locname) VALUES (@d1)"
            command = New SqlCommand(query, myconnection)
            command.Parameters.AddWithValue("@d1", txtLocation.Text)
            command.ExecuteNonQuery()
            AllUserActivities(LogFullName + ", added a new location with name '" & txtLocation.Text & "' on " & DateTime.Now)
            MessageBox.Show("Record saved", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Reset()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        GetData()
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MessageBox.Show("Permanently delete '" & txtLocation.Text & "' from the system." & vbCrLf & "Do you want to continue?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1) = MsgBoxResult.Yes Then
            DeleteRecord()
        End If
    End Sub
    Sub DeleteRecord()
        Try
            ''If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            ''Dbconnection.Open()
            ConnectDB()
            Dim chk As String = "select * from location where locid='" & dgv.SelectedRows(0).Cells(0).Value & ""
            Dim com As New SqlCommand(chk, myconnection)
            dreader = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dreader.Read() Then  'if product is found in database, proceed to delete product record
                dreader.Close()
                'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                'Dbconnection.Open()
                ConnectDB()
                query = "delete from location where locid='" & dgv.SelectedRows(0).Cells(0).Value & "'"
                command = New SqlCommand(query, myconnection)
                command.ExecuteNonQuery()
                AllUserActivities(LogFullName + ", deleted the location: " & locname & " on " & Date.Now)
                MessageBox.Show("Record successfully deleted", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            Else
                MessageBox.Show("Record not found. Could not complete the process..", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try

    End Sub
    Sub UpdateRecord()
        Try
            'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
            'Dbconnection.Open()
            ConnectDB()
            Dim chk As String = "select * from location where locid='" & dgv.SelectedRows(0).Cells(0).Value & "'"
            Dim com As New SqlCommand(chk, myconnection)
            dreader = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dreader.Read() Then  'if product is found in database, proceed to update product record
                dreader.Close()
                'If Dbconnection.State = ConnectionState.Open Then Dbconnection.Close()
                'Dbconnection.Open()
                ConnectDB()
                query = "update location set locname=@d1 where locid=@locid"
                command = New SqlCommand(query, myconnection)
                command.Parameters.AddWithValue("@d1", txtLocation.Text)
                command.Parameters.AddWithValue("@locid", dgv.SelectedRows(0).Cells(0).Value)
                command.ExecuteNonQuery()
                AllUserActivities(LogFullName & ", updated the location with name: " & locname & " on " & Date.Now)
                MessageBox.Show("Record successfully updated.", "Sale System", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            Else
                MessageBox.Show("Record not found. Could not complete the process.. ", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        UpdateRecord()
    End Sub

    Private Sub dgv_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellDoubleClick
        Try
            locname = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            txtLocation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            btnSave.Enabled = False
            btnDelete.Enabled = True
            btnUpdate.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString(), , "Error")
        End Try
    End Sub
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Me.Close()
    End Sub
End Class